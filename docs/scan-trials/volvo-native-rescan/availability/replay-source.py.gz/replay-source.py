from pathlib import Path
from collections import Counter
import os,json,subprocess,gzip,time
base=Path('/Users/RNEL/Workspace/groundWork');clones=Path('/Users/RNEL/.cache/groundwork/clones');state=json.loads((base/'docs/scan-trials/volvo-native-rescan/scan-state.json').read_text());out=base/'reports/volvo-native-rescan/remaining-availability';out.mkdir(exist_ok=True);env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'};results=[]
for row in state['repositories']:
 if row['basis']!='repository_scan' or row['status']!='not_started':continue
 started=time.monotonic();repo=row['repo'];clone=clones/repo;result={'repo':repo,'commit':row['commit'],'qualification':'Offline object/tree availability only; no source semantics, endpoint completeness, source-body review or native capture acceptance is claimed.'}
 if not (clone/'.git').exists():result.update(status='clone_unavailable',action='Obtain authorised pinned clone before semantic scan; no automatic fetch attempted')
 else:
  try:
   raw=subprocess.check_output(['git','-C',str(clone),'ls-tree','-r','-z',row['commit']],env=env,stderr=subprocess.PIPE,timeout=30);tree=[]
   for entry in raw.split(b'\0'):
    if not entry:continue
    meta,path=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();tree.append({'path':path.decode('utf8','surrogateescape'),'mode':mode,'kind':kind,'oid':oid})
   oids=sorted({x['oid']for x in tree if x['kind']=='blob'});data='\n'.join(oids)+'\n';answer=subprocess.check_output(['git','-C',str(clone),'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],input=data.encode(),env=env,stderr=subprocess.PIPE,timeout=90).decode().splitlines();available={};missing=[]
   for line in answer:
    parts=line.split()
    if len(parts)==3 and parts[1]=='blob':available[parts[0]]=int(parts[2])
    else:missing.append(parts[0])
   absent=[x['path']for x in tree if x['kind']=='blob'and x['oid']not in available];gitlinks=[x for x in tree if x['kind']=='commit'];extensions=Counter(Path(x['path']).suffix or '(no extension)'for x in tree if x['kind']=='blob')
   result.update(status='all_parent_blob_objects_available'if not absent else'parent_blobs_unavailable',trackedEntries=len(tree),uniqueBlobObjects=len(oids),availableBlobObjects=len(available),parentBlobPathsMissing=absent,gitlinks=gitlinks,logicalBlobBytes=sum(available.values()),extensions=dict(extensions.most_common()))
   (out/(repo.split('/')[-1]+'.tree.json.gz')).write_bytes(gzip.compress(json.dumps({'repo':repo,'commit':row['commit'],'tree':tree,'blobObjectSizes':available,'unavailableObjectIDs':missing},ensure_ascii=True,separators=(',',':')).encode()))
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as error:result.update(status='offline_lookup_failed',error=(error.stderr.decode(errors='replace')if isinstance(error,subprocess.CalledProcessError)else str(error))[:1200])
 result['elapsedMs']=round((time.monotonic()-started)*1000);results.append(result);print(json.dumps({k:result[k]for k in ['repo','status','elapsedMs']}),flush=True)
report={'qualification':'Availability preflight of previously unstarted pinned repositories. No fetch, source builds/tests, body review, native capture or completion implied. Source blob contents still require full semantic scan and independent acceptance; gitlink child availability is not established here.','repositories':len(results),'statuses':dict(Counter(x['status']for x in results)),'results':results};(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
