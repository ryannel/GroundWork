from pathlib import Path
import json,gzip,sys
prior,ledger,out=map(Path,sys.argv[1:])
bundle=json.loads(gzip.decompress(prior.read_bytes()));changes=json.loads(ledger.read_text());by={r['id']:r for r in bundle['records']}
for change in changes['fields']:
 field=next(f for f in by[change['shape']]['fields']if f['name']==change['field'])
 assert field['type']==change['sourceType'] and 'nullable'not in field
 field['nullable']=True
old,new=changes['namespaceTranslation'].values()
result=json.loads(json.dumps(bundle).replace(old,new))
out.write_text(json.dumps(result,indent=2)+'\n')
