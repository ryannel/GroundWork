"""Create source-kind metadata from parse-only Java trees; no lexical body reparse."""
import json,pathlib
out=pathlib.Path(__file__).resolve().parent;a=json.loads((out/'javac-source-index.json').read_text());classes=[]
assert not a['diagnostics']
for f in a['files']:
 if not '/src/main/' in f['path']:continue
 for c in f['classes']:
  classes.append(dict(fqn=f['package']+'.'+c['name'],name=c['name'],kind=c['kind'].lower(),path=f['path'],fields=[dict(name=x['name'],modifiers=['static'] if 'static' in x['declaration']['text'].split('=')[0] else [],annotations=[]) for x in c['fields']],annotations=[]))
assert len(set(c['fqn'] for c in classes))==len(classes)
(out/'source-index.json').write_text(json.dumps(dict(repo='volvo-cars/cds-ecom-customer-service',commit='09623ab3a1f39845d8fc02abc3d591b53a3b5fea',classes=classes,qualification='Original Java syntax exporter; source class kind and independent exact method bodies. Legacy lexical compact-record limitation is not used.'),indent=2)+'\n')
