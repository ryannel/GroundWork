"""Freeze a fresh immutable native identity and matched ledgers, never overwrite a selection."""
import json,pathlib,hashlib,collections
D=pathlib.Path(__file__).resolve().parent
old='volvo/cds-ecom-customer-service/09623ab3a1f3/draft-r1/'
new='volvo/cds-ecom-customer-service/09623ab3a1f3/final-r1/'
def revise(x):
 if isinstance(x,str):return x.replace(old,new)
 if isinstance(x,list):return [revise(v) for v in x]
 if isinstance(x,dict):return {k:revise(v) for k,v in x.items()}
 return x
bundle=revise(json.loads((D/'working.bundle.json').read_text()))
target=D/'bundle.final-r1.json';assert not target.exists();target.write_text(json.dumps(bundle,indent=2)+'\n')
selected=['source-files','source-index','javac-source-index','method-ledger','call-audit','entry-ledger','registration-ledger','io-ledger','caller-contract-ledger','subscription-ledger','construction-ledger','source-review','test-assertion-ledger','dependency-ledger','openapi-ledger','schema-ledger','rest-ledger','async-ledger','write-ledger','channel-ledger','publication-ledger','adapter-ledger']
for name in selected:
 target=D/(name+'.final-r1.json');assert not target.exists();target.write_text(json.dumps(revise(json.loads((D/(name+'.json')).read_text())),indent=2)+'\n')
(D/'revision-ledger.final-r1.json').write_text(json.dumps(dict(previous='unfrozen draft-r1 diagnostic only',selected='final-r1',policy='All fact IDs use a fresh revision namespace; logicalIds and exact source tuples preserved.',changedIds={r['id']:r['id'].replace(new,old) for r in bundle['records']},selectedLedgers=selected),indent=2)+'\n')
print(json.dumps(dict(records=len(bundle['records']),kinds=collections.Counter(r['kind'] for r in bundle['records'])),indent=2))
