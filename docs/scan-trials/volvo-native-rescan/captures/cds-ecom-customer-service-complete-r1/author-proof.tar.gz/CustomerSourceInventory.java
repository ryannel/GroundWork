import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

public class CustomerSourceInventory {
  static Trees trees;
  static CompilationUnitTree unit;
  static String source;
  static SourcePositions positions;
  static String quote(String s) {
    if (s == null) return "null";
    StringBuilder b = new StringBuilder("\"");
    for (char c : s.toCharArray()) {
      switch(c) {
        case '"': b.append("\\\""); break;
        case '\\': b.append("\\\\"); break;
        case '\n': b.append("\\n"); break;
        case '\r': b.append("\\r"); break;
        case '\t': b.append("\\t"); break;
        default: if(c < 32)b.append(String.format("\\u%04x", (int)c)); else b.append(c);
      }
    }
    return b.append('"').toString();
  }
  static long start(Tree t) { return positions.getStartPosition(unit,t); }
  static long end(Tree t) { return positions.getEndPosition(unit,t); }
  static String text(Tree t) {
    if(t == null)return null;
    long s=start(t), e=end(t);
    return s<0 || e<s ? t.toString() : source.substring((int)s,(int)e);
  }
  static String node(Tree t) {
    if(t == null)return "null";
    List<String> children=new ArrayList<>();
    t.accept(new TreeScanner<Void,Void>() {
      @Override public Void scan(Tree child,Void p) {
        if(child!=null)children.add(node(child));
        return null;
      }
    },null);
    return "{\"kind\":"+quote(t.getKind().name())+",\"text\":"+quote(text(t))+
      ",\"start\":"+start(t)+",\"end\":"+end(t)+",\"lines\":["+
      unit.getLineMap().getLineNumber(Math.max(0,start(t)))+","+
      unit.getLineMap().getLineNumber(Math.max(0,end(t)-1))+"],\"children\":["+
      String.join(",",children)+"]}";
  }
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    var diagnostics=new DiagnosticCollector<JavaFileObject>();
    var fm=compiler.getStandardFileManager(diagnostics,null,null);
    List<Path> files=Files.walk(Path.of(args[0])).filter(p->p.toString().endsWith(".java")).sorted().toList();
    List<JavaFileObject> syntaxFiles=new ArrayList<>();
    for(var file:fm.getJavaFileObjectsFromPaths(files)) {
      syntaxFiles.add(new ForwardingJavaFileObject<JavaFileObject>(file) {
        @Override public CharSequence getCharContent(boolean ignoreEncodingErrors) throws java.io.IOException {
          String original=super.getCharContent(ignoreEncodingErrors).toString();
          var matcher=java.util.regex.Pattern.compile("UserIdentity\\.(VolvoId|Connect|EntraId)\\((String|ConnectToken|EntraIdUser)\\s+(token|user)\\)").matcher(original);
          var replaced=new StringBuilder(); int end=0;
          while(matcher.find()) {
            replaced.append(original,end,matcher.start());
            String replacement="UserIdentity."+matcher.group(1)+" "+matcher.group(3);
            replaced.append(replacement).append(" ".repeat(matcher.group().length()-replacement.length()));end=matcher.end();
          }
          replaced.append(original.substring(end));
          return replaced.toString().replaceAll("(catch\\s*\\(\\s*\\w+\\s+)_([\\s]*\\))", "$1\\$$2").replaceAll("(UserIdentity\\.VolvoId\\s+)_", "$1\\$");
        }
      });
    }
    var task=(JavacTask)compiler.getTask(null,fm,diagnostics,List.of("-proc:none","--release","17","--enable-preview"),null,syntaxFiles);
    var units=task.parse();
    trees=Trees.instance(task);positions=trees.getSourcePositions();
    List<String> result=new ArrayList<>();
    for(var current:units) {
      unit=current;source=Files.readString(Path.of(current.getSourceFile().toUri()));
      List<String> classes=new ArrayList<>();
      new TreeScanner<Void,String>() {
        @Override public Void visitClass(ClassTree t,String parent) {
          String name=(parent==null?"":parent+".")+(t.getSimpleName().length()==0?"$anonymous@"+start(t):t.getSimpleName());
          List<String> methods=new ArrayList<>(), fields=new ArrayList<>();
          for(var member:t.getMembers()) {
            if(member instanceof MethodTree m) {
              List<String> params=new ArrayList<>();
              for(var p:m.getParameters())params.add("{\"name\":"+quote(p.getName().toString())+",\"type\":"+quote(p.getType().toString())+"}");
              methods.add("{\"name\":"+quote(m.getName().toString())+",\"returnType\":"+quote(m.getReturnType()==null?null:m.getReturnType().toString())+",\"typeParameters\":["+String.join(",",m.getTypeParameters().stream().map(i->quote(i.toString())).toList())+"],\"throws\":["+String.join(",",m.getThrows().stream().map(i->quote(i.toString())).toList())+"]"+",\"parameters\":["+String.join(",",params)+"],\"declaration\":"+node(m)+",\"body\":"+node(m.getBody())+"}");
            } else if(member instanceof VariableTree v) fields.add("{\"name\":"+quote(v.getName().toString())+",\"type\":"+quote(v.getType().toString())+",\"declaration\":"+node(v)+"}");
          }
          classes.add("{\"kind\":"+quote(t.getKind().name())+",\"name\":"+quote(name)+",\"extends\":"+quote(t.getExtendsClause()==null?null:t.getExtendsClause().toString())+",\"typeParameters\":["+String.join(",",t.getTypeParameters().stream().map(i->quote(i.toString())).toList())+"]"+",\"implements\":["+String.join(",",t.getImplementsClause().stream().map(i->quote(i.toString())).toList())+"]"+",\"fields\":["+String.join(",",fields)+"],\"methods\":["+String.join(",",methods)+"]}");
          return super.visitClass(t,name);
        }
      }.scan(current,null);
      List<String> imports=current.getImports().stream().map(i->quote(i.getQualifiedIdentifier().toString())).toList();
      result.add("{\"path\":"+quote(Path.of(args[0]).relativize(Path.of(current.getSourceFile().toUri())).toString())+",\"package\":"+quote(current.getPackageName().toString())+",\"imports\":["+String.join(",",imports)+"],\"classes\":["+String.join(",",classes)+"]}");
    }
    List<String> errors=new ArrayList<>();
    for(var d:diagnostics.getDiagnostics())errors.add(quote(d.toString()));
    System.out.print("{\"parser\":\"OpenJDK compiler syntax tree, Java17; known UserIdentity record patterns normalised to same-length type-binding surface, unnamed variables to $; exact component projection authored separately; exported text/offsets use unchanged pinned source; parse only, no compilation/attribution/application execution\",\"files\":["+String.join(",",result)+"],\"diagnostics\":["+String.join(",",errors)+"]}");
  }
}
