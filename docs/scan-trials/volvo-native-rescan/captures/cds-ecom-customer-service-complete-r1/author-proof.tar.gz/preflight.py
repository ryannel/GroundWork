import subprocess,os,json,pathlib,collections
REPO='volvo-cars/cds-ecom-customer-service';COMMIT='09623ab3a1f39845d8fc02abc3d591b53a3b5fea';CLONE=pathlib.Path('/Users/RNEL/.cache/groundwork/clones')/REPO;OUT=pathlib.Path(__file__).resolve().parent;TMP=pathlib.Path('/tmp/cds-ecom-customer-service-pinned');env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
def git(*args):return subprocess.run(['git','-C',str(CLONE),*args],env=env,capture_output=True,check=True).stdout
rows=[]
for entry in git('ls-tree','-rz','--full-tree',COMMIT).split(b'\0'):
 if not entry:continue
 head,path=entry.split(b'\t',1);mode,kind,oid=head.decode().split();path=path.decode();r=dict(path=path,mode=mode,kind=kind,blob=oid)
 if kind!='blob':r.update(available=False,role='gitlink');rows.append(r);continue
 try:data=git('cat-file','blob',oid);r['available']=True
 except subprocess.CalledProcessError:r['available']=False;rows.append(r);continue
 try:text=data.decode();r.update(text=True,lines=len(text.splitlines()))
 except UnicodeDecodeError:r.update(text=False,lines=None)
 role='production_java' if '/src/main/' in path and path.endswith('.java') else 'test_java' if '/src/test/' in path and path.endswith('.java') else 'test_resource' if '/src/test/' in path else 'api_schema' if path=='docs/openapi.json' else 'configuration_support'
 r.update(bytes=len(data),role=role);rows.append(r);target=TMP/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
result=dict(repo=REPO,commit=COMMIT,gitEnvironment={'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0'},fetchAttempted=False,files=rows,counts=dict(collections.Counter(r.get('role','missing') for r in rows)),available=sum(r['available'] for r in rows))
(OUT/'source-files.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
