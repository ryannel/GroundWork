#!/usr/bin/env python3
"""Finite pinned Java source capture; parse only, no source compilation or execution."""
import json,pathlib,hashlib,copy,re,collections,subprocess,os
OUT=pathlib.Path(__file__).resolve().parent
if (OUT/'snapshot.final-r1.json').exists():raise SystemExit('Frozen selection; use a fresh namespace')
REPO='volvo-cars/cds-ecom-customer-service';COMMIT='09623ab3a1f39845d8fc02abc3d591b53a3b5fea';P='volvo/cds-ecom-customer-service/09623ab3a1f3/draft-r1/'
ROOT=pathlib.Path('/tmp/cds-ecom-customer-service-pinned');CLONE=pathlib.Path('/Users/RNEL/.cache/groundwork/clones')/REPO
records=[];byid={};bundle=dict(format='groundwork-knowledge/v3',workspace='volvo-cars');original={}
AST=json.loads((OUT/'javac-source-index.json').read_text()); assert not AST['diagnostics']
LEX=json.loads((OUT/'source-index.json').read_text());lex={c['fqn']:c for c in LEX['classes']}
files=[f for f in AST['files'] if '/src/main/' in f['path']];classes={};methods={};simple=collections.defaultdict(list);audit=[];source_cache={}
def uid(s):return hashlib.sha256(s.encode()).hexdigest()[:20]
def add(kind,key,**kw):
 rid=P+key
 assert rid not in byid,rid
 r=dict(id=rid,kind=kind,**kw);records.append(r);byid[rid]=r;return rid
def raw(p):
 if p not in source_cache:source_cache[p]=(ROOT/p).read_text()
 return source_cache[p]
def ev(path,lines=None):
 lines=lines or [1,len(raw(path).splitlines())];lines=[max(1,lines[0]),max(1,lines[1])];key='e/'+uid(path+str(lines));rid=P+key
 return [rid] if rid in byid else [add('evidence',key,repo=REPO,host='github.com',commit=COMMIT,path=path,lines=lines,basis='source')]
scope=add('source_revision','source',repo=REPO,commit=COMMIT)
host=add('runtime_component','host',logicalId='svc:cds-ecom-customer-service',label='CDS Ecom Customer Service',category='service',technology='Java / Spring HTTP / Kafka',sources=[scope],basis='source_declared',gaps=[],evidence=ev('customer-service-api/src/main/java/com/volvocars/ecom/customerservice/api/App.java'))
for f in files:
 raw(f['path'])
 for c in f['classes']:
  fq=f['package']+'.'+c['name'];c.update(fqn=fq,file=f,path=f['path'],lex=lex.get(fq,{}));classes[fq]=c;simple[c['name'].split('.')[-1]].append(fq)
  for field in c['fields']:field['sourcePath']=f['path'];field['sourceOwner']=fq
  for i,m in enumerate(c['methods']):
   signature=fq+'#'+m['name']+'('+','.join(p['type'] for p in m['parameters'])+')';m.update(key=signature,ownerClass=c,file=f,impl=P+'method/'+uid(signature),params=[],exec=None,varargs=bool(m['parameters'] and re.search(r'\.\.\.\s+'+re.escape(m['parameters'][-1]['name'])+r'\b',m['declaration']['text'].split('{',1)[0])));methods[signature]=m

assert len(classes)==len(lex), (len(classes),len(lex))
assert len(methods)==sum(len(c['methods']) for f in files for c in f['classes']), 'method identity collision'

def clean(t):return re.sub(r'<.*>','',re.sub(r'@\w+(?:\([^)]*\))?\s*','',t or '')).replace('[]','').strip()
def fqtype(t,c):
 t=clean(t)
 if not t:return '?'
 for parameter in c.get('typeParameters',[]):
  match=re.fullmatch(r'(\w+)\s+extends\s+(.+)',parameter)
  if match and t==match[1]:return fqtype(match[2].split('&')[0].strip(),c)
 if t in classes:return t
 for im in c['file']['imports']:
  if '.' in t and im.endswith('.'+t.split('.')[0]) and im+'.'+t.split('.',1)[1] in classes:return im+'.'+t.split('.',1)[1]
  if im.endswith('.'+t):return im
  if im.endswith('.*') and im[:-1]+t in classes:return im[:-1]+t
 local=c['file']['package']+'.'+t
 if local in classes:return local
 outer=c['fqn']
 while '.' in outer:
  if outer+'.'+t in classes:return outer+'.'+t
  outer=outer.rsplit('.',1)[0]
 return t

def generic_args(t):
 if '<' not in (t or ''):return []
 text=t[t.find('<')+1:t.rfind('>')];out=[];start=0;depth=0
 for i,c in enumerate(text):
  if c=='<':depth+=1
  elif c=='>':depth-=1
  elif c==',' and depth==0:out.append(text[start:i].strip());start=i+1
 return out+[text[start:].strip()]
def declared_result(t,targetclass,receiverType,caller):
 if not t:return t
 actual=classes.get(fqtype(receiverType,caller));params=[p.split()[0] for p in targetclass.get('typeParameters',[])];args=generic_args(receiverType)
 if actual and actual['fqn']!=targetclass['fqn']:
  ancestry=actual;seen=set()
  while ancestry and ancestry['fqn'] not in seen:
   seen.add(ancestry['fqn']);base=ancestry.get('extends') or ''
   if fqtype(base,ancestry)==targetclass['fqn']:args=generic_args(base);break
   ancestry=classes.get(fqtype(base,ancestry))
 mapping={name:(fqtype(value,caller) if clean(value)==value and value!='?' else value) for name,value in zip(params,args)}
 for name,value in mapping.items():t=re.sub(r'\b'+re.escape(name)+r'\b',value,t)
 return t

def findfield(c,name):
 for f in c['fields']:
  if f['name']==name:return f
 base=classes.get(fqtype(c.get('extends'),c))
 if base:
  field=findfield(base,name)
  if field:return field
 for interface in c.get('implements',[]):
  local=classes.get(fqtype(interface,c))
  if local:
   field=findfield(local,name)
   if field:return field
 return None

def candidates(c,name,arity):
 out=[m for m in c['methods'] if m['name']==name and (len(m['parameters'])==arity or m.get('varargs') and arity>=len(m['parameters'])-1)]
 base=classes.get(fqtype(c.get('extends'),c))
 inherited=(candidates(base,name,arity) if base and name!='<init>' else [])
 for interface in c.get('implements',[]):
  local=classes.get(fqtype(interface,c))
  if local and name!='<init>':inherited+=candidates(local,name,arity)
 return out+inherited

def matching(targets,argtypes):
 if len(targets)<=1:return targets
 boxed={'int':'Integer','long':'Long','boolean':'Boolean','double':'Double','float':'Float','char':'Character','byte':'Byte','short':'Short'}
 scored=[]
 for m in targets:
  score=0;possible=True
  for actual,p in zip(argtypes,m['parameters']):
   a=clean(actual).split('.')[-1];f=clean(p['type']).split('.')[-1]
   if a==f:continue
   if boxed.get(a,a)==boxed.get(f,f):score+=1;continue
   if a in ['?','null']:score+=5;continue
   if f=='Object':score+=3;continue
   if len(f)==1 and f.isupper():score+=2;continue
   if a=='callback' and f in ['Function','Supplier','Predicate','Consumer','BiFunction','BiConsumer','BinaryOperator','UnaryOperator']:score+=2;continue
   actualClass=classes.get(fqtype(a,m['ownerClass']));seen=set();isbase=False
   while actualClass and actualClass['fqn'] not in seen:
    seen.add(actualClass['fqn']);base=clean(actualClass.get('extends'))
    if base.split('.')[-1]==f:isbase=True;break
    actualClass=classes.get(fqtype(base,actualClass))
   if isbase:score+=1;continue
   possible=False;break
  if possible:scored.append((score,m))
 if not scored:return targets
 best=min(score for score,_ in scored);choices=[m for score,m in scored if score==best]
 return choices

# Each declared source object retains fields, inheritance and annotations, with source/wire closure distinct.
shapeids={fq:P+'shape/'+uid(fq) for fq in classes}
schemaGap=add('gap','gap/generated-and-formatters',owner=scope,obligation='generated_and_effective_representation',reason='Source declarations and constraints are available; Lombok-generated accessors/constructors, imported SDK/framework implementations, property binding and effective JSON/Kafka conversion are not present as generated source at this pinned revision.',action='Inspect exact generated/dependency artefacts and effective configuration before claiming runtime or wire closure.',evidence=ev('pom.xml'))
for fq,c in classes.items():
 fields=[];seen=set()
 def fields_of(k):
  base=classes.get(fqtype(k.get('extends'),k))
  return (fields_of(base) if base else [])+[(k,x) for x in k['fields']]
 for owner,f in fields_of(c):
  if f['name'] in seen:continue
  text=f['declaration']['text'];lf=next((x for x in owner['lex'].get('fields',[]) if x['name']==f['name']),{})
  if owner['lex'].get('kind')=='enum' and f['type']==owner['name'] and any(child['kind']=='NEW_CLASS' for child in f['declaration']['children']):continue
  if owner['lex'].get('kind')=='interface' or 'static' in lf.get('modifiers',[]) or re.search(r'\bstatic\b',text) or any(child['kind']=='MODIFIERS' and re.search(r'\bstatic\b',child['text']) for child in f['declaration']['children']):continue
  seen.add(f['name']);field=dict(name=f['name'],type=f['type'],status='declared',evidence=ev(owner['path'],f['declaration']['lines']))
  resolved=fqtype(f['type'],owner)
  if resolved in shapeids and classes[resolved]['lex'].get('kind')!='enum':field['shape']=shapeids[resolved]
  generic=re.fullmatch(r'(?:List|Set|Collection)<(.+)>',f['type'])
  if generic:
   element=fqtype(generic[1],owner)
   if element in shapeids:
    arrayid=add('shape','array/'+uid(fq+'.'+f['name']),representation='constructed',label=f['type']+' source collection',fields=[],container='array',items=shapeids[element],completeness='partial',gaps=[schemaGap],evidence=field['evidence']);field['shape']=arrayid
  if resolved in classes and classes[resolved]['lex'].get('kind')=='enum':
   enum=[x['name'] for x in classes[resolved]['fields'] if x['type']==classes[resolved]['name'] and any(child['kind']=='NEW_CLASS' for child in x['declaration']['children'])]
   if enum:field['enum']=enum
  if (re.search(r'@(?:NonNull|NotNull|NotBlank|NotEmpty)\b',text) and not re.search(r'@(?:NotNull|NotBlank|NotEmpty)\([^)]*groups',text)) or f['type'] in ['int','long','boolean','double','float','short','byte','char']:field['nullable']=False
  size=re.search(r'@Size\([^)]*max\s*=\s*(\d+)',text)
  if size and f['type']=='String':field['maxLength']=int(size[1])
  pat=re.search(r'@Pattern\([^)]*regexp\s*=\s*("(?:[^"\\]|\\.)*")',text)
  if pat:
   try:field['pattern']=json.loads(pat[1])
   except ValueError:pass
  fields.append(field)
 add('shape','shape/'+uid(fq),representation='constructed',label=fq+' source declaration; inherited local fields retained',fields=fields,completeness='partial',gaps=[schemaGap],evidence=ev(c['path']),**({} if c['lex'].get('kind')=='enum' else dict(container='object')))

initializerKeys=[]
# Materialise all explicit methods first so calls retain actual formal parameter identities.
for m in methods.values():
 c=m['ownerClass'];e=ev(c['path'],m['declaration']['lines']);mid=m['impl'];entry=mid+'/entry'
 m['params']=[mid+'/parameter/'+p['name'] for p in m['parameters']];m['receiver']=None if re.search(r'\bstatic\b',m['declaration']['children'][0]['text']) else mid+'/receiver'
 add('implementation','method/'+uid(m['key']),logicalId=m['key'],scope=scope,entry=entry,parameters=m['params'],returnKind='void' if m['returnType'] in [None,'void'] or m['name']=='<init>' else 'value',**(dict(receiver=m['receiver']) if m['receiver'] else {}),evidence=e)
 add('operation','method/'+uid(m['key'])+'/entry',owner=mid,action='entry',label='Enter '+m['key'],resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=e)
 if m['receiver']:add('value',m['receiver'][len(P):],owner=mid,definition=entry,label='Implicit this receiver: '+c['fqn'],role='receiver',representation='constructed',shape=shapeids.get(c['fqn']),evidence=e,accessPath=[])
 # Public client library is a source surface whose consuming runtime host is not established.
 isclient='-adapter/' in c['path'];m['library']=isclient
 if not isclient:m['exec']=add('execution_binding','execution/'+uid(m['key']),implementation=mid,component=host,basis='source_declared',artifactBinding=None,gaps=[],evidence=e)
 for p,pid in zip(m['parameters'],m['params']):
  add('value',pid[len(P):],owner=mid,definition=entry,label=p['name']+': '+p['type'],role='parameter',representation='constructed',shape=shapeids.get(fqtype(p['type'],c)),evidence=e,accessPath=[])

def exception_status(node,c,bindings=None,depth=0):
 if depth>10:return None,[]
 bindings=bindings or {}
 if node['kind']=='NEW_CLASS':
  children=node['children'];typename=next((x['text'] for x in children if x['kind'] in ['IDENTIFIER','PARAMETERIZED_TYPE','MEMBER_SELECT']), '?');idx=next((i for i,x in enumerate(children) if x['text']==typename),0);args=children[idx+1:];target=classes.get(fqtype(typename,c))
  return constructor_status(target,[bindings.get(a['text'],a['text']) for a in args],depth+1)
 return None,[]
def constructor_status(c,args,depth=0):
 if not c or depth>10:return None,[]
 ctors=[m for m in c['methods'] if m['name']=='<init>' and len(m['parameters'])==len(args)]
 if len(ctors)!=1:return None,[]
 m=ctors[0];bound={p['name']:a for p,a in zip(m['parameters'],args)};e=ev(c['path'],m['declaration']['lines'])
 if c['name'] in ['PaymentServiceException','SchedulerException']:
  status=bound.get('statusCode','')
  return (int(status) if re.fullmatch(r'\d{3}',status or '') else None),e
 def walk(n):
  if n['kind']=='METHOD_INVOCATION' and n['children'] and n['children'][0]['text']=='super':return n
  for child in n['children']:
   found=walk(child)
   if found:return found
  return None
 call=walk(m['body']) if m['body'] else None
 if call:
  status,extra=constructor_status(classes.get(fqtype(c.get('extends'),c)),[bound.get(a['text'],a['text']) for a in call['children'][1:]],depth+1);return status,e+extra
 return None,e

class Graph:
 def __init__(self,m):
  self.m=m;self.c=m['ownerClass'];self.owner=m['impl'];self.entry=self.owner+'/entry';self.env={p['name']:(p['type'],pid) for p,pid in zip(m['parameters'],m['params'])};self.last=[self.entry];self.terms=[];self.serial=0;self.calls=[];self.unsupported=[];self.callback=[];self.branch=[];self.callbackHint=None;self.deferred=[];self.callbackObjects={};self.catchSites=[];self.finallySites=[];self.normalResume=set();self.dispatchJoins=[];self.loopContinues=[];self.streamPlans={};self.collectorPlans={};self.builders={};self.constructionRecords=[];self.streamResults=[];self.expectedType=None;self.receiverValue=m.get('receiver') or next((cap['value'] for cap in m.get('captures',[]) if cap['name']=='this'),None)
 def evidence(self,n):return ev(self.c['path'],n['lines'])
 def op(self,n,action,label=None,result=True,exit=None):
  self.serial+=1;key='operation/'+uid(self.m['key'])+'/'+str(self.serial);oid=add('operation',key,owner=self.owner,action=action,label=label or n['text'],resolution=None,bindings=[],result=None,exit=exit,httpStatus=None,evidence=self.evidence(n))
  for prior in self.last:self.edge(prior,oid,'normal')
  self.last=[oid] if action not in ['return','throw'] else []
  if action in ['return','throw']:self.terms.append(oid)
  val=None
  if result:
   val=add('value','value/'+uid(oid),owner=self.owner,definition=oid,label=n['text'],role='constant' if n['kind'].endswith('_LITERAL') else 'definition',representation='constructed',shape=None,evidence=self.evidence(n),accessPath=[]);byid[oid]['result']=val
  return oid,val
 def edge(self,a,b,on='normal',condition=None,values=None):
  if a in self.normalResume and not on.startswith('pending_'):condition='Pending Java completion is normal; '+(condition or 'continue to the next source operation')
  add('transition','transition/'+uid(a+b+on+str(condition)+str(len(records))),owner=self.owner,**{'from':a,'to':b},on=on,condition=condition,values=values or [],evidence=byid[a]['evidence'])
 def flow(self,a,b,oid,text):
  if a and b and a!=b:add('flow','flow/'+uid(str(len(records))+a+b),owner=self.owner,**{'from':a,'to':b},at=oid,transform=text,evidence=byid[oid]['evidence'],gaps=[],assumptions=[])
 def expr(self,n):
  if n is None:return ('?',None)
  k=n['kind'];ch=n['children'];txt=n['text']
  if k=='IDENTIFIER':
   if txt=='this' and self.receiverValue:return self.c['fqn'],self.receiverValue
   if txt in self.env:return self.env[txt]
   fld=findfield(self.c,txt)
   if fld:
    fieldOwner=classes.get(fld.get('sourceOwner'),self.c);decl=fld['declaration'];literal=next((node for node in decl['children'] if node['kind'].endswith('_LITERAL')),None);isconstant=(fieldOwner['lex'].get('kind')=='interface' or re.search(r'\bstatic\s+final\b',decl['text'])) and literal
    oid,v=self.op(n,'compute',('Declared source constant '+txt+' = '+literal['text']) if isconstant else 'Read source field '+txt);byid[oid]['evidence']+=ev(fld.get('sourcePath',self.c['path']),decl['lines']);byid[v]['evidence']=byid[oid]['evidence']
    if isconstant:byid[v]['role']='constant'
    else:self.flow(self.receiverValue,v,oid,'Read declared instance field '+txt)
    return declared_result(fld['type'],classes.get(fld.get('sourceOwner'),self.c),self.c['fqn'],self.c),v
   oid,v=self.op(n,'compute','Source identifier '+txt+'; declared symbol/type resolution retained separately');return txt,v
  if k=='PARENTHESIZED':return self.expr(ch[0])
  if k=='MEMBER_SELECT':
   if fqtype(txt,self.c) in classes:return fqtype(txt,self.c),None
   if re.fullmatch(r'(?:com|org|java)\.[A-Za-z0-9_.]+\.[A-Z][A-Za-z0-9_]*',txt):return txt,None
   t,v=self.expr(ch[0]) if ch else ('?',None);targetclass=classes.get(fqtype(t,self.c),self.c);fld=findfield(targetclass,txt.rsplit('.',1)[-1]);literal=next((node for node in fld['declaration']['children'] if node['kind'].endswith('_LITERAL')),None) if fld else None;fieldOwner=classes.get(fld.get('sourceOwner'),targetclass) if fld else targetclass;isconstant=fld and literal and (fieldOwner['lex'].get('kind')=='interface' or re.search(r'\bstatic\s+final\b',fld['declaration']['text']));oid,out=self.op(n,'compute',('Declared source constant '+txt+' = '+literal['text']) if isconstant else txt)
   if fld:byid[oid]['evidence']+=ev(fld.get('sourcePath',self.c['path']),fld['declaration']['lines']);byid[out]['evidence']=byid[oid]['evidence']
   if isconstant:byid[out]['role']='constant'
   else:self.flow(v,out,oid,'Source member projection '+txt)
   return (fld['type'] if fld else '?'),out
  if k=='INSTANCE_OF' and any(x['kind']=='BINDING_PATTERN' for x in ch):
   typ,operand=self.expr(ch[0]);pattern=next(x for x in ch if x['kind']=='BINDING_PATTERN');variable=pattern['children'][0];recordPattern=re.search(r'UserIdentity\.(VolvoId|Connect|EntraId)\((String|ConnectToken|EntraIdUser)\s+(token|user)\)',raw(self.c['path'])[n['start']:].splitlines()[0])
   if recordPattern:
    variant,declared,name=recordPattern.groups();component='user' if variant=='EntraId' else 'token';oid,test=self.op(n,'compute','Source instanceof UserIdentity.'+variant+' record pattern guard');self.flow(operand,test,oid,'Source instanceof tests original record variant');projection,value=self.op(pattern,'compute','Matched UserIdentity.'+variant+' nested '+declared+' component '+name);byid[value].update(label='Matched UserIdentity.'+variant+' nested '+declared+' component '+name,role='field',accessPath=[component],shape=shapeids.get(fqtype(declared,self.c)));self.flow(operand,value,projection,'Exact original source record deconstruction selects '+component+' only on matching variant; parse surface normalization is not semantic binding');self.env[name]=(declared,value)
   else:
    name=re.search(r'(\w+)\s*$',variable['text'])[1];declared=variable['children'][1]['text'];oid,test=self.op(n,'compute','Source instanceof '+declared+' pattern guard');self.flow(operand,test,oid,'Source instanceof tests actual receiver');projection,value=self.op(pattern,'compute','Matched source pattern variable '+name+': '+declared);self.flow(operand,value,projection,'Source pattern variable aliases this receiver only on successful instanceof guard');self.env[name]=(declared,value)
   return 'boolean',test
  if k=='SWITCH_EXPRESSION':
   typ,selected=self.expr(ch[0]);guard,_=self.op(ch[0],'branch','Select exactly one source switch arm for '+ch[0]['text'],result=False);saved=dict(self.env);arms=[]
   for arm in ch[1:]:
    self.env=dict(saved);self.last=[];before=len(records);pattern=re.search(r'case\s+UserIdentity\.(Connect|EntraId)\((ConnectToken|EntraIdUser)\s+(token|user)\)',arm['text'])
    if pattern:
     variant,componentType,componentName=pattern.groups();project,pv=self.op(arm,'compute','Matched UserIdentity.'+variant+' nested '+componentType+' component '+componentName);byid[pv].update(label='Matched UserIdentity.'+variant+' nested '+componentType+' component '+componentName,role='field',accessPath=['user' if variant=='EntraId' else 'token'],shape=shapeids.get(fqtype(componentType,self.c)));self.flow(selected,pv,project,'Original record switch deconstruction only for this matching source variant');self.env[componentName]=(componentType,pv)
    atype,value=self.expr(arm['children'][-1]);first=next(r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner);ends=self.last[:];labels=arm['text'].split('->',1)[0];arms.append((first,ends,value,atype,labels))
   self.last=[];join,out=self.op(n,'compute','Join source switch expression selected value');self.env=saved
   for first,ends,value,atype,labels in arms:
    self.edge(guard,first,'case',labels,[selected] if selected else []);self.flow(value,out,join,'Only source switch case '+labels+' contributes this value')
    for end in ends:self.edge(end,join)
   return (arms[0][3] if all(a[3]==arms[0][3] for a in arms) else '?'),out
  if k=='METHOD_INVOCATION':
   # Javac traversal: optional type arguments precede method select; identify it by source '(' position.
   select=next((x for x in ch if x['kind'] in ['IDENTIFIER','MEMBER_SELECT'] and x['start']==n['start']),None)
   if select is None:select=ch[0]
   at=ch.index(select);args=ch[at+1:];name=re.search(r'([A-Za-z_$][\w$]*)\s*$',select['text'])[1];receiver=None;rt=self.c['fqn'];rv=self.receiverValue
   if select['kind']=='MEMBER_SELECT':
    receiver=select['children'][0];rt,rv=self.expr(receiver)
    if receiver['text']=='this':rt=self.c['fqn']
    if receiver['text']=='super':rt=self.c.get('extends') or '?'
   av=[]
   for argumentIndex,argument in enumerate(args):
    self.callbackHint=self.element(rt)
    if rt=='Collectors' and name=='toMap' and argumentIndex==2:
     expected=self.expectedType or self.m.get('returnType') or '';match=re.fullmatch(r'Map<[^,]+,\s*(.+)>',expected)
     if match:self.callbackHint=match[1]
    av.append(self.expr(argument))
   if receiver is None and not candidates(self.c,name,len(args)):
    imported=next((im for im in self.c['file']['imports'] if im.endswith('.'+name) and name[:1].islower()),None)
    if imported:rt=imported.rsplit('.',1)[0];rv=None
   self.callbackHint=None;targetclass=classes.get(fqtype(rt,self.c));name='<init>' if name in ['super','this'] else name;targetclass=classes.get(fqtype(self.c.get('extends'),self.c)) if select['text']=='super' else targetclass;opts=matching(candidates(targetclass,name,len(args)),[x[0] for x in av]) if targetclass else []
   target=opts[0] if len(opts)==1 and opts[0]['body'] else None
   if target is None and receiver is None and '.' in self.c['name']:
    outer=classes.get(self.c['fqn'].rsplit('.',1)[0]);outerCandidates=matching([m for m in candidates(outer,name,len(args)) if m.get('receiver') is None],[x[0] for x in av]) if outer else []
    if len(outerCandidates)==1 and outerCandidates[0]['body']:target=outerCandidates[0]
   if False:
    # TransactionRepository extends CustomTransactionRepository; the one local fragment implements it.
    fragment=[m for m in methods.values() if m['ownerClass']['name']=='CustomTransactionRepositoryImpl' and m['name']=='partialUpdate']
    if len(fragment)==1:target=fragment[0]
   dispatchGuard=None;dispatchTargets=[];dispatchCommon=target or (opts[0] if len(opts)==1 else None);dispatchReceiver=rv or self.receiverValue;receiverBase=clean(rt).split('.')[-1];dispatchPolicy=None
   localChoices=[]
   if target is None and targetclass and targetclass['name'] in ['EntityFactory','Mapper']:
    localChoices=[(c['name'],name,'Only if this invocation receiver is source subclass '+c['fqn']) for c in classes.values() if clean(c.get('extends')).split('.')[-1]==targetclass['name'] and any(m['name']==name and len(m['parameters'])==len(args) and m['body'] for m in c['methods'])];dispatchPolicy='available source subclasses overriding '+targetclass['fqn']+'.'+name+'; actual receiver/context and imported/generated wiring remain conditional'
   if receiverBase in ['CustomerArchiveRepository','CustomerArchiveUpsertRepository'] and name=='upsertCustomerArchive':localChoices=[('CustomerArchiveUpsertRepositoryImpl',name,'Only if Spring Data binds this declared repository fragment to the available matching Impl')];dispatchPolicy='local interface plus matching source Spring Data fragment declaration; framework fragment activation unresolved'
   if localChoices:
    for owner,methodName,condition in localChoices:
     choices=[method for method in methods.values() if method['ownerClass']['name']==owner and method['name']==methodName and len(method['parameters'])==len(args) and method['body']]
     assert len(choices)==1,(owner,methodName)
     dispatchTargets.append((choices[0],condition))
    target=dispatchTargets[0][0];dispatchGuard,_=self.op(n,'branch','Select source conditional virtual/delegate target: '+dispatchPolicy,result=False);self.last=[]
   callActuals=[a[1] or self.constant(arg) for a,arg in zip(av,args)]
   if target and target.get('varargs'):
    fixed=len(target['params'])-1;packed,packValue=self.op(n,'compute','Pack exact source Java varargs operands for '+target['name']);
    for index,actual in enumerate(callActuals[fixed:]):
     field=add('value','vararg-item/'+uid(packed+str(index)),owner=self.owner,definition=packed,label='Source Java varargs element '+str(index),role='field',representation='constructed',shape=byid[actual].get('shape'),evidence=self.evidence(n),accessPath=[str(index)]);self.flow(actual,field,packed,'Exact Java source variable-arity invocation operand '+str(index));self.flow(field,packValue,packed,'Source Java implicit varargs array construction')
    callActuals=callActuals[:fixed]+[packValue]
   oid,v=self.op(n,'call');resolution=add('resolution','resolution/'+uid(oid),owner=self.owner,requestedArtifact=None,basis='source_local' if target else 'unresolved',target=target['impl'] if target else None,binding=None,candidates=[o['impl'] for o in opts] if not target else [],evidence=self.evidence(n));byid[oid]['resolution']=resolution
   if target and target.get('receiver'):byid[oid]['receiver']=rv or self.receiverValue
   elif rv and receiver and (receiver['kind']!='IDENTIFIER' or receiver['text'] in self.env or findfield(self.c,receiver['text'])):byid[oid]['receiver']=rv
   if target:byid[oid]['bindings']=[dict(parameter=p,value=actual) for p,actual in zip(target['params'],callActuals)]
   if dispatchGuard:
    firstResult=v;choices=[(oid,v,dispatchTargets[0][0],dispatchTargets[0][1])]
    if target.get('receiver'):byid[oid]['receiver']=dispatchReceiver
    self.edge(dispatchGuard,oid,'source_target',dispatchTargets[0][1]);self.last=[]
    for alternative,condition in dispatchTargets[1:]:
     invoke,value=self.op(n,'call',n['text']+' [conditional source target '+alternative['key']+']');resolutionId=add('resolution','resolution/'+uid(invoke),owner=self.owner,requestedArtifact=None,basis='source_local',target=alternative['impl'],binding=None,candidates=[],evidence=self.evidence(n));byid[invoke].update(resolution=resolutionId,bindings=[dict(parameter=parameter,value=actual[1] or self.constant(argument)) for parameter,actual,argument in zip(alternative['params'],av,args)])
     if alternative.get('receiver'):byid[invoke]['receiver']=dispatchReceiver
     self.edge(dispatchGuard,invoke,'source_target',condition);choices.append((invoke,value,alternative,condition));self.last=[]
    unknown=None
    if receiverBase!='Function':
     unknown,unknownValue=self.op(n,'opaque','Other framework/runtime receiver correspondence remains unresolved');self.edge(dispatchGuard,unknown,'other_receiver','Effective receiver does not match the source factory/fragment correspondence');self.last=[]
    join,v=self.op(n,'compute','Join guarded source call alternatives for '+name)
    for invoke,value,alternative,condition in choices:self.edge(invoke,join,'normal',condition);self.flow(value,v,join,'Source guarded dispatch alternative '+condition)
    if unknown:self.edge(unknown,join,'normal','Unresolved other receiver returned an unknown result');self.flow(unknownValue,v,join,'Unresolved other receiver result')
    self.dispatchJoins.append(dict(value=v,values=[value for _,value,_,_ in choices],operation=join))
    add('claim','dispatch/'+uid(oid),owner=self.owner,statement='This actual source invocation selects a conditional concrete receiver/delegate from '+dispatchPolicy+'. Arguments evaluate once, each helper keeps its real receiver and formal bindings, and the separate alternatives are not eager invocations of every helper.',basis='source_traced',inputs=[dispatchGuard,join]+[invoke for invoke,_,_,_ in choices]+[alternative['impl'] for _,_,alternative,_ in choices]+([rv] if rv else [])+[actual[1] for actual in av if actual[1]],assumptions=['Factory/fragment/framework correspondence and runtime argument subtype compatibility remain conditional; heap/guard feasibility is not inferred'],evidence=self.evidence(n)+[e for _,_,alternative,_ in choices for e in ev(alternative['ownerClass']['path'],alternative['declaration']['lines'])])
   # Formal/actual bindings carry proven local lineage. An arbitrary callee result is not inferred from arguments.
   typ=declared_result(dispatchCommon['returnType'],dispatchCommon['ownerClass'],rt,self.c) if dispatchGuard and dispatchCommon else declared_result(target['returnType'],target['ownerClass'],rt,self.c) if target else declared_result(opts[0]['returnType'],opts[0]['ownerClass'],rt,self.c) if len(opts)==1 else '?'
   # Source member declarations establish accessor candidate types, not generated implementations.
   if typ=='?' and targetclass:
    fld=findfield(targetclass,name[3:4].lower()+name[4:] if name.startswith('get') else name[2:3].lower()+name[3:] if name.startswith('is') else name[3:4].lower()+name[4:] if name.startswith('set') else name)
    if not fld and name.startswith(('get','is','set')):
     member=name[3:] if name.startswith(('get','set')) else name[2:];fld=findfield(targetclass,member)
    if fld:typ=declared_result(fld['type'],classes.get(fld.get('sourceOwner'),targetclass),rt,self.c)
    if False and fld and name.startswith('set'):typ=fld.get('sourceOwner',rt) # lombok.config declares accessors.chain=true; generated implementation remains a gap
    if name=='builder':typ=targetclass['fqn']+'Builder'
   if name in ['builder','toBuilder'] and not targetclass:typ=rt+'Builder'
   if name=='toBuilder' and targetclass:typ=targetclass['fqn']+'Builder'
   if name=='apply' and rt.startswith('Function<'):typ=rt[rt.rfind(',')+1:rt.rfind('>')].strip()
   if name=='values' and targetclass and targetclass['lex'].get('kind')=='enum':typ=rt+'[]'
   if rt=='Stream' and name in ['of','ofNullable']:typ='Stream<'+(av[0][0] if av else '?')+'>'
   if rt=='Optional' and name in ['of','ofNullable']:typ='Optional<'+(av[0][0] if av else '?')+'>'
   if rt.startswith('Optional<') and name in ['or','filter']:typ=rt
   if rt=='String' and name in ['split']:typ='String[]'
   if rt in ['String','Object'] and name in ['trim','toLowerCase','toUpperCase','toString','substring']:typ='String'
   if rt=='String' and name=='valueOf':typ='String'
   if rt=='Arrays' and name=='stream':typ='Stream<'+(self.element(av[0][0]) if av else '?')+'>'
   if not target and clean(rt).endswith('Builder'):typ=(self.expectedType or clean(rt)[:-7]) if name=='build' else rt
   if name in ['stream','parallelStream'] and rt not in ['Arrays','Stream']:typ='Stream<'+self.element(rt)+'>'
   if name in ['get','getFirst','getLast','orElse','orElseGet','orElseThrow','findFirst','findAny','max','min','reduce'] and '<' in rt:typ=self.element(rt) if name not in ['findFirst','findAny','max','min','reduce'] else 'Optional<'+self.element(rt)+'>'
   if name in ['map','filter','flatMap','distinct','sorted','peek','collect','toList'] and '<' in rt:
    typ=rt
    if name=='toList':typ='List<'+self.element(rt)+'>'
   mapargs=self.genericArgs(rt)
   if clean(rt).split('.')[-1] in ['Map','LinkedHashMap'] and len(mapargs)==2:
    if name in ['get','getOrDefault']:typ=mapargs[1]
    if name=='keySet':typ='Set<'+mapargs[0]+'>'
    if name=='values':typ='Collection<'+mapargs[1]+'>'
   if clean(rt).split('.')[-1]=='SwaggerUIConfig' and name=='getSettings':typ='Map<String,Object>'
   if rt=='ResponseEntity' and name=='status':typ='ResponseEntity.BodyBuilder'
   if rt=='ResponseEntity.BodyBuilder' and name=='body':typ='ResponseEntity<String>'
   # Source uses known named imported projections; exact artefact contracts remain a gap.
   receiverBase=clean(rt).split('.')[-1]
   if receiverBase=='Objects' and name=='requireNonNull' and av:typ=av[0][0]
   if receiverBase=='Event' and '<' in rt and name=='getPayload':typ=self.element(rt)
   if receiverBase=='Event' and name=='getMetadata':typ='Metadata'
   if receiverBase=='PspInboundEventPayload' and name=='getAdditionalParameters':typ='Map<String,Object>'
   if receiverBase in ['PspInboundEventPayload','Metadata'] and name in ['getId','getType','getCorrelationId']:typ='String'
   if fqtype(rt,self.c)=='com.stripe.model.Event' and name=='getDataObjectDeserializer':typ='EventDataObjectDeserializer'
   if receiverBase=='EventDataObjectDeserializer' and name=='getObject':typ='Optional<StripeObject>'
   if receiverBase in ['StripeObject','EventDataObjectDeserializer'] and name in ['toJson','getRawJson']:typ='String'
   byid[v]['shape']=shapeids.get(fqtype(typ,self.c))
   if not target and rt in ['SuccessResponse','ResponseEntity']:
    sid=add('shape','boundary-result/'+uid(oid),representation='constructed',label=rt+'.'+name+' whole source factory/client result; distinct from data/getData argument or projection',fields=[],completeness='partial',gaps=[schemaGap],evidence=self.evidence(n));byid[v]['shape']=sid
   item=dict(owner=self.m['key'],path=self.c['path'],lines=n['lines'],operation=oid,receiver=receiver['text'] if receiver else 'this',receiverType=rt,name=name,argumentTypes=[a[0] for a in av],arguments=[a['text'] for a in args],argumentValues=[a[1] for a in av],resultValue=v,resolution='source_local' if target else 'unresolved',target=target['key'] if target else None,candidates=[o['key'] for o in opts] if not target else [],returnType=typ)
   # A source fluent builder establishes caller construction intent, not SDK wire fields.
   if name in ['builder','toBuilder']:self.builders[v]=dict(type=fqtype(rt,self.c),fields=[],**(dict(base=rv) if name=='toBuilder' else {}))
   if rt=='ResponseEntity' and name=='status' and len(av)==1:self.builders[v]=dict(type='ResponseEntity<String>',fields=[dict(name='status',value=av[0][1],type=av[0][0],expression=args[0]['text'],evidence=self.evidence(n))])
   if rv in self.builders:
    construction=self.builders[rv]
    if name=='build' or rt=='ResponseEntity.BodyBuilder' and name=='body':
     if name=='build' and target:construction['type']=fqtype(target['returnType'],target['ownerClass'])
     if name=='body':construction=dict(type=construction['type'],fields=construction['fields']+[dict(name='body',value=av[0][1],type=av[0][0],expression=args[0]['text'],evidence=self.evidence(n))])
     fs=[]
     for member in construction['fields']:
      arg=member['value'];af=byid[arg] if arg else None;f=dict(name=member['name'],type=member['type'],status='declared',evidence=member['evidence'])
      if af and af.get('shape'):f['shape']=af['shape']
      product=classes.get(construction['type']);declaredField=findfield(product,member['name']) if product else None
      if declaredField:
       f['type']=declaredField['type'];f['evidence']+=ev(declaredField.get('sourcePath',product['path']),declaredField['declaration']['lines'])
       if declaredField['type'] in ['int','long','boolean','double','float','short','byte','char']:f['nullable']=False
      declaredType=classes.get(fqtype(member['type'],self.c))
      if declaredType and declaredType['lex'].get('kind')=='enum':
       enum=[x['name'] for x in declaredType['fields'] if x['type']==declaredType['name'] and any(child['kind']=='NEW_CLASS' for child in x['declaration']['children'])]
       if enum:f['enum']=enum
      try:
       literal=json.loads(member['expression'])
       if isinstance(literal,(str,int,float,bool)) or literal is None:f['const']=literal
      except (ValueError,TypeError):pass
      fs=[old for old in fs if old['name']!=f['name']]+[f]
     sid=add('shape','construction/'+uid(oid),representation='constructed',label=construction['type']+' explicit caller construction and source setter intent; SDK/wire declaration is separate',fields=fs,completeness='partial',gaps=[schemaGap],evidence=self.evidence(n),container='object');byid[v]['shape']=sid;self.constructionRecords.append(dict(shape=sid,fields=construction['fields']))
     if construction.get('base'):
      add('flow','caller-clone-base/'+uid(oid),owner=self.owner,**{'from':construction['base'],'to':v},at=oid,transform='Explicit caller toBuilder source clone intent; copied unknown members are not invented as fields',evidence=self.evidence(n),gaps=[schemaGap],assumptions=['Imported/generated toBuilder follows source caller clone intent; no automatic mutable heap version proof'])
     for member in construction['fields']:
      if not member['value']:continue
      fv=add('value','construction-field/'+uid(oid+member['name']+str(member['value'])),owner=self.owner,definition=oid,label='Caller intended '+construction['type']+'.'+member['name'],role='field',representation='constructed',shape=byid[member['value']]['shape'],evidence=member['evidence'],accessPath=[member['name']])
      add('flow','construction-input/'+uid(fv),owner=self.owner,**{'from':member['value'],'to':fv},at=oid,transform='Explicit caller builder setter .'+member['name']+'('+member['expression']+'); exact generated/imported builder execution remains a boundary',evidence=member['evidence'],gaps=[schemaGap],assumptions=['Fluent builder preserves the source-declared setter intent; no HTTP placement or unknown SDK members are inferred'])
      add('flow','construction-member/'+uid(fv),owner=self.owner,**{'from':fv,'to':v},at=oid,transform='Caller construction member '+member['name'],evidence=member['evidence'],gaps=[schemaGap],assumptions=['This shape describes the explicit caller construction only'])
    elif len(av)==1:
     self.builders[v]=dict(type=construction['type'],**(dict(base=construction['base']) if construction.get('base') else {}),fields=construction['fields']+[dict(name=name,value=av[0][1],type=target['parameters'][0]['type'] if target and target['parameters'] else av[0][0],expression=args[0]['text'],evidence=self.evidence(n))])
   if rv and name.startswith('set') and len(av)==1 and byid[rv].get('shape') and '/construction/' in byid[rv]['shape']:
    member=name[3:4].lower()+name[4:];argument=av[0][1];shape=byid[byid[rv]['shape']];field=dict(name=member,type=av[0][0],status='declared',evidence=self.evidence(n))
    if argument and byid[argument].get('shape'):field['shape']=byid[argument]['shape']
    shape['fields']=[f for f in shape['fields'] if f['name']!=member]+[field]
    if argument:
     fv=add('value','source-setter-field/'+uid(oid),owner=self.owner,definition=oid,label='Caller source setter intent '+member,role='field',representation='constructed',shape=byid[argument].get('shape'),evidence=self.evidence(n),accessPath=[member])
     add('flow','source-setter-input/'+uid(oid),owner=self.owner,**{'from':argument,'to':fv},at=oid,transform='Source setter '+name+'('+args[0]['text']+'); field intent only, exact imported/generated implementation unresolved',evidence=self.evidence(n),gaps=[schemaGap],assumptions=['Source setter follows its declared caller intent'])
     add('flow','source-setter-object/'+uid(oid),owner=self.owner,**{'from':fv,'to':rv},at=oid,transform='Source setter mutates this explicitly constructed object reference; no automatic heap-version proof',evidence=self.evidence(n),gaps=[schemaGap],assumptions=['The referenced caller source setter returns normally'])
   if rv and name.startswith('set') and len(av)==1 and targetclass:
    member=name[3:4].lower()+name[4:];field=findfield(targetclass,member) or findfield(targetclass,name[3:])
    if field and target is None:
     actual=av[0][1];fv=add('value','declared-setter/'+uid(oid),owner=self.owner,definition=oid,label='Source declared setter intent '+member,role='field',representation='constructed',shape=byid[actual].get('shape') if actual else None,evidence=self.evidence(n)+ev(field.get('sourcePath',targetclass['path']),field['declaration']['lines']),accessPath=[field['name']]);self.flow(actual,fv,oid,'Source setter argument for declared field '+field['name']);self.flow(fv,rv,oid,'Source setter field mutation intent on this same object; mutable heap versions are not inferred');self.flow(rv,v,oid,'Source lombok.config accessors.chain=true returns receiver intent; generated implementation and alias effects remain a boundary');byid[v]['shape']=byid[rv].get('shape')
   # Exact source projection intentions and arithmetic are narrower than arbitrary call-result inference.
   if rv and target is None and targetclass and (name.startswith(('get','is')) or findfield(targetclass,name)) and not args:
    member=name[3:4].lower()+name[4:] if name.startswith('get') else name[2:3].lower()+name[3:] if name.startswith('is') else name;declared=findfield(targetclass,member) or findfield(targetclass,name[3:] if name.startswith('get') else name[2:] if name.startswith('is') else name)
    if declared:
     byid[v].update(role='field',accessPath=[member],shape=shapeids.get(fqtype(declared['type'],targetclass)))
     add('flow','source-accessor/'+uid(oid),owner=self.owner,**{'from':rv,'to':v},at=oid,transform='Source accessor projection '+member+' from the local declared field; exact generated accessor implementation is unresolved',evidence=self.evidence(n)+ev(declared.get('sourcePath',targetclass['path']),declared['declaration']['lines']),gaps=[schemaGap],assumptions=['Generated accessor follows the local declaration and source call name'])
   if clean(rt).split('.')[-1]=='BigDecimal' and name in ['add','subtract','multiply','divide','compareTo']:
    for operand in [rv]+[a[1] for a in av]:
     if operand:add('flow','source-arithmetic/'+uid(oid+operand),owner=self.owner,**{'from':operand,'to':v},at=oid,transform='Source BigDecimal.'+name+' operand; source arithmetic/result use retained',evidence=self.evidence(n),gaps=[schemaGap],assumptions=['JDK arithmetic operation returns normally; exact implementation and exceptional inputs remain a boundary'])
   if rt=='SuccessResponse':
    for i,(_,a) in enumerate(av):
     if a:add('flow','factory-flow/'+uid(oid+str(i)),owner=self.owner,**{'from':a,'to':v},at=oid,transform='Actual response factory argument '+str(i)+'; whole factory result is distinct and exact member placement remains unresolved',evidence=self.evidence(n),gaps=[schemaGap],assumptions=['Imported response factory mapping is not expanded; this preserves argument/result association only'])
   if name=='getData' and '<' in rt:typ=self.element(rt)
   if name=='getData' and rv:add('flow','wrapper-projection/'+uid(oid),owner=self.owner,**{'from':rv,'to':v},at=oid,transform='Source getData() use selects the returned inner value from the distinct whole wrapper; exact imported implementation remains unresolved',evidence=self.evidence(n),gaps=[schemaGap],assumptions=['Exact imported getData implementation is not expanded'])
   if rt=='Optional' and name in ['of','ofNullable'] and av:
    self.flow(av[0][1],v,oid,'Source Optional factory stores its actual nullable/present input')
   if rt.startswith('Optional<') and name in ['get','orElse','orElseGet','orElseThrow','or','map','filter','flatMap']:
    self.flow(rv,v,oid,'Source Optional '+name+' selected present/absent result under its corresponding condition; exact JDK invocation returns normally')
    if name=='orElse' and av:self.flow(av[0][1],v,oid,'Source Optional.orElse fallback only if empty; argument evaluation itself is eager')
   if clean(rt).split('.')[-1] in ['String','Object','Boolean','Class','Objects','Map','EnumSet','Set','List','Collection'] and name in ['toString','toLowerCase','toUpperCase','trim','split','substring','valueOf','parseBoolean','cast','isNull','nonNull','isEmpty','contains','containsKey','equals','equalsIgnoreCase']:
    for actual in ([rv] if rv else [])+[a[1] for a in av if a[1]]:
     self.flow(actual,v,oid,'Source named JDK scalar/selection operation '+name+' consumes this actual value; exact runtime input and exceptional semantics remain unresolved')
   self.calls.append(item);audit.append(item)
   # Preserve lazy stream registration and invoke available local callback bodies at a terminal traversal.
   callbacks=[(i,self.callbackObjects.get(a[1])) for i,a in enumerate(av) if a[1] in self.callbackObjects]
   optional=rt.startswith('Optional<');stream=rt.startswith('Stream<') or (receiver is not None and '.stream()' in receiver['text']) or (name=='forEach' and '<' in rt)
   if name=='map' and callbacks:
    returned=callbacks[0][1].get('returnType')
    if returned:typ=('Optional<' if optional else 'Stream<')+returned+'>' if optional or stream else typ
   if optional and name=='flatMap' and callbacks and callbacks[0][1].get('returnType','').startswith('Optional<'):typ=callbacks[0][1]['returnType']
   if name=='flatMap' and any(a['kind']=='MEMBER_REFERENCE' and a['text'] in ['List::stream','Collection::stream'] for a in args):typ='Stream<'+self.element(self.element(rt))+'>'
   item['returnType']=typ
   if rt=='Collectors' and callbacks:self.collectorPlans[v]=[(('merge_key' if i==2 else 'key_mapper' if i==0 else 'value_mapper'),lm) for i,lm in callbacks]
   inherited=list(self.streamPlans.get(rv,[]))
   if stream and name in ['map','flatMap','filter','peek','sorted','distinct']:
    self.streamPlans[v]=inherited+[(name,lm) for _,lm in callbacks]
    self.flow(rv,v,oid,'Register lazy stream stage '+name+'; callback creation does not invoke it')
   terminal=stream and name in ['toList','collect','findFirst','findAny','anyMatch','allMatch','noneMatch','forEach','reduce','max','min','count']
   if terminal and name in ['max','min','reduce','findFirst','findAny']:
    self.flow(rv,v,oid,'Source Stream.'+name+' selects/accumulates accepted source elements into Optional; zero elements gives empty. Comparator/reducer selection is retained by the actual source argument expression '+', '.join(argument['text'] for argument in args))
    if name in ['max','min']:
     add('claim','comparator-policy/'+uid(oid),owner=self.owner,statement='Source '+n['text']+' selects the '+('maximum' if name=='max' else 'minimum')+' accepted stream element by this exact Comparator expression. In the retry-history helper, the key is RecurringChargeStatePayload.getAttemptedAt. This selected history element is distinct from response.getLastRecurringChargeState used later by notification construction.',basis='source_traced',inputs=[oid]+([rv] if rv else [])+[actual[1] for actual in av if actual[1]],assumptions=['JDK comparator/stream execution returns normally; imported selector implementation, null keys and implicit failures remain unresolved'],evidence=self.evidence(n))
   if terminal:
    stages=inherited+[(name,lm) for _,lm in callbacks]
    for _,a in av:stages+=self.collectorPlans.get(a,[])
    if name in ['toList','collect']:self.streamResults.append(dict(value=v,stages=stages,operation=oid))
    if stages:
     guard,_=self.op(n,'branch','Terminal '+name+' traverses source stream lazily; empty/exhausted and short-circuit paths skip remaining visits',result=False)
     self.last=[];elementop,element=self.op(n,'compute','Select next source stream element for this terminal traversal');self.flow(rv,element,elementop,'Terminal traversal selects a source element from the registered pipeline');self.edge(guard,elementop,'element','Next element is visited')
     previousElement=element;activeGuard=guard;terminalPredicate=None
     for stage,lm in stages:
      branch=None
      if stage in ['merge_key','reduce']:branch,_=self.op(n,'branch','Collector invokes merger only when source key already exists' if stage=='merge_key' else 'Source reduce uses first accepted element as initial accumulator; invokes binary reducer only for a subsequent accepted element',result=False)
      receiverActual=lm.get('boundReceiver');args=[]
      if lm.get('unboundReceiver'):receiverActual=previousElement
      for i,formal in enumerate(lm['parameters']):
       if stage=='reduce':
        if i==1:args.append(previousElement)
        else:
         accumulator,pv=self.op(n,'compute','Select source reduction accumulator from earlier accepted elements');self.flow(rv,pv,accumulator,'Current source reduce accumulator from earlier accepted stream elements');args.append(pv)
       elif i==0 and stage!='merge_key':args.append(previousElement)
       else:
        projection,pv=self.op(n,'compute','Select '+('existing mapped value' if i==0 else 'new mapped value')+' for callback '+formal['name']);self.flow(previousElement,pv,projection,'Collector duplicate-key mapped pricing/value selection');args.append(pv)
      invoke,cbv=self.op(n,'call','Terminal '+name+' invokes source '+stage+' callback '+lm['key'])
      rid=add('resolution','resolution/'+uid(invoke),owner=self.owner,requestedArtifact=None,basis='unresolved' if lm.get('referenceExternal') else 'source_local',target=None if lm.get('referenceExternal') else lm['impl'],binding=None,candidates=[lm['impl']] if lm.get('referenceExternal') and lm.get('impl') else [],evidence=self.evidence(n));byid[invoke].update(resolution=rid,bindings=[] if lm.get('referenceExternal') else [dict(parameter=p,value=a) for p,a in zip(lm['params'],args)],captureBindings=[dict(capture=cap['value'],value=cap['actual'],mode='value') for cap in lm.get('captures',[])])
      if lm.get('receiver'):byid[invoke]['receiver']=receiverActual
      if lm.get('referenceExternal'):
       audit.append(dict(owner=self.m['key'],path=self.c['path'],lines=n['lines'],operation=invoke,receiver='bound method-reference receiver',receiverType=lm['referenceReceiverType'],name=lm['referenceName'],argumentTypes=[p['type'] for p in lm['parameters']],arguments=[p['name'] for p in lm['parameters']],argumentValues=args,resultValue=cbv,resolution='unresolved',target=None,candidates=[lm['key']] if lm.get('impl') else [],returnType=lm.get('returnType','?')))
      item.setdefault('callbackInvocations',[]).append(dict(implementation=lm['impl'],operation=invoke,condition='terminal traversal '+stage))
      if stage=='filter' or stage in ['anyMatch','allMatch','noneMatch']:
       choice,_=self.op(n,'branch','Source callback predicate controls '+stage,result=False)
       if stage=='filter':self.edge(choice,activeGuard,'false','Filter rejects this element',[cbv]);self.last=[];nextop,_=self.op(n,'compute','Filter accepts element',result=False);self.edge(choice,nextop,'true','Filter accepts this element',[cbv])
       else:terminalPredicate=(choice,cbv,stage)
      if stage in ['map','value_mapper','merge_key','reduce']:previousElement=cbv
      if stage=='flatMap':
       nestedGuard,_=self.op(n,'branch','Flat-map visits elements in returned source stream',result=False);self.edge(nestedGuard,activeGuard,'exhausted','Returned source stream has no next element');self.last=[];nestedElementOp,nestedElement=self.op(n,'compute','Select next flattened source element');self.flow(cbv,nestedElement,nestedElementOp,'Select source element from flat-map callback returned stream');self.edge(nestedGuard,nestedElementOp,'element','Returned stream has next element');activeGuard=nestedGuard;previousElement=nestedElement
      if branch:
       after,_=self.op(n,'compute','Continue after conditional collector/reduction callback',result=False);self.edge(branch,after,'first_element' if stage=='reduce' else 'new_key','First accepted element initializes accumulator without invoking reducer' if stage=='reduce' else 'No existing key; merger skipped')
     ends=self.last[:];self.last=[];join,_=self.op(n,'compute','Terminal '+name+' completes source stream result',result=False);self.edge(guard,join,'exhausted','No next visited element')
     for end in ends:
      if terminalPredicate and end==terminalPredicate[0]:
       predicateValue=terminalPredicate[1];settle='false' if name=='allMatch' else 'true';continueOn='true' if name=='allMatch' else 'false';self.edge(end,activeGuard,continueOn,'Predicate does not settle '+name,[predicateValue]);self.edge(end,join,settle,'Predicate settles '+name,[predicateValue])
      elif name in ['findFirst','findAny']:self.edge(end,join,'selected','First accepted source element settles Optional result')
      else:self.edge(end,activeGuard,'next','Visit the next source element')
   if optional and name in ['map','flatMap','filter','ifPresent','ifPresentOrElse','orElseGet','orElseThrow','or'] and callbacks:
    branch,_=self.op(n,'branch','Conditional Optional '+name+' callback invocation',result=False);allends=[]
    for index,lm in callbacks:
     self.last=[];argvals=[];receiverActual=lm.get('boundReceiver')
     if lm.get('unboundReceiver'):
      receiverProjection,receiverActual=self.op(n,'compute','Selected Optional value becomes instance-method receiver');self.flow(rv,receiverActual,receiverProjection,'Source unbound instance method reference receiver')
     for formal in lm['parameters']:
      projection,pv=self.op(n,'compute','Present Optional value for callback formal '+formal['name']);self.flow(rv,pv,projection,'Optional present value selected conditionally');argvals.append(pv)
     invoke,cbv=self.op(n,'call','Invoke Optional callback only when '+('empty' if name in ['orElseGet','orElseThrow','or'] or index==1 else 'present')+': '+lm['key'])
     resolution=add('resolution','resolution/'+uid(invoke),owner=self.owner,requestedArtifact=None,basis='unresolved' if lm.get('referenceExternal') else 'source_local',target=None if lm.get('referenceExternal') else lm['impl'],binding=None,candidates=[lm['impl']] if lm.get('referenceExternal') and lm.get('impl') else [],evidence=self.evidence(n));byid[invoke].update(resolution=resolution,bindings=[] if lm.get('referenceExternal') else [dict(parameter=p,value=a) for p,a in zip(lm['params'],argvals)],captureBindings=[dict(capture=cap['value'],value=cap['actual'],mode='value') for cap in lm.get('captures',[])])
     if lm.get('receiver'):byid[invoke]['receiver']=receiverActual
     if lm.get('referenceExternal'):
      audit.append(dict(owner=self.m['key'],path=self.c['path'],lines=n['lines'],operation=invoke,receiver='bound method-reference receiver',receiverType=lm['referenceReceiverType'],name=lm['referenceName'],argumentTypes=[p['type'] for p in lm['parameters']],arguments=[p['name'] for p in lm['parameters']],argumentValues=argvals,resultValue=cbv,resolution='unresolved',target=None,candidates=[lm['key']] if lm.get('impl') else [],returnType=lm.get('returnType','?')))
     first=byid[receiverActual]['definition'] if lm.get('unboundReceiver') else byid[argvals[0]]['definition'] if argvals else invoke
     condition='absent' if name in ['orElseGet','orElseThrow','or'] or index==1 else 'present';self.edge(branch,first,'callback',condition)
     if name=='orElseThrow':
      sourceBody=lm.get('body',{});constructed=re.search(r'\bnew\s+(\w+Exception)\s*\(',sourceBody.get('text',''));exitcode=constructed[1] if constructed else 'SupplierException'
      thrown,_=self.op(n,'throw','Optional.orElseThrow throws the source supplier exception object',result=False,exit=exitcode);byid[thrown]['result']=cbv
     else:allends.extend(self.last)
     self.flow(cbv,v,invoke,'Conditional callback result is consumed by Optional '+name)
     item.setdefault('callbackInvocations',[]).append(dict(implementation=lm['impl'],operation=invoke,condition=condition))
    self.last=[];join,_=self.op(n,'compute','Continue after conditional Optional '+name+' callback',result=False)
    if name!='ifPresentOrElse' or len(callbacks)!=2:self.edge(branch,join,'skip_callback','Opposite Optional condition')
    for end in allends:self.edge(end,join)
   if receiverBase=='Objects' and name=='requireNonNull' and av:
    self.flow(av[0][1],v,oid,'Source Objects.requireNonNull returns the same non-null input or throws');guard,_=self.op(n,'branch','Objects.requireNonNull tests the actual source input',result=False);self.last=[];thrown,_=self.op(n,'throw','Objects.requireNonNull throws NullPointerException for null input',result=False,exit='NullPointerException');self.edge(guard,thrown,'null','Actual input is null');self.last=[];present,_=self.op(n,'compute','Objects.requireNonNull continues with the non-null source value',result=False);self.edge(guard,present,'non_null','Actual input is non-null')
   if optional and name in ['get','orElseThrow'] and not callbacks:
    branch,_=self.op(n,'branch','Optional '+name+' selects present result or throws on empty',result=False);self.last=[];thrown,_=self.op(n,'throw','Empty Optional '+name+' throws NoSuchElementException',result=False,exit='NoSuchElementException');self.edge(branch,thrown,'empty','No present Optional value');self.last=[];present,_=self.op(n,'compute','Present Optional '+name+' continues',result=False);self.edge(branch,present,'present','A present Optional value exists')
   return typ,v
  if k=='NEW_CLASS':
   typename=next((x['text'] for x in ch if x['kind'] in ['IDENTIFIER','PARAMETERIZED_TYPE','MEMBER_SELECT']), '?');typeidx=next((i for i,x in enumerate(ch) if x['text']==typename),0);args=[a for a in ch[typeidx+1:] if a['kind']!='CLASS'];av=[self.expr(a) for a in args]
   targetclass=classes.get(fqtype(typename,self.c));opts=matching(candidates(targetclass,'<init>',len(args)),[a[0] for a in av]) if targetclass else [];target=opts[0] if len(opts)==1 and opts[0]['body'] else None
   allocation,avalue=self.op(n,'compute','Allocate source new-expression instance '+typename)
   byid[avalue]['shape']=shapeids.get(fqtype(typename,self.c))
   oid,_=self.op(n,'call','Invoke constructor '+txt,result=False)
   rid=add('resolution','resolution/'+uid(oid),owner=self.owner,requestedArtifact=None,basis='source_local' if target else 'unresolved',target=target['impl'] if target else None,binding=None,candidates=[],evidence=self.evidence(n));byid[oid].update(resolution=rid,bindings=[dict(parameter=p,value=a[1]) for p,a in zip(target['params'],av)] if target else [])
   if not target or target.get('receiver'):byid[oid]['receiver']=avalue
   audit.append(dict(owner=self.m['key'],path=self.c['path'],lines=n['lines'],operation=oid,receiver=typename,receiverType=typename,name='<init>',argumentTypes=[a[0] for a in av],arguments=[a['text'] for a in args],argumentValues=[a[1] for a in av],resultValue=None,resolution='source_local' if target else 'unresolved',target=target['key'] if target else None,candidates=[],returnType='void'))
   add('claim','constructor-signature/'+uid(oid),owner=self.owner,statement='Source constructor call '+txt+' has indexed arguments '+str([arg['text'] for arg in args])+'. These are actual caller arguments, not an inferred mapping onto allocated object fields or imported wire fields. The allocation value exists separately; the constructor invocation has no return value.',basis='source_traced',inputs=[oid,avalue]+[actual for _,actual in av if actual],assumptions=['Imported/generated constructor body and field assignment behaviour remain unresolved'] if not target else [],evidence=self.evidence(n))
   completed,v=self.op(n,'compute','Source new-expression yields allocated instance after constructor normal completion '+typename)
   self.flow(avalue,v,completed,'New-expression instance identity; constructor normal completion does not return a value')
   byid[v]['shape']=shapeids.get(fqtype(typename,self.c))
   if targetclass and targetclass['lex'].get('kind')=='record':
    components=[f for f in targetclass['fields'] if not re.search(r'\bstatic\b',f['declaration']['text'])]
    if len(components)==len(av):
     for component,(_,actual) in zip(components,av):
      field=add('value','record-construction/'+uid(oid+component['name']),owner=self.owner,definition=oid,label='Canonical source record constructor component '+component['name'],role='field',representation='constructed',shape=byid[actual].get('shape') if actual else None,evidence=self.evidence(n)+ev(targetclass['path'],component['declaration']['lines']),accessPath=[component['name']])
      if actual:self.flow(actual,field,oid,'Canonical Java source record constructor input '+component['name'])
      self.flow(field,v,oid,'Explicit source record component '+component['name'])

   if targetclass and targetclass['lex'].get('kind')=='record' and target and len(components)!=len(av):
    def descend(node):
     yield node
     for child in node['children']:yield from descend(child)
    delegation=next((node for node in descend(target['body']) if node['kind']=='METHOD_INVOCATION' and node['children'] and node['children'][0]['text']=='this'),None)
    if delegation and len(delegation['children'])-1==len(components):
     parameterIndex={p['name']:i for i,p in enumerate(target['parameters'])}
     for component,arg in zip(components,delegation['children'][1:]):
      if arg['kind']=='IDENTIFIER' and arg['text'] in parameterIndex:actual=av[parameterIndex[arg['text']]][1]
      elif arg['kind']=='NULL_LITERAL':
       constant,actual=self.op(n,'compute','Source constructor delegation literal null for record component '+component['name']);byid[actual]['role']='constant';byid[actual]['evidence']+=ev(targetclass['path'],arg['lines'])
      else:continue # generated UUID/other callee expressions remain owned by actual constructor body
      projection,field=self.op(n,'compute','Exact source constructor delegation component '+component['name']);byid[field].update(role='field',accessPath=[component['name']]);byid[field]['evidence']+=ev(targetclass['path'],delegation['lines']);self.flow(actual,field,projection,'Explicit source this(...) delegation binds canonical Java record component '+component['name']);self.flow(field,v,projection,'Same allocated source record after explicit canonical constructor delegation; imported auditing/formatting remain separate')
   if typename.startswith('ResponseEntity'):
    sid=add('shape','boundary-result/'+uid(oid),representation='constructed',label=typename+' constructed HTTP response container; body factory result remains separate',fields=[],completeness='partial',gaps=[schemaGap],evidence=self.evidence(n));byid[v]['shape']=sid
   return typename,v
  if k in ['CONDITIONAL_AND','CONDITIONAL_OR','CONDITIONAL_EXPRESSION']:
   leftt,left=self.expr(ch[0]);oid,cond=self.op(ch[0],'branch','Evaluate '+ch[0]['text']);self.flow(left,cond,oid,'Source conditional guard');self.branch.append(oid);saved=dict(self.env);before=[oid]
   self.last=[];t1,v1=self.expr(ch[1]);first=self.last[:];start1=self._first_after(oid)
   self.last=[];self.env=dict(saved)
   if k=='CONDITIONAL_EXPRESSION':t2,v2=self.expr(ch[2]);second=self.last[:];start2=self._first_after(first[-1] if first else oid)
   else:t2,v2=leftt,left;second=[];start2=None
   # Explicit detached expression alternatives join at an expression value.
   self.last=[];join,out=self.op(n,'compute','Join conditional expression '+txt)
   if start1:self.edge(oid,start1,'true' if k!='CONDITIONAL_OR' else 'false',ch[0]['text'],[left] if left else [])
   if start2:self.edge(oid,start2,'false',ch[0]['text'],[left] if left else [])
   else:self.edge(oid,join,'false' if k!='CONDITIONAL_OR' else 'true','Short-circuit / conditional alternative',[])
   for end in first+second:self.edge(end,join)
   self.flow(v1,out,join,'Conditional selected alternative');self.flow(v2,out,join,'Conditional selected alternative');return t1 if t1==t2 else '?',out
  if k in ['LAMBDA_EXPRESSION','MEMBER_REFERENCE']:
   oid,v=self.op(n,'compute','Create deferred callback '+txt)
   item=dict(operation=oid,path=self.c['path'],lines=n['lines'],text=txt,kind=k,status='association_only_no_eager_invocation')
   if k=='LAMBDA_EXPRESSION':
    params=[]
    for variable in ch[:-1]:
     ptext=variable['text'];pname=ptext.split()[-1];ptype=variable['children'][-1]['text'] if len(variable['children'])>1 else self.callbackHint or '?';params.append(dict(name=pname,type=ptype))
    signature=self.m['key']+'$lambda@'+str(n['start']);mid=P+'method/'+uid(signature)
    captured=[]
    names=set()
    def identifiers(node):
     if node['kind']=='IDENTIFIER':names.add(node['text'])
     for sub in node['children']:identifiers(sub)
    identifiers(ch[-1]);formal={p['name'] for p in params}
    if self.receiverValue and ('this' in names or names.intersection({f['name'] for f in self.c['fields']}) or names.intersection({method['name'] for method in self.c['methods'] if method.get('receiver')}) or any(x['kind']=='METHOD_INVOCATION' and x['children'] and x['children'][0]['kind']=='IDENTIFIER' for x in ch[-1].get('children',[]))):captured.append(dict(name='this',type=self.c['fqn'],actual=self.receiverValue,value=mid+'/capture/this'))
    for name,(typ,actual) in self.env.items():
     if name in names and name not in formal and actual:captured.append(dict(name=name,type=typ,actual=actual,value=mid+'/capture/'+name))
    lm=dict(key=signature,ownerClass=self.c,file=self.m['file'],impl=mid,params=[mid+'/parameter/'+p['name'] for p in params],parameters=params,returnType='?',declaration=n,body=ch[-1],exec=None,library=self.m['library'],captures=captured)
    add('implementation','method/'+uid(signature),logicalId=signature,scope=scope,entry=mid+'/entry',parameters=lm['params'],captures=[x['value'] for x in captured],evidence=self.evidence(n))
    add('operation','method/'+uid(signature)+'/entry',owner=mid,action='entry',label='Enter deferred source lambda '+signature,resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=self.evidence(n))
    if not lm['library']:lm['exec']=add('execution_binding','execution/'+uid(signature),implementation=mid,component=host,basis='source_declared',artifactBinding=None,gaps=[],evidence=self.evidence(n))
    for p,pid in zip(params,lm['params']):add('value',pid[len(P):],owner=mid,definition=mid+'/entry',label=p['name']+': '+p['type'],role='parameter',representation='constructed',shape=shapeids.get(fqtype(p['type'],self.c)),evidence=self.evidence(n),accessPath=[])
    for cap in captured:add('value',cap['value'][len(P):],owner=mid,definition=mid+'/entry',label='Lexical capture '+cap['name']+': '+cap['type'],role='capture',representation='constructed',shape=shapeids.get(fqtype(cap['type'],self.c)),evidence=self.evidence(n),accessPath=[])
    self.deferred.append(lm);self.callbackObjects[v]=lm;item.update(implementation=mid,formalParameters=lm['params'],captures=captured)
   if k=='MEMBER_REFERENCE' and ch:
    qualifier=ch[0];qt,qv=self.expr(qualifier);qc=classes.get(fqtype(qt,self.c));refname=txt.rsplit('::',1)[-1];opts=[m for m in qc['methods'] if m['name']==refname] if qc else []
    # Exact reviewed overloaded scalar callbacks in these two source stream pipelines.
    selectedType={'AnalyticsIndividualMapper':'Individual','AnalyticsCorporateEntityMapper':'CorporateEntity'}.get(qc['name'] if qc else '') if refname=='to' else None
    if selectedType:opts=[m for m in opts if len(m['parameters'])==1 and clean(m['parameters'][0]['type'])==selectedType]
    if len(opts)==1:
     target=opts[0];isclass=qualifier['text'] in [qc['name'],qc['fqn']];ref=dict(target,referenceTarget=True,referenceExternal=not bool(target['body']),referenceReceiverType=qt,referenceName=refname,unboundReceiver=bool(target.get('receiver') and isclass),boundReceiver=qv if target.get('receiver') and not isclass else None,captures=[])
     self.callbackObjects[v]=ref;item.update(implementation=target['impl'],formalParameters=target['params'],referenceReceiver='element' if ref['unboundReceiver'] else 'bound' if target.get('receiver') else 'static',status='generated_method_reference_associated' if ref['referenceExternal'] else 'local_method_reference_associated')
   if k=='MEMBER_REFERENCE' and v not in self.callbackObjects:
    qualifier=ch[0];refname=txt.rsplit('::',1)[-1];classNamed=bool(re.fullmatch(r'[A-Z]\w*',qualifier['text']));staticRef=qualifier['text']=='Objects';inputs=[dict(name='input',type=self.callbackHint or '?')] if staticRef or not classNamed else []
    ref=dict(key='Source reference '+txt,impl=None,params=[],parameters=inputs,captures=[],referenceExternal=True,referenceReceiverType=qt,referenceName=refname,receiver=classNamed and not staticRef or not classNamed,unboundReceiver=classNamed and not staticRef,boundReceiver=qv if not classNamed else None,returnType='String' if refname in ['trim','toLowerCase','toString','getId'] else 'boolean' if refname in ['contains','nonNull'] else 'Map<String,Object>' if refname=='getAdditionalParameters' else '?')
    self.callbackObjects[v]=ref;item.update(status='imported_method_reference_invocation_boundary',receiverType=qt,referenceName=refname)
   self.callback.append(item);return 'callback',v
  if k=='ASSIGNMENT':
   typ,v=self.expr(ch[-1]);oid,out=self.op(n,'compute');self.flow(v,out,oid,'Source assignment '+txt);self.flow(self.receiverValue,out,oid,'Source receiver mutation '+ch[0]['text']) if ch[0]['text'].startswith('this.') or findfield(self.c,ch[0]['text']) else None;self.env[ch[0]['text']]=(typ,out);return typ,out
  av=[self.expr(x) for x in ch if x['kind'] not in ['MODIFIERS','PRIMITIVE_TYPE','PARAMETERIZED_TYPE','CLASS']];oid,v=self.op(n,'compute')
  for _,a in av:self.flow(a,v,oid,'Evaluate source expression '+txt)
  typ={'STRING_LITERAL':'String','INT_LITERAL':'int','BOOLEAN_LITERAL':'boolean','NULL_LITERAL':'null'}.get(k,av[-1][0] if av else '?')
  return typ,v
 def _first_after(self,oid):
  ix=next(i for i,r in enumerate(records) if r['id']==oid)
  return next((r['id'] for r in records[ix+1:] if r['kind']=='operation' and r['owner']==self.owner),None)
 def genericArgs(self,t):
  if '<' not in t:return []
  text=t[t.find('<')+1:t.rfind('>')];out=[];start=0;depth=0
  for i,c in enumerate(text):
   if c=='<':depth+=1
   elif c=='>':depth-=1
   elif c==',' and depth==0:out.append(text[start:i].strip());start=i+1
  return out+[text[start:].strip()]
 def element(self,t):return t[t.find('<')+1:t.rfind('>')] if '<' in t else t[:-2] if t.endswith('[]') else '?'
 def constant(self,n):return self.expr(n)[1]
 def block(self,n):
  if not n:return
  k=n['kind'];ch=n['children']
  if k=='BLOCK':
   for x in ch:self.block(x)
  elif k=='EXPRESSION_STATEMENT':self.expr(ch[0])
  elif k=='VARIABLE':
   inferred=bool(re.match(r'\s*(?:final\s+)?var\s+\w+\s*=',n['text']));decltype='var' if inferred else ch[1]['text'] if len(ch)>1 else '?';name=re.search(r'([\w$]+)\s*(?:=|;|$)',n['text'].split('=',1)[0].strip())
   name=name[1] if name else '?';previousExpected=self.expectedType;self.expectedType=decltype;typ,v=self.expr(ch[-1]) if inferred or len(ch)>2 else (decltype,None);self.expectedType=previousExpected;oid,out=self.op(n,'compute','Define '+n['text']);self.flow(v,out,oid,'Initialise source local '+name);self.env[name]=(decltype if decltype!='var' else typ,out);byid[out]['shape']=(byid[v].get('shape') if v else None) or shapeids.get(fqtype(decltype,self.c))
   if v in self.builders:self.builders[out]=copy.deepcopy(self.builders[v])
   if v in self.streamPlans:self.streamPlans[out]=list(self.streamPlans[v])
   if v in self.collectorPlans:self.collectorPlans[out]=list(self.collectorPlans[v])
   if v in self.callbackObjects:self.callbackObjects[out]=self.callbackObjects[v]
  elif k in ['RETURN','THROW']:
   typ,v=self.expr(ch[0]) if ch else ('void',None);oid,_=self.op(n,'return' if k=='RETURN' else 'throw',result=False,exit='normal' if k=='RETURN' else typ);byid[oid]['result']=v
   if k=='RETURN' and v and byid[v]['shape'] is None:byid[v]['shape']=shapeids.get(fqtype(self.m.get('returnType'),self.c))
   if k=='THROW' and ch:
    status,statusEvidence=exception_status(ch[0],self.c)
    if status is not None:byid[oid]['label']+=' [local exception statusCode='+str(status)+'; final advice/catch outcome is separate]';byid[oid]['evidence']+=statusEvidence
   if k=='RETURN' and 'ControllerImpl' in self.c['name']:
    for status,number in [('ALREADY_REPORTED',208),('ACCEPTED',202),('CREATED',201),('OK',200)]:
     if 'HttpStatus.'+status in n['text']:byid[oid]['httpStatus']=number;break
    if byid[oid]['httpStatus'] is None and ('SuccessResponse.ok(' in n['text'] or 'ResponseEntity.ok(' in n['text']):byid[oid]['httpStatus']=200
  elif k=='IF':
   _,val=self.expr(ch[0]);branch,_=self.op(ch[0],'branch','if '+ch[0]['text'],result=False);self.branch.append(branch);env=dict(self.env);self.last=[];before=len(records);self.block(ch[1]);yes=self.last[:];yesenv=dict(self.env);yesstart=next((r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner),None);self.env=dict(env);self.last=[];before=len(records)
   if len(ch)>2:self.block(ch[2])
   no=self.last[:];noenv=dict(self.env);nostart=next((r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner),None);self.last=[];join,_=self.op(n,'compute','Continue after if at line '+str(n['lines'][0]),result=False)
   for start,on in [(yesstart,'true'),(nostart,'false')]:self.edge(branch,start or join,on,ch[0]['text'],[val] if val else [])
   for end in yes+no:self.edge(end,join)
   self.env=dict(env)
   for name in env:
    y=yesenv.get(name,env[name]);z=noenv.get(name,env[name])
    if y!=z:
     phi,pv=self.op(n,'compute','Select source local '+name+' from the feasible if branch');self.flow(y[1],pv,phi,'Value selected only on true branch '+ch[0]['text']);self.flow(z[1],pv,phi,'Value selected only on false branch '+ch[0]['text']);self.env[name]=(y[0] if y[0]==z[0] else '?',pv)
   if yesstart and not yes and nostart and not no:self.last=[]
  elif k=='ENHANCED_FOR_LOOP':
   variable,iterable,body=ch;typ,vals=self.expr(iterable);guard,_=self.op(n,'branch','For each '+variable['text']+' in '+iterable['text'],result=False);self.branch.append(guard);self.last=[];before=len(records);self.loopContinues.append(guard);name=re.search(r'(\w+)\s*$',variable['text'])[1];vtype=variable['children'][1]['text'];select,selected=self.op(variable,'compute','Select actual source enhanced-for element '+name);self.flow(vals,selected,select,'Java enhanced-for selects the current source collection element');self.env[name]=(vtype,selected);self.block(body);self.loopContinues.pop();end=self.last[:];start=next((r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner),None);self.last=[];join,_=self.op(n,'compute','Loop exhausted',result=False)
   self.edge(guard,start or guard,'iteration','Next element exists',[vals] if vals else []);self.edge(guard,join,'exhausted');[self.edge(x,guard,'next') for x in end]
  elif k=='CONTINUE':
   oid,_=self.op(n,'compute','Source continue to next iteration',result=False)
   if self.loopContinues:self.edge(oid,self.loopContinues[-1],'continue','Continue nearest source loop')
   self.last=[]
  elif k=='FOR_LOOP':
   body=ch[-1];prefix=ch[:-1];initial=[x for x in prefix if x['kind']=='VARIABLE'];condition=next((x for x in prefix if x['kind'] not in ['VARIABLE','EXPRESSION_STATEMENT']),None);updates=[x for x in prefix if x['kind']=='EXPRESSION_STATEMENT']
   for init in initial:self.block(init)
   before=len(records);_,value=self.expr(condition) if condition else ('boolean',None);startCondition=next((r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner),self.last[-1]);guard,_=self.op(n,'branch','Source for-loop condition '+(condition['text'] if condition else 'true'),result=False);saved=dict(self.env);self.last=[];before=len(records);self.loopContinues.append(guard);self.block(body);self.loopContinues.pop()
   for update in updates:self.block(update)
   ends=self.last[:];start=next((r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner),startCondition);self.last=[];join,_=self.op(n,'compute','Source for-loop condition false',result=False);self.edge(guard,start,'true',condition['text'] if condition else 'true',[value] if value else []);self.edge(guard,join,'false','Source loop condition false')
   for end in ends:self.edge(end,startCondition,'next','Evaluate source for update then re-evaluate condition')
  elif k=='WHILE_LOOP':
   condition,body=ch;before=len(records);_,value=self.expr(condition);conditionStart=next(r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner);guard,_=self.op(condition,'branch','while '+condition['text'],result=False);self.last=[];before=len(records);self.block(body);ends=self.last[:];bodyStart=next((r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner),None);self.last=[];join,_=self.op(n,'compute','While condition is false; loop ends',result=False);self.edge(guard,bodyStart or conditionStart,'true',condition['text'],[value] if value else []);self.edge(guard,join,'false','Loop condition is false',[value] if value else [])
   for end in ends:self.edge(end,conditionStart,'next','Re-evaluate the actual source condition before selecting another job')
  elif k=='TRY':
   before=len(records);resources=[x for x in ch if x['kind'] not in ['BLOCK','CATCH']]
   for resource in resources:self.block(resource)
   body=next((x for x in ch if x['kind']=='BLOCK'),None);self.block(body);normal=self.last[:];bodyops=[r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner and r['action'] in ['call','throw']];abrupt=[r['id'] for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner and r['action'] in ['return','throw']];sources=list(bodyops);catchends=[]
   for catch in [x for x in ch if x['kind']=='CATCH']:
    self.last=[];before=len(records);self.block(catch['children'][0]);self.block(catch['children'][1]);catchends+=self.last;owned=[r for r in records[before:] if r['kind']=='operation' and r['owner']==self.owner];sources += [r['id'] for r in owned if r['action']=='call'];abrupt += [r['id'] for r in owned if r['action'] in ['return','throw']];start=owned[0]['id'] if owned else None;catchType=catch['children'][0]['children'][1]['text'] if len(catch['children'][0]['children'])>1 else catch['children'][0]['text'].rsplit(' ',1)[0]
    if start:self.catchSites.append(dict(sources=bodyops,start=start,type=catchType))
   self.last=normal+catchends;final=[x for x in ch if x['kind']=='BLOCK' and x is not body]
   if final:
    normalEnds=self.last[:];self.last=[];enter,_=self.op(final[0],'compute','Enter source finally with pending normal/return/exception completion',result=False)
    for end in normalEnds:self.edge(end,enter,'normal','Try/catch completed normally; run source finally')
    for block in final:self.block(block)
    finalEnds=self.last[:]
    if finalEnds:
     resume,_=self.op(final[0],'branch','Resume the saved Java completion only after source finally returns normally',result=False);self.normalResume.add(resume);self.last=[resume]
    else:resume=None;self.last=[]
    self.finallySites.append(dict(node=final[0],entry=enter,resume=resume,sources=sources,abrupt=abrupt))
  elif k in ['EMPTY_STATEMENT']:pass
  else:self.unsupported.append(dict(kind=k,lines=n['lines'],text=n['text']));self.op(n,'opaque','Unexpanded source syntax '+n['text'],result=False)
 def compile(self):
  if self.m['body']:self.block(self.m['body'])
  else:self.op(self.m['declaration'],'opaque','Declaration only; implementation is generated/imported or selected by runtime',result=False)
  if self.last:self.op(self.m['declaration'],'return','Normal source completion',result=False,exit='normal')
  mutation=[r['id'] for r in records if r['kind']=='operation' and r['owner']==self.owner and (r['label'].startswith('this.') and '=' in r['label'] or re.search(r'\.(?:set[A-Z]\w*|addAttribute|addFirst|add|put|remove)\(',r['label']))]
  if mutation:add('claim','source-mutations/'+uid(self.m['key']),owner=self.owner,statement='The cited source explicitly assigns or mutates the receiver/member values at these operations. Receiver and lexical-capture bindings retain object-reference identity; later mapper/store calls consume the source object reference. This is source-traced transformation evidence, not automatic heap-state/alias proof or runtime branch feasibility.',basis='source_traced',inputs=mutation+([self.receiverValue] if self.receiverValue else []),assumptions=['Generated accessor and imported collection implementations remain explicit boundaries; branch guards are retained natively.'],evidence=ev(self.c['path'],self.m['declaration']['lines']))
  gap=add('gap','gap/method/'+uid(self.m['key']),owner=self.owner,obligation='effective_runtime_and_formal_analysis',reason='Available explicit method/lambda source and source registration/call/guard/value/mutation expressions are extracted. Imported/generated implementations, effective configuration and wire conversion remain boundaries. Native queries do not automatically prove mutable heap state, alias/guard feasibility or implicit runtime exceptions.',action='Resolve exact generated/dependency artefacts and effective configuration for runtime closure; inspect the saved source transformations and invocation bindings when assessing state changes.',evidence=ev(self.c['path'],self.m['declaration']['lines']))
  add('coverage','coverage/'+uid(self.m['key']),owner=self.owner,obligation='explicit_source_method_control_data',status='examined' if self.m['body'] and not self.unsupported else 'partial',scope='Whole explicit source method/lambda body and source call/guard/return/assignment expressions, with actual method ownership, declared formals, receivers and lexical captures. This obligation excludes unavailable generated/imported implementations and automatic heap/feasibility proof.',gaps=[gap,schemaGap],evidence=ev(self.c['path'],self.m['declaration']['lines']))
  return dict(method=self.m['key'],implementation=self.owner,path=self.c['path'],lines=self.m['declaration']['lines'],hasBody=bool(self.m['body']),runtimeRole='unbound_client_library' if self.m['library'] else 'source_host_context',status='source_body_examined' if self.m['body'] and not self.unsupported else 'declaration_only_implementation_external',calls=len(self.calls),localResolved=sum(x['resolution']=='source_local' for x in self.calls),callbacks=self.callback,unexpanded=self.unsupported,branches=self.branch,gap=gap)

ledger=[];pending=list(methods.values());graphs=[]
while pending:
 m=pending.pop(0);g=Graph(m)
 for cap in m.get('captures',[]):g.env[cap['name']]=(cap['type'],cap['value'])
 # Expression-bodied lambdas return the expression; block lambdas preserve explicit returns.
 if '$lambda@' in m['key'] and m['body']['kind']!='BLOCK':
  expression=m['body'];m['body']=dict(kind='RETURN',text=expression['text'],start=expression['start'],end=expression['end'],lines=expression['lines'],children=[expression])
 ledger.append(g.compile());graphs.append(g);pending.extend(g.deferred)

# Preserve contextual construction through explicit local returns, copies and formal/actual bindings.
returnByOwner=collections.defaultdict(list)
for r in records:
 if r['kind']=='operation' and r['action']=='return' and r.get('result'):returnByOwner[r['owner']].append(r)
shapeCalls=[r for r in records if r['kind']=='operation' and r['action']=='call' and r.get('result') and r.get('resolution')]
copyFlows=[r for r in records if r['kind']=='flow' and r['transform'].startswith(('Initialise source local','Source assignment','Conditional selected alternative','Explicit caller builder'))]
for _ in range(16):
 changedShape=False
 for flow in copyFlows:
  source=byid[flow['from']].get('shape');target=byid[flow['to']]
  if source and not target.get('shape'):target['shape']=source;changedShape=True
 actualShapes=collections.defaultdict(set)
 for operation in shapeCalls:
  resolution=byid[operation['resolution']]
  if resolution['basis']!='source_local':continue
  for binding in operation['bindings']:
   source=byid[binding['value']].get('shape')
   if source:actualShapes[binding['parameter']].add(source)
  shapes={byid[r['result']].get('shape') for r in returnByOwner[resolution['target']]};shapes.discard(None)
  if len(shapes)==1 and byid[operation['result']].get('shape') is None:byid[operation['result']]['shape']=next(iter(shapes));changedShape=True
  elif len(shapes)>1 and byid[operation['result']].get('shape') is None and all(byid[s].get('container')=='object' for s in shapes):
   variants=[byid[s] for s in sorted(shapes)];names=list(dict.fromkeys(f['name'] for shape in variants for f in shape['fields']));fields=[]
   for name in names:
    members=[next((f for f in shape['fields'] if f['name']==name),None) for shape in variants];known=[f for f in members if f];f=copy.deepcopy(known[0]);f['evidence']=list(dict.fromkeys(e for field in known for e in field.get('evidence',[])))
    if len(known)<len(variants):f['optional']=True
    for constraint in ['const','enum','shape','nullable','maxLength','pattern']:
     if not all(constraint in other and other[constraint]==f.get(constraint) for other in known):f.pop(constraint,None)
    fields.append(f)
   sid=add('shape','return-construction-union/'+uid(operation['id']),representation='constructed',label='Conditional source return construction variants for '+byid[resolution['target']]['logicalId'],fields=fields,container='object',completeness='partial',gaps=[schemaGap],evidence=list(dict.fromkeys(e for shape in variants for e in shape['evidence'])));byid[operation['result']]['shape']=sid;changedShape=True
 for parameter,shapes in actualShapes.items():
  if len(shapes)==1 and not byid[parameter].get('shape'):byid[parameter]['shape']=next(iter(shapes));changedShape=True
 for graph in graphs:
  for dispatch in graph.dispatchJoins:
   shapes=[byid[value].get('shape') for value in dispatch['values']]
   if not all(shapes):continue
   unique=sorted(set(shapes));selected=unique[0]
   if len(unique)>1 and all(byid[shape].get('container')=='object' for shape in unique):
    variants=[byid[shape] for shape in unique];fields=[]
    for name in dict.fromkeys(field['name'] for shape in variants for field in shape['fields']):
     members=[next((field for field in shape['fields'] if field['name']==name),None) for shape in variants];known=[field for field in members if field];field=copy.deepcopy(known[0]);field['evidence']=list(dict.fromkeys(e for item in known for e in item.get('evidence',[])))
     if len(known)<len(variants):field['optional']=True
     if len({item['type'] for item in known})>1:field['type']='Guarded source alternatives: '+' | '.join(sorted({item['type'] for item in known}))
     for constraint in ['const','enum','shape','nullable','maxLength','pattern']:
      if not all(constraint in item and item[constraint]==field.get(constraint) for item in known):field.pop(constraint,None)
     fields.append(field)
    selected=P+'guarded-dispatch-shape/'+uid(dispatch['value']);evidence=list(dict.fromkeys(e for shape in variants for e in shape['evidence']))
    if selected not in byid:add('shape','guarded-dispatch-shape/'+uid(dispatch['value']),representation='constructed',label='Partial union of source guarded receiver/delegate result constructions',fields=fields,container='object',completeness='partial',gaps=[schemaGap],evidence=evidence)
    elif byid[selected]['fields']!=fields:byid[selected]['fields']=fields;changedShape=True
   if byid[dispatch['value']].get('shape')!=selected:byid[dispatch['value']]['shape']=selected;changedShape=True
  for construction in graph.constructionRecords:
   shape=byid[construction['shape']]
   for field in shape['fields']:
    members=[m for m in construction['fields'] if m['name']==field['name'] and m['value']]
    if members:
     nested=byid[members[-1]['value']].get('shape')
     if nested and nested!=shape['id'] and field.get('shape')!=nested:field['shape']=nested;changedShape=True
  for stream in graph.streamResults:
   if byid[stream['value']].get('shape'):continue
   mapped=[lm for stage,lm in stream['stages'] if stage in ['map','flatMap','value_mapper']]
   if not mapped:continue
   last=mapped[-1];shapes={byid[r['result']].get('shape') for r in returnByOwner[last['impl']]};shapes.discard(None)
   if len(shapes)==1:
    item=next(iter(shapes));sid=add('shape','stream-construction/'+uid(stream['value']),representation='constructed',label='Source terminal collection of explicit mapped construction',fields=[],container='array',items=item,completeness='partial',gaps=[schemaGap],evidence=byid[stream['operation']]['evidence']);byid[stream['value']]['shape']=sid;changedShape=True
 if not changedShape:break

# Native exception continuations must match actual exit discriminants, including available local subtypes.
def subtype(exittype,catchtype,c):
 if exittype==catchtype:return True
 if catchtype in ['Exception','RuntimeException'] and exittype in ['RuntimeException','IllegalArgumentException','IllegalStateException','NullPointerException','NoSuchElementException','IndexOutOfBoundsException','ClassCastException','ArithmeticException']:return True
 if catchtype=='Throwable':return True
 seen=set();fq=fqtype(exittype,c)
 while fq in classes and fq not in seen:
  seen.add(fq);owner=classes[fq];base=clean(owner.get('extends'))
  if base.split('.')[-1]==catchtype:return True
  if catchtype=='Exception' and base in ['RuntimeException','Exception']:return True
  fq=fqtype(base,owner)
 return False
# Preserve a qualified imported failure escape from local methods. This is not a
# fabricated executed throw: it is conditional on an unresolved invocation actually
# throwing an unchecked exception, outside every matching source catch.
for graph in graphs:
 for row in graph.calls:
  operation=byid[row['operation']];resolution=byid.get(operation.get('resolution'),{})
  if resolution.get('basis')!='unresolved':continue
  matchingCatches=[site for site in graph.catchSites if operation['id'] in site['sources'] and subtype('RuntimeException',site['type'],graph.c)]
  if matchingCatches:continue
  saved=graph.last;graph.last=[];escape,_=graph.op(dict(lines=row['lines'],text=row['name'],kind='IMPORTED_FAILURE_BOUNDARY'),'throw','Unresolved imported invocation may propagate unchecked RuntimeException: '+row['name'],result=False,exit='RuntimeException');graph.edge(operation['id'],escape,'RuntimeException','Only if this exact unresolved invocation throws an uncaught unchecked exception; dependency/runtime behaviour remains unknown');graph.last=saved
exits=sorted({r['exit'] for r in records if r['kind']=='operation' and r.get('exit') not in [None,'normal']})
for g in graphs:
 for site in g.catchSites:
  for source in site['sources']:
   r=byid[source]
   if r['action']=='throw':
    exitcode=r['exit']
    if exitcode and subtype(exitcode,site['type'],g.c):r['exit']=None;g.edge(source,site['start'],exitcode,'Source catch '+site['type'])
   else:
    for exitcode in exits if byid[r['resolution']]['basis']!='unresolved' else []:
     if subtype(exitcode,site['type'],g.c):g.edge(source,site['start'],exitcode,'Source catch '+site['type'])
    if byid[r['resolution']]['basis']=='unresolved':g.edge(source,site['start'],site['type'],'Imported dependency conditionally throws catch-compatible '+site['type'])


# Java finally executes after pending source completion; its own failure replaces that completion.
for g in graphs:
 for site in g.finallySites:
  pending=[]
  for rid in site['abrupt']:
   operation=byid[rid];exitcode=operation.get('exit')
   if exitcode is None:continue # Already redirected to a compatible local catch.
   operation['exit']=None;g.edge(rid,site['entry'],'finally','Save pending '+exitcode+' completion and execute finally first');pending.append((exitcode,operation.get('result'),rid))
  for rid in site['sources']:
   operation=byid[rid]
   if operation['action']!='call':continue
   for exitcode in exits if byid[operation['resolution']]['basis']!='unresolved' else []:
    caught=any(r['kind']=='transition' and r['from']==rid and r['on']==exitcode for r in records)
    if not caught:g.edge(rid,site['entry'],exitcode,'Callee exits '+exitcode+'; save that exception and execute source finally');pending.append((exitcode,None,rid))
   if byid[operation['resolution']]['basis']=='unresolved' and not any(record['kind']=='transition' and record['from']==rid and record['on']=='Exception' for record in records):
    g.edge(rid,site['entry'],'Exception','Imported invocation conditionally throws an otherwise-unhandled Exception; source finally still executes');pending.append(('Exception',None,rid))
  if site['resume']:
   seen=set()
   for exitcode,value,origin in pending:
    if (exitcode,value) in seen:continue
    seen.add((exitcode,value));g.last=[];terminal,_=g.op(site['node'],'return' if exitcode=='normal' else 'throw','Resume pending '+exitcode+' completion saved before finally',result=False,exit=exitcode);byid[terminal]['result']=value;g.edge(site['resume'],terminal,'pending_'+exitcode,'Only when pending completion saved at '+origin+' is '+exitcode)
  add('claim','finally-policy/'+uid(g.owner+site['entry']),owner=g.owner,statement='The source finally block runs after normal completion, pending return and uncaught call/throw completion from this try/catch. Pending completions resume only if finally returns normally; a finally failure replaces the pending completion. Calls before this try are not covered. Conditions retain the pending completion discriminator; native traversal does not prove state/guard feasibility or every implicit runtime failure.',basis='source_traced',inputs=[site['entry']]+([site['resume']] if site['resume'] else [])+site['sources']+site['abrupt'],assumptions=['Imported implicit exception types outside declared/source exits remain unresolved'],evidence=ev(g.c['path'],site['node']['lines']))

# Enforce source declaration return contracts, including guarded call alternatives.
voidResults={row['resultValue'] for row in audit if (row['name']=='<init>' or row.get('returnType')=='void') and row.get('resultValue')}
for row in audit:
 if row.get('returnType')=='void':byid[row['operation']]['result']=None
for row in audit:
 if row['name']=='<init>':byid[row['operation']]['result']=None
for operation in records:
 if operation['kind']!='operation' or operation.get('action')!='call':continue
 resolution=byid.get(operation.get('resolution'),{});target=byid.get(resolution.get('target'),{})
 if target.get('returnKind')=='void' and operation.get('result'):
  voidResults.add(operation['result']);operation['result']=None
for row in audit:
 if row.get('resultValue') in voidResults:row['resultValue']=None;row['returnType']='void'
removed={r['id'] for r in records if r['kind']=='value' and r['id'] in voidResults or r['kind']=='flow' and (r['from'] in voidResults or r['to'] in voidResults)}
records=[r for r in records if r['id'] not in removed]
for record in records:
 if record['kind']=='operation' and record.get('result') in removed:record['result']=None
 if record['kind']=='claim':record['inputs']=[v for v in record.get('inputs',[]) if v not in removed]
 if record['kind']=='transition':record['values']=[v for v in record.get('values',[]) if v not in removed]
byid={r['id']:r for r in records}


exec(compile((OUT/'catalogue.py').read_text(),str(OUT/'catalogue.py'),'exec'))
(OUT/'working.bundle.json').write_text(json.dumps(dict(format='groundwork-knowledge/v3',workspace='volvo-cars',records=records),indent=2)+'\n')
(OUT/'method-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
(OUT/'call-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(dict(records=len(records),methods=len(methods),frames=len(ledger),unexpanded=[x for r in ledger for x in r['unexpanded']]),indent=2))
