"""Source tuple reconciliation and review gates; not a compiler correctness claim."""
# Exact global declarations remain native source facts, with large inert literals compressed by digest.
constantAudit=[]
for path,f in F.items():
 for decl in f['ast'].get('Decls',[]):
  if decl.get('kind')!='GenDecl' or decl.get('Tok') not in ['const','var']:continue
  for spec in decl.get('Specs',[]):
   if spec.get('kind')!='ValueSpec':continue
   names=[x['Name'] for x in spec.get('Names',[])];raw=spec['text'];statement=('Inert/generated source declaration '+str(names)+': '+str(len(raw.encode()))+' bytes, SHA256 '+hashlib.sha256(raw.encode()).hexdigest()+'. Full pinned source retained as evidence; data literal/descriptor is not an extra execution/registration.') if len(raw)>5000 else 'Exact package-level '+decl['Tok']+' declaration: '+raw+'. Source initialisation/constant identity is distinct from observed runtime activation.'
   cid=claim('global/'+hash(path+str(spec['start'])),source,statement,[source],[ev(path,spec['lines'])]);constantAudit.append(dict(path=path,lines=spec['lines'],names=names,claim=cid,bytes=len(raw.encode()),sha256=hashlib.sha256(raw.encode()).hexdigest()))
# Actual Fx registrations, including unused helper declarations, are not eager ordinary method calls.
registrations=[]
for node in walknode(F['internal/app/app.go']['ast']):
 if node.get('kind')!='CallExpr' or tx(node['Fun']) not in ['fx.Provide','fx.Invoke']:continue
 for arg in node.get('Args',[]):
  callback=arg
  if callback.get('kind')=='CallExpr' and tx(callback['Fun'])=='fx.Annotate':callback=callback['Args'][0]
  target=None
  if callback.get('kind')=='FuncLit':target=B.get('internal/app/app.go:'+str(callback['start']))
  elif callback.get('kind')=='Ident':rows=FUN.get(('github.com/volvo-cars/cce-policy-admin/internal/app',tx(callback)),[]);target=rows[0] if len(rows)==1 else None
  elif callback.get('kind')=='SelectorExpr':
   package=F['internal/app/app.go']['imports'].get(tx(callback['X']));rows=FUN.get((package,tx(callback['Sel'])),[]);target=rows[0] if len(rows)==1 else None
  if not target:raise AssertionError(('Local Fx registration not resolved',tx(arg)))
  cid=claim('registration/'+hash(str(callback['start'])),source,'Exact '+tx(node['Fun'])+' registration '+tx(arg)+'. Available source callable is associated, not eagerly invoked. Default provider graph, supplied options, dependency availability and imported Fx activation remain separate. Repeated same constructor registration is not an asserted count of runtime objects.',[target['implementation']],[ev('internal/app/app.go',arg['lines'])]);registrations.append(dict(kind=tx(node['Fun']),source=tx(arg),lines=arg['lines'],implementation=target['implementation'],claim=cid))
# Signature candidates are checked against source-native actual bindings, namespace and guarded receiver rules.
aid={(c['path'],c['source'],tuple(c['lines'])):c for m in M['methods'] for c in m['calls']};sourceMethods={m['implementation']:m for m in methods};symbolAudit=[]
for c in CALLS:
 candidate=aid.get((c['path'],c['source'],tuple(c['lines'])));target=sourceMethods.get(c['target']);assert not(candidate and candidate['signatureCandidate'] and not target),('Available local candidate remains unreviewed',c)
 symbolAudit.append(dict(path=c['path'],lines=c['lines'],source=c['source'],operation=c['operation'],target=c['target'],targetSourcePath=target['path'] if target else None,receiverSourceType=c.get('receiverSourceType'),receiverAdjustment=c.get('receiverAdjustment'),declaredReturnTypes=c['resultTypes'],localSignatureCandidate=candidate.get('signatureCandidate') if candidate else None,review='Source namespace/receiver/arity checked; default interface concrete target guarded with unresolved alternative' if target else 'Available local module inventory searched; exact operand/source signature retained, imported/dynamic implementation unresolved'))
returnAudit=[]
for m in methods:
 assert R[m['implementation']]['returnKind']==('value' if m['results'] else 'void')
 returnAudit.append(dict(implementation=m['implementation'],path=m['path'],lines=m['lines'],sourceResults=m['results'],returnKind=R[m['implementation']]['returnKind'],basis='Exact available Go source signature; interface/function-type void calls separately audited'))
for name,f in pyFrames.items():returnAudit.append(dict(implementation=f['owner'],path=pyPath,lines=[getattr(f['node'],'lineno',1),getattr(f['node'],'end_lineno',len(pyText.splitlines()))],sourceReturns=[ast.unparse(n.value) for n in ast.walk(f['node']) if isinstance(n,ast.Return) and n.value is not None] if name!='module' else [],returnKind=R[f['owner']]['returnKind'],basis='Actual Python body returns; explicit object-returning preparation helpers are value, other completion is None/void'))
voids={r['id'] for r in R.values() if r['kind']=='implementation' and r.get('returnKind')=='void'};boundVoid=[r for r in R.values() if r['kind']=='operation' and R.get(r.get('resolution'),{}).get('target') in voids];assert all(r['result'] is None for r in boundVoid);assert all(r['result'] is None for r in R.values() if r['kind']=='operation' and r['owner'] in voids and r['action']=='return')
for c in LOCAL_SIGNATURE_CALLS:
 if c['signature']['returnKind']=='void':assert c['result'] is None
allIO=[]
for r in R.values():
 if r['kind']!='interaction':continue
 allIO.append(dict(interaction=r['id'],owner=r['owner'],operation=r['operation'],mode=r['mode'],boundary=r['boundary'],target=r['target'],contract=r['contract'],effect=r['effect'],evidence=r['evidence'],scope='Actual source-bound operation/entry; default registrations versus available unregistered helper scopes separate'))
allEntries={r['implementation'] for r in R.values() if r['kind']=='entry'}
claim('implicit-bounds',method('internal/database/blobstorage/blobstorage.go','getRequiredOptionsComponents')['implementation'],'Known source implicit-bounds risk is retained: allocation uses IncludedOptions length, iteration uses RequiredOptions length. Automatic Go index/nil bounds and arbitrary loop/heap feasibility are not solved by source graphs; no successful completion is guaranteed for mismatched lengths.',[method('internal/database/blobstorage/blobstorage.go','getRequiredOptionsComponents')['implementation']],anchor('internal/database/blobstorage/blobstorage.go'))
for name,data in [('global-declaration',constantAudit),('registration',registrations),('symbol-resolution',symbolAudit),('return-type',dict(implementations=returnAudit,knownVoid=len(voids),boundVoidCalls=len(boundVoid),nativeNegativeAssertions='All bound void calls and void exits have no result; local function/interface signatures audited')),('io-completeness',allIO)]: (D/(name+'-ledger.json')).write_text(json.dumps(data,indent=2)+'\n')
