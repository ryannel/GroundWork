"""Finite actual registration/runtime/configured Azure boundary catalogue."""
SRC=Path('/tmp/cce-policy-admin-pinned')
def anchor(path):return [ev(path,[1,len((SRC/path).read_text().splitlines())])]
def method(path,name):return next(m for m in methods if m['path']==path and m['name']==name)
def claim(key,owner,statement,inputs,evidence):return add('claim',key,owner=owner,statement=statement,basis='source_declared',inputs=list(dict.fromkeys(inputs)),assumptions=[],evidence=evidence)
def component(key,label,category,tech,paths):return add('runtime_component',key,logicalId=key,label=label,category=category,technology=tech,sources=[source],basis='source_declared',gaps=[runtimeGap],evidence=sum((anchor(p) for p in paths),[]))
api=component('policy-admin','CCE Policy Admin','service','Go / chi / Fx / in-process Watermill',['cmd/policy-admin/main.go','internal/app/app.go']);blob=component('azure-blobs','Configured Policy Admin Azure blob storage','store','Azure Blob Storage; configured service URL/container',['internal/app/config.go','internal/database/blobstorage/blobstorage.go'])
executions={m['implementation']:add('execution_binding',hash(m['key']),implementation=m['implementation'],component=api,basis='source_declared',artifactBinding=None,gaps=[runtimeGap],evidence=[ev(m['path'],m['lines'])]) for m in methods}
json_shapes={k:P+'shape/json/'+hash(k) for k,t in M['types'].items() if t['kind']=='StructType'}
def jsonshape(typ,evidence):
 typ=(typ or '').lstrip('*')
 if typ in json_shapes:return json_shapes[typ]
 if typ.startswith('[]'):
  if P+'shape/json-array/'+hash(typ) in R:return P+'shape/json-array/'+hash(typ)
  return add('shape','json-array/'+hash(typ),representation='wire',label='Declared JSON array '+typ,encoding='json',container='array',items=jsonshape(typ[2:],evidence),fields=[],completeness='closed',gaps=[],evidence=evidence)
 if typ in ['string','bool','int','int32','int64','uint32','uint64','float32','float64','byte']:
  if P+'shape/json-scalar/'+hash(typ) in R:return P+'shape/json-scalar/'+hash(typ)
  return add('shape','json-scalar/'+hash(typ),representation='wire',label='Declared JSON scalar '+typ,encoding='json',wireType=typ,fields=[],completeness='closed',gaps=[],evidence=evidence)
 if typ in M['types'] and M['types'][typ].get('alias'):return jsonshape(M['types'][typ]['alias'],evidence)
 sid=P+'shape/json-external/'+hash(typ)
 if sid in R:return sid
 g=gap(sid,'json-external/'+hash(typ),'source_schema_boundary','Exact source field type '+typ+' has no fully expanded generic/map/imported JSON schema here; source type is retained.','Use actual source declaration and caller construction; resolve effective codec/alias/container separately.',evidence)
 return add('shape','json-external/'+hash(typ),representation='wire',label='Partial declared JSON '+typ,encoding='json',fields=[],completeness='partial',gaps=[g],evidence=evidence)
for typ,sid in json_shapes.items():
 t=M['types'][typ];evidence=[ev(t['path'],t['lines'])];fields=[];gs=[]
 for f in t['fields']:
  name=f['name']
  if not name or not name[0].isupper():continue
  tag=re.search(r'json:"([^"]*)"',f['tag'] or '');parts=tag[1].split(',') if tag else [name]
  if parts[0]=='-':continue
  fields.append(dict(name=parts[0] or name,type=f['type'],status='declared',optional='omitempty' in parts,shape=jsonshape(f['type'],[ev(t['path'],f['lines'])]),evidence=[ev(t['path'],f['lines'])]))
 add('shape','json/'+hash(typ),representation='wire',label='Source declared JSON '+typ,encoding='json',fields=fields,completeness='partial' if any(f['name'] is None for f in t['fields']) else 'closed',gaps=[runtimeGap] if any(f['name'] is None for f in t['fields']) else [],evidence=evidence)
def part(name,shape=None,sourceShape=None,presence=None,evidence=None,content='application/json'):
 return dict(part=name,presence=presence or ('present' if shape else 'unresolved'),shape=shape,sourceShape=sourceShape,contentType=content,gaps=[] if shape or presence=='none' else [runtimeGap],evidence=evidence or anchor('internal/api/httpserver/routes.go'))
def expose(key,m,trigger,protocol,verb,address,evidence,request=None,responses=None):
 eid=add('entry',key,logicalId='policy-admin:'+trigger+':'+verb+':'+address,trigger=trigger,method=verb,path=address,implementation=m['implementation'],evidence=evidence)
 contract=add('interface_contract','entry/'+key,component=api,protocol=protocol,name=verb+' '+address,method=verb,path=address,authority='source_declared',request=request or [],responses=responses or [],gaps=[runtimeGap],evidence=evidence)
 add('entry_binding',key,entry=eid,execution=executions[m['implementation']],contract=contract,gaps=[runtimeGap],evidence=evidence);return dict(entry=eid,implementation=m['implementation'],contract=contract,trigger=trigger,method=verb,path=address)
entryAudit=[];routeMethod=method('internal/api/httpserver/routes.go','AddRoutes');routeNode=nodes[routeMethod['key']]
def join(a,b):return '/'+('/'.join([a.strip('/'),b.strip('/')])).lstrip('/')
def routes(n,prefix=''):
 if not isinstance(n,dict):return
 if n.get('kind')=='CallExpr' and n['Fun']['kind']=='SelectorExpr':
  name=tx(n['Fun']['Sel']);args=n.get('Args',[])
  if name=='Route' and len(args)==2 and args[0]['kind']=='BasicLit' and args[1]['kind']=='FuncLit':routes(args[1]['Body'],join(prefix,json.loads(args[0]['Value'])));return
  if name in ['Get','Post','Put','Delete'] and len(args)==2:
   address=join(prefix,json.loads(args[0]['Value']));target=args[1];e=[ev(routeMethod['path'],n['lines'])];m=None
   if target['kind']=='FuncLit':m=B[routeMethod['path']+':'+str(target['start'])]
   elif tx(target)=='r.controller.UpdatePolicy':m=method('internal/api/httpserver/controller/controller.go','UpdatePolicy')
   else:
    key='external-route/'+hash(str(n['start']));iid=add('implementation',key,logicalId='source imported handler registration '+tx(target),scope=source,entry=P+'operation/'+key+'/entry',parameters=[],returnKind='unresolved',evidence=e);op=add('operation',key+'/entry',owner=iid,action='entry',label='Imported source handler registration '+tx(target),resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=e);add('operation',key+'/opaque',owner=iid,action='opaque',label='Imported handler body unavailable: '+tx(target),resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=e);add('transition',key,owner=iid,**{'from':op,'to':P+'operation/'+key+'/opaque'},on='normal',condition=None,values=[],evidence=e);m=dict(implementation=iid);executions[iid]=add('execution_binding',key,implementation=iid,component=api,basis='source_declared',artifactBinding=None,gaps=[runtimeGap],evidence=e)
   request=[];responses=[]
   if tx(target)=='r.controller.UpdatePolicy':
    typ='github.com/volvo-cars/cce-policy-admin/internal/api/httpserver/controller::UpdatePolicyPayload';request=[part('body',json_shapes[typ],shapeids[typ],evidence=e)];err='github.com/volvo-cars/cce-policy-admin/internal/api/httpserver/respond::ErrorResponse';response='github.com/volvo-cars/cce-policy-admin/internal/api/httpserver/respond::Response'
    responses=[dict(status=str(status),body=part('body',json_shapes[err] if status!=200 else json_shapes[response],shapeids[err] if status!=200 else shapeids[response],evidence=e),meaning='Source requested response status and local wrapper; JSON encoding/header/write errors remain source branches',evidence=e) for status in [200,400,500]]
   entryAudit.append(expose('rest/'+hash(verb:=name.upper()+address),m,'rest','http',name.upper(),address,e,request,responses));claim('route/'+hash(str(n['start'])),m['implementation'],'Actual chi registration '+tx(n)+'. Source middleware is Compress(5) only; no source auth wrapper is established. Empty handler has no source response write; imported net/http default semantics are not synthesised. Swagger callback is imported body, not another local implementation.',[entryAudit[-1]['entry']],e);return
 for key,value in n.items():
  if key=='text':continue
  if isinstance(value,dict):routes(value,prefix)
  elif isinstance(value,list):
   for v in value:routes(v,prefix)
routes(routeNode['Body'])
main=method('cmd/policy-admin/main.go','main');entryAudit.append(expose('process/main',main,'process','process','PROCESS','source:cmd/policy-admin/main.go:main',[ev(main['path'],main['lines'])]))
# Actual Fx lifecycle callback literals remain separate from registration-time execution.
for m in methods:
 if not m['name'].startswith('<lambda') or m['path'] not in ['internal/app/app.go','internal/app/watermill.go']:continue
 node=nodes[m['key']];parents=[n for n in walknode(F[m['path']]['ast']) if n.get('kind')=='KeyValueExpr' and n.get('Value',{}).get('start')==node['start'] and tx(n['Key']) in ['OnStart','OnStop']]
 if parents:
  kind=tx(parents[0]['Key']);entryAudit.append(expose('lifecycle/'+hash(m['key']),m,'startup' if kind=='OnStart' else 'callback','lifecycle' if kind=='OnStart' else 'callback','STARTUP' if kind=='OnStart' else 'CALLBACK','fx:'+m['path']+':'+kind+':'+str(node['start']),[ev(m['path'],parents[0]['lines'])]));claim('hook/'+hash(m['key']),m['implementation'],'Actual lifecycle hook '+kind+' registration. Callback body does not execute while Hook literal is constructed. Fx availability/default missing pool provider, supplied options and actual activation remain separate.',[entryAudit[-1]['entry']],anchor(m['path']))
# Source Fx provider registration supports a constructor-body callback exposure, not an eager ordinary call.
newBlob=method('internal/database/blobstorage/blobstorage.go','NewBlobStorage');entryAudit.append(expose('provider/blob',newBlob,'callback','callback','CALLBACK','fx:internal/app/app.go:blobstorage.NewBlobStorage',anchor('internal/app/app.go')+[ev(newBlob['path'],newBlob['lines'])]));claim('provider/blob',newBlob['implementation'],'NewBlobStorage is source-registered as concrete provider and as command.X in Fx.As. This one callable source exposure retains both registrations without claiming a count of constructed instances or eager provider execution.',[entryAudit[-1]['entry']],anchor('internal/app/app.go'))
resource=add('resource','azure-rulesets',label='Policy Admin rulesets blobs',technology='Azure Blob Storage',declaredDatabase=None,physicalLocation=None,shapes=list(wireShapes.values()),gaps=[runtimeGap],evidence=anchor('internal/database/blobstorage/blobstorage.go'),address=dict(basis='source_declared',connectionSetting='AZURE_STORAGE_SERVICE_URL + AZURE_STORAGE_ACCOUNT_NAME/AZURE_STORAGE_ACCOUNT_KEY',database=None,table=None,container='AZURE_STORAGE_CONTAINER',path='rulesets/{ConfigRuleSet.Id}',key='ConfigRuleSet.Id'))
add('resource_binding','azure-rulesets',resource=resource,component=blob,role='storage',gaps=[runtimeGap],evidence=anchor('internal/app/config.go')+anchor('internal/database/blobstorage/blobstorage.go'))
ioAudit=[]
for row in CALLS:
 if row['path']!='internal/database/blobstorage/blobstorage.go' or not re.search(r's\.client\.(CreateContainer|UploadBuffer)\(',row['source']):continue
 evidence=[ev(row['path'],row['lines'])];fields=[dict(name='argument'+str(i),type=VT.get(v) or 'source actual',status='declared',**({'shape':R[v]['shape']} if R[v]['shape'] else {}),evidence=evidence) for i,v in enumerate(row['arguments'])];sig=add('shape','signature/'+hash(row['operation']),representation='constructed',label=row['source']+' source argument-list projection',fields=fields,completeness='closed',gaps=[],evidence=evidence,container='object');contract=add('interface_contract','io/'+hash(row['operation']),component=blob,protocol='azure-blob-sdk',name=row['source'],method=None,path=None,authority='caller_construction',request=[part('record',None,sig,evidence=evidence)],responses=[],gaps=[runtimeGap],evidence=evidence)
 effect=add('effect','io/'+hash(row['operation']),owner=row['owner'],operation=row['operation'],effect='write',resource=resource,modality='source_traced',representation='logical',selection=row['arguments'][1:3],payload=row['arguments'][3:4],evidence=evidence)
 interaction=add('interaction','io/'+hash(row['operation']),owner=row['owner'],execution=executions[row['owner']],operation=row['operation'],target=blob,targetEntry=None,contract=contract,effect=effect,handoff=None,mode='write',boundary='network',waitsFor='store_result',condition='Source constructor configured Azure client/container; normal synchronous SDK call and source error guard, no durable/shared transaction guarantee.',requestBindings=[dict(part='record',path=['argument'+str(i)],value=v,transform='Exact source argument order projection; not an allocated runtime signature object or guessed HTTP body') for i,v in enumerate(row['arguments'])],responseBindings=[],gaps=[runtimeGap],evidence=evidence)
 ioAudit.append(dict(**row,interaction=interaction,effect=effect,contract=contract,targetComponent=blob))
(D/'entries-ledger.json').write_text(json.dumps(entryAudit,indent=2)+'\n');(D/'io-ledger.json').write_text(json.dumps(ioAudit,indent=2)+'\n')
