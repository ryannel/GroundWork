"""Finite native transcription of the standalone migration's actual Python idioms."""
import ast
pyPath='migrate_mongodb_to_postgres.py';pyText=(SRC/pyPath).read_text();tree=ast.parse(pyText);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)};pyFrames={};pyCalls=[];pySQL=[];pyIO=[];pyBodies=[]
migrationHost=component('python-migration','Policy Admin standalone MongoDB to PostgreSQL migration','service','Python / pymongo / pg8000',[pyPath]);mongo=component('migration-mongo','Configured migration MongoDB','store','MongoDB; filter-service-db',[pyPath]);postgres=component('migration-postgres','Configured migration PostgreSQL','store','PostgreSQL / pg8000',[pyPath])
def pev(n):return [ev(pyPath,[getattr(n,'lineno',1),getattr(n,'end_lineno',len(pyText.splitlines()))])]
for name,node in [('module',tree)]+list(functions.items()):
 key='py/'+name;mid=P+'implementation/'+key;entry=P+'operation/'+key+'/entry';params=[add('value',key+'/p/'+a.arg,owner=mid,definition=entry,role='parameter',representation='source',label='Python formal '+a.arg,shape=None,accessPath=[],evidence=pev(a)) for a in getattr(getattr(node,'args',None),'args',[])];value=name in ['prepare_compress','prepare_decompress'];add('implementation',key,logicalId='migrate_mongodb_to_postgres.py:'+name,scope=source,entry=entry,parameters=params,returnKind='value' if value else 'void',evidence=pev(node));add('operation',key+'/entry',owner=mid,action='entry',label='Standalone Python '+name,resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=pev(node));execution=add('execution_binding',key,implementation=mid,component=migrationHost,basis='source_declared',artifactBinding=None,gaps=[runtimeGap],evidence=pev(node));pyFrames[name]=dict(owner=mid,entry=entry,params=params,node=node,execution=execution)
pyResources={};pyResourceShapes={}
for name,node in functions.items():
 sqls=[n.args[0].value for n in ast.walk(node) if isinstance(n,ast.Call) and ast.unparse(n.func)=='pg_cursor.execute' and n.args and isinstance(n.args[0],ast.Constant)];ddl=next((s for s in sqls if s.lstrip().startswith('CREATE')),None)
 if not ddl:continue
 table=re.search(r'CREATE TABLE IF NOT EXISTS\s+(\w+)',ddl).group(1);fields=[]
 for col,typ in re.findall(r'^\s*(\w+)\s+(TEXT|BOOLEAN|BYTEA|JSONB|TIMESTAMP)\b',ddl,re.M):fields.append(dict(name=col,type=typ,status='declared',evidence=pev(node)))
 sid=add('shape','py/sql/'+table,representation='source',label='Migration DDL '+table,encoding='relational',container='object',fields=fields,completeness='closed',gaps=[],evidence=pev(node));pyResourceShapes[table]=sid
 claim('py/ddl/'+table,sid,'Exact source migration DDL, including primary-key/type constraints: '+ddl+'. This is intended migration schema, not an observed database.',[sid],pev(node))
 res=add('resource','py/sql/'+table,label='Migration target table '+table,technology='PostgreSQL',declaredDatabase='POSTGRES_DBNAME',physicalLocation=None,shapes=[sid],gaps=[runtimeGap],evidence=pev(node),address=dict(basis='source_declared',connectionSetting='POSTGRES_HOST/PORT/USER/PASSWORD',database='config POSTGRES_DBNAME',table=table,container=None,path=None,key=None));add('resource_binding','py/sql/'+table,resource=res,component=postgres,role='storage',gaps=[runtimeGap],evidence=pev(node));pyResources[table]=res
for node in ast.walk(tree):
 if isinstance(node,ast.Subscript) and ast.unparse(node.value)=='mongo_db' and isinstance(node.slice,ast.Constant):
  name=node.slice.value
  if ('mongo',name) in pyResources:continue
  res=add('resource','py/mongo/'+name,label='Migration source collection '+name,technology='MongoDB',declaredDatabase='filter-service-db',physicalLocation=None,shapes=[],gaps=[runtimeGap],evidence=pev(node),address=dict(basis='source_declared',connectionSetting='MONGO_DB_CNXSTRING; conditional tlsCAFile MONGO_TLS_CERTIFICATE',database='filter-service-db',table=None,container=name,path=None,key=None));add('resource_binding','py/mongo/'+name,resource=res,component=mongo,role='storage',gaps=[runtimeGap],evidence=pev(node));pyResources[('mongo',name)]=res
class MigrationBody:
 def __init__(self,name):
  self.name=name;self.f=pyFrames[name];self.owner=self.f['owner'];self.front=[(self.f['entry'],'normal',None,[])];self.i=0;self.env={a.arg:v for a,v in zip(getattr(getattr(self.f['node'],'args',None),'args',[]),self.f['params'])};self.parts={};self.sqlWrites=[];self.commits=[];self.collection=None
 def op(self,n,action,label,result=False,**kw):
  self.i+=1;key='py/'+self.name+'/'+str(self.i);oid=add('operation',key,owner=self.owner,action=action,label=label,resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=pev(n),**kw)
  for j,(f,on,c,values) in enumerate(self.front):add('transition',key+'/'+str(j),owner=self.owner,**{'from':f,'to':oid},on=on,condition=c,values=values,evidence=pev(n))
  self.front=[(oid,'normal',None,[])];v=None
  if result:v=add('value',key,owner=self.owner,definition=oid,label=label,role='definition',representation='source',shape=None,accessPath=[],evidence=pev(n));R[oid]['result']=v
  return oid,v
 def compute(self,n,label,values=()):
  op,v=self.op(n,'compute',label,True)
  for i,x in enumerate(values):
   if x:add('flow','py/'+hash(op+str(i)),owner=self.owner,**{'from':x,'to':v},at=op,transform=label,gaps=[],assumptions=[],evidence=pev(n))
  return v
 def expr(self,n,need=True):
  if n is None:return None
  label=ast.unparse(n)
  if isinstance(n,ast.Name):
   if n.id in self.env:return self.env[n.id]
   v=self.compute(n,'Python module-global/source lookup '+n.id);self.env[n.id]=v;return v
  if isinstance(n,ast.Constant):return self.compute(n,'Python literal '+repr(n.value))
  if isinstance(n,ast.Call):
   receiver=self.expr(n.func.value) if isinstance(n.func,ast.Attribute) else None;args=[self.expr(a) for a in n.args];kwargs={k.arg or '**':self.expr(k.value) for k in n.keywords};fn=ast.unparse(n.func);target=pyFrames.get(fn);result=need and (not target or target['owner'] in [pyFrames[x]['owner'] for x in ['prepare_compress','prepare_decompress']]);op,v=self.op(n,'call','Python invoke '+label,result);rid=add('resolution','py/'+hash(op),owner=self.owner,requestedArtifact=None,basis='source_local' if target else 'unresolved',target=target['owner'] if target else None,candidates=[],binding=None,evidence=pev(n));R[op]['resolution']=rid
   if target:R[op]['bindings']=[dict(parameter=p,value=a) for p,a in zip(target['params'],args)]
   elif receiver:R[op]['receiver']=receiver
   row=dict(owner=self.owner,operation=op,expression=label,callee=fn,arguments=args,keywords=kwargs,result=v,receiver=receiver,lines=[n.lineno,n.end_lineno],target=target['owner'] if target else None);pyCalls.append(row);claim('py/call/'+hash(op),self.owner,'Exact migration call association '+str(row)+'. No generic unknown argument→result flow or external formals are fabricated.',[op,*args,*kwargs.values()]+([receiver] if receiver else [])+([v] if v else []),pev(n))
   if fn=='pg_cursor.execute':
    sql=n.args[0].value;table=re.search(r'(?:CREATE TABLE IF NOT EXISTS|INSERT INTO)\s+(\w+)',sql).group(1);effect=add('effect','py/'+hash(op),owner=self.owner,operation=op,effect='write',resource=pyResources[table],modality='source_traced',representation='logical',selection=[],payload=args[1:],evidence=pev(n));fields=[]
    if len(n.args)>1:
     columns=[c.strip() for c in re.search(r'INSERT INTO\s+\w+\s*\((.*?)\)\s*VALUES',sql,re.S).group(1).split(',')];items=self.parts[args[1]]
     fields=[dict(path=[col],value=value,transform='Exact migration INSERT column/placeholder/source tuple operand '+ast.unparse(operand)) for col,value,operand in zip(columns,items,n.args[1].elts)];R[effect]['payload']=items;conflict=re.search(r'ON CONFLICT\s*\((.*?)\)',sql);R[effect]['selection']=[f['value'] for f in fields if conflict and f['path'][0] in conflict.group(1).split(',')]
    self.sqlWrites.append(dict(operation=op,effect=effect,table=table,fields=fields,ddl=not bool(fields),sql=sql));pySQL.append(dict(**self.sqlWrites[-1],owner=self.owner,lines=row['lines']));self.io(row,n,postgres,effect,pyResources[table],'write')
   elif fn=='mongo_collection.find':
    res=pyResources[('mongo',self.collection)];effect=add('effect','py/'+hash(op),owner=self.owner,operation=op,effect='read',resource=res,modality='source_traced',representation='logical',selection=[],payload=[],evidence=pev(n));self.io(row,n,mongo,effect,res,'read')
   elif fn=='pg_conn.commit':self.commits.append(op);self.io(row,n,postgres,None,None,'unknown')
   elif fn=='pg8000.connect':self.io(row,n,postgres,None,None,'unknown')
   return v
  if isinstance(n,(ast.Tuple,ast.List)):
   vals=[self.expr(e) for e in n.elts];v=self.compute(n,'Python ordered '+type(n).__name__+' '+label,vals);self.parts[v]=vals;return v
  if isinstance(n,ast.Dict):return self.compute(n,'Python dictionary construction '+label,[self.expr(v) for v in n.values])
  if isinstance(n,ast.Subscript):return self.compute(n,'Python indexed projection '+label,[self.expr(n.value),self.expr(n.slice)])
  if isinstance(n,ast.Attribute):return self.compute(n,'Python field projection '+label,[self.expr(n.value)])
  return self.compute(n,'Python source expression '+label,[self.expr(x) for x in ast.iter_child_nodes(n) if isinstance(x,ast.expr)])
 def io(self,row,n,target,effect,resource,mode):
  e=pev(n);values=row['arguments']+list(row['keywords'].values());sig=add('shape','py/signature/'+hash(row['operation']),representation='constructed',label='Migration '+row['callee']+' source argument-list projection',fields=[dict(name='argument'+str(i),type='source actual',status='declared',evidence=e) for i in range(len(values))],completeness='closed',gaps=[],evidence=e,container='object');contract=add('interface_contract','py/io/'+hash(row['operation']),component=target,protocol='mongodb-driver' if target==mongo else 'postgresql-driver',name=row['expression'],method=None,path=None,authority='caller_construction',request=[part('record',None,sig,evidence=e)],responses=[],gaps=[runtimeGap],evidence=e);iid=add('interaction','py/io/'+hash(row['operation']),owner=self.owner,execution=self.f['execution'],operation=row['operation'],target=target,targetEntry=None,contract=contract,effect=effect,handoff=None,mode=mode,boundary='network',waitsFor='store_result',condition='Standalone migration source invocation only; configuration/runtime codec/driver and durable server acknowledgement remain unresolved.',requestBindings=[dict(part='record',path=['argument'+str(i)],value=v,transform='Actual source positional/keyword/spread order, not a wire body or imported formal') for i,v in enumerate(values)],responseBindings=[],gaps=[runtimeGap],evidence=e);pyIO.append(dict(**row,interaction=iid,resource=resource,effect=effect,targetComponent=target))
 def stmts(self,ns):
  for n in ns:
   if not self.front:return
   if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef)):continue
   if isinstance(n,ast.Assign):
    v=self.expr(n.value)
    for t in n.targets:
     if isinstance(t,ast.Name):self.env[t.id]=v
    if isinstance(n.value,ast.Subscript) and ast.unparse(n.value.value)=='mongo_db':self.collection=n.value.slice.value
   elif isinstance(n,ast.Expr):self.expr(n.value,False)
   elif isinstance(n,ast.Return):
    value=self.expr(n.value);op,_=self.op(n,'return','Python return '+ast.unparse(n));R[op].update(result=value,exit='normal');self.front=[]
   elif isinstance(n,ast.If):
    cond=self.expr(n.test);br,_=self.op(n,'branch','Python if '+ast.unparse(n.test));env=self.env.copy();ends=[]
    for truth,body in [('true',n.body),('false',n.orelse)]:self.env=env.copy();self.front=[(br,'condition',truth+': '+ast.unparse(n.test),[cond])];self.stmts(body);ends.extend(self.front)
    # Only module constructor client alternatives require a union. Helper data is not branch-written here.
    rows=[self.env.copy()];self.env=env;self.front=ends
   elif isinstance(n,ast.For):
    iterable=self.expr(n.iter);br,_=self.op(n,'branch','Python for each '+ast.unparse(n.target)+' in '+ast.unparse(n.iter));env=self.env.copy();self.front=[(br,'condition','iteration exists',[iterable])];item=self.compute(n,'Migration cursor iteration item '+ast.unparse(n.target),[iterable]);self.env[ast.unparse(n.target)]=item;self.stmts(n.body);ends=self.front
    for f,on,c,values in ends:add('transition','py/loop/'+hash(f+br),owner=self.owner,**{'from':f,'to':br},on='iterate',condition='next imported cursor item',values=values,evidence=pev(n))
    self.env=env;self.front=[(br,'condition','iteration exhausted',[iterable])]
   else:raise AssertionError(('Migration actual syntax needs source review',type(n).__name__,ast.unparse(n)))
 def build(self):
  self.stmts(self.f['node'].body)
  if self.front:op,_=self.op(self.f['node'],'return','Python implicit None completion');R[op]['exit']='normal'
  for write in self.sqlWrites:
   stage=R[write['operation']];commit=next(c for c in self.commits if R[c]['evidence'] and R[R[c]['evidence'][0]]['lines'][0]>=R[stage['evidence'][0]]['lines'][0]);add('storage_write','py/'+hash(write['operation']),owner=self.owner,effect=write['effect'],stagedAt=write['operation'],acknowledgedAt=commit,mode='unknown' if write['ddl'] else 'insert',acknowledgement='ignored_result',atomicity='store_call_only',fields=write['fields'],gaps=[runtimeGap],evidence=stage['evidence'],condition='Source execute then explicit pg_conn.commit after DDL or data loop. ON CONFLICT DO NOTHING does not prove insertion. Normal imported commit return is not replication/durability proof; preceding DDL commit can remain after later failure.')
  pyBodies.append(dict(name=self.name,implementation=self.owner,sourceLines=R[self.f['entry']]['evidence'],returnKind=R[self.owner]['returnKind'],calledByDefaultMain=self.name in ['module','main','migrate_config_policy','migrate_components_policy']))
for name in pyFrames:MigrationBody(name).build()
f=pyFrames['module'];eid=add('entry','py/process',logicalId='policy-admin:migration:process',trigger='process',method='PROCESS',path='source:migrate_mongodb_to_postgres.py:__main__',implementation=f['owner'],evidence=anchor(pyPath));contract=add('interface_contract','py/process',component=migrationHost,protocol='process',name='Standalone migration __main__',method='PROCESS',path='source:migrate_mongodb_to_postgres.py:__main__',authority='source_declared',request=[],responses=[],gaps=[runtimeGap],evidence=anchor(pyPath));add('entry_binding','py/process',entry=eid,execution=f['execution'],contract=contract,gaps=[runtimeGap],evidence=anchor(pyPath));entryAudit.append(dict(entry=eid,implementation=f['owner'],contract=contract,trigger='process',method='PROCESS',path='source:migrate_mongodb_to_postgres.py:__main__'))
claim('py/default-main',f['owner'],'Standalone module opens configured Mongo/PostgreSQL connections on import before __main__ guard. Main invokes only migrate_config_policy and migrate_components_policy, then closes cursor/PostgreSQL/Mongo. Six other migration routines and two preparation helpers are available source bodies; declarations do not imply invocation. DDL commits before data insertion commit. This script does not implement the Go app in-memory repositories or establish a shared deployed database identity with other repo pins.',[eid]+[x['owner'] for x in pyFrames.values()],anchor(pyPath))
for name,data in [('python-body',pyBodies),('python-call',pyCalls),('migration-sql',pySQL),('migration-io',pyIO)]: (D/(name+'-ledger.json')).write_text(json.dumps(data,indent=2)+'\n')
(D/'entries-ledger.json').write_text(json.dumps(entryAudit,indent=2)+'\n')
