"""Exact local source containers/aliases; native limitations stay explicit, no fake payload fields."""
SCHEMA_ROWS=[];building=set()
def source_shape(typ,evidence):
 if not typ:return None
 base=typ.lstrip('*');existing=shapeids.get(base)
 if existing:return existing
 key=hash(base);sid=P+'shape/source-type/'+key
 if sid in R:return sid
 if base in building:return sid
 building.add(base)
 scalar=base in ['bool','string','int','int32','int64','uint','uint32','uint64','byte','rune','float32','float64','uintptr','untyped-int','untyped-float','untyped-rune']
 if base.startswith('[]'):
  item=source_shape(base[2:],evidence);add('shape','source-type/'+key,representation='source',label='Go source slice '+base,wireType=base,container='array',items=item,fields=[],completeness='closed',gaps=[],evidence=evidence)
 elif '[' in base and (base.split('[',1)[0] in M['types'] or any(t['package']=='github.com/volvo-cars/cce-policy-admin/'+str(Path(R[evidence[0]]['path']).parent) and t['name']==base.split('[',1)[0] for t in M['types'].values())):
  genericbase=base.split('[',1)[0];matches=[t for t in M['types'].values() if t['key']==genericbase or t['package']=='github.com/volvo-cars/cce-policy-admin/'+str(Path(R[evidence[0]]['path']).parent) and t['name']==genericbase];decl=matches[0] if len(matches)==1 else None
  if not decl:raise AssertionError(('Generic declaration resolution ambiguous',base))
  g=gap(sid,'generic-template/'+key,'source_generic_projection','Local generic wrapper '+base+' has available source fields retained as a declaration template. Actual inferred type-variable substitution/embedded JSON flattening is not mechanically solved.','Use exact caller bindings and available generic declaration; do not substitute an inner DTO for the outer wrapper.',evidence)
  add('shape','source-type/'+key,representation='source',label='Source generic wrapper '+base,wireType=base,container='object',fields=[dict(name=f['name'] or '<embedded:'+f['sourceType']+'>',type=f['type'],status='declared',evidence=[ev(decl['path'],f['lines'])]) for f in decl['fields']],completeness='partial',gaps=[g],evidence=evidence)
 elif scalar:add('shape','source-type/'+key,representation='source',label='Go source scalar '+base,wireType=base,fields=[],completeness='closed',gaps=[],evidence=evidence)
 else:
  reason='Exact source type expression '+base+' retained. '
  if base.startswith('map['):reason+='Native shape has no typed map-key/value slots; exact Go declaration is retained as a claim, not fabricated object fields.'
  elif 'func(' in base or 'func (' in base:reason+='Callable source signature is retained; native data shapes do not encode delegate dispatch, captures or scheduling.'
  else:reason+='External or generic type structure is not established by this pinned source declaration; unavailable fields are not invented.'
  g=gap(sid,'source-type/'+key,'Source type schema boundary',reason,'Use exact declaration and local source associations; resolve imported artefact or native representation limit before complete structural claims.',evidence)
  add('shape','source-type/'+key,representation='source',label=base,wireType=base,fields=[],completeness='partial',gaps=[g],evidence=evidence,**({'container':'object','additionalProperties':True} if base.startswith('map[') else {}))
 building.remove(base);shapeids[base]=sid;return sid
for key,t in M['types'].items():
 sid=shapeids[key];shape=R[sid];e=shape['evidence'];oldgaps=list(shape['gaps'])
 if t['kind']=='ArrayType' and (t.get('alias') or '').startswith('[]'):
  item=source_shape(t['alias'][2:],e);shape.update(container='array',items=item,fields=[],completeness='closed',gaps=[])
 elif t['kind'] in ['Ident','SelectorExpr'] and t.get('alias'):
  underlying=source_shape(t['alias'],e);shape.update(wireType=t['alias'],completeness='closed' if t['alias'] in ['string','bool','int','int32','int64','byte'] else 'partial')
  if shape['completeness']=='closed':shape['gaps']=[]
  add('claim','underlying/'+hash(key),owner=sid,statement='Exact Go declared underlying type: '+t['source']+'. Named type method identity remains distinct; this is not a constructed wrapper object.',basis='source_declared',inputs=[sid,underlying],assumptions=[],evidence=e)
 elif t['kind']=='MapType':
  shape.update(container='object',additionalProperties=True)
  add('claim','map/'+hash(key),owner=sid,statement='Exact source typed map declaration: '+t['source']+'. Native shape keys/values remain an explicit schema representation limit.',basis='source_declared',inputs=[sid],assumptions=[],evidence=e)
 for f,src in zip(shape['fields'],t['fields']):
  if src['name'] is None:f['name']=src['sourceType'].lstrip('*').split('.')[-1].split('[')[0]
  nested=source_shape(src['type'],[ev(t['path'],src['lines'])])
  if nested:f['shape']=nested
 if shape['completeness']=='closed':
  for old in oldgaps:
   if old not in shape['gaps']:None # Shared declaration/runtime gaps remain globally referenced
 SCHEMA_ROWS.append({'shape':sid,'path':t['path'],'lines':t['lines'],'sourceType':key,'kind':t['kind'],'declaration':t['source'],'completeness':shape['completeness'],'gaps':shape['gaps']})
for value in [x for x in R.values() if x['kind']=='value']:
 typ=VT.get(value['id'])
 if typ and not value['shape']:value['shape']=source_shape(typ,value['evidence'])
(D/'source-shape-ledger.json').write_text(json.dumps(SCHEMA_ROWS,indent=2)+'\n')
