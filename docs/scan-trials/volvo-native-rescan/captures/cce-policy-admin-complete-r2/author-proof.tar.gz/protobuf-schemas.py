"""Read literal generated descriptor bytes, without importing generated source or protoc."""
from google.protobuf.descriptor_pb2 import FileDescriptorProto,FieldDescriptorProto
PROTO={};PB_ENUMS={};ENUM_EVIDENCE={};DESCRIPTORS=[];wireShapes={};pbSchemaAudit=[]
for path,f in F.items():
 if not path.endswith('.pb.go'):continue
 for node in walknode(f['ast']):
  if node.get('kind')!='ValueSpec' or not any(x['Name'].endswith('_rawDesc') for x in node.get('Names',[])):continue
  values=node.get('Values',[])
  if not values or values[0].get('kind')!='CompositeLit':continue
  raw=bytes(int(x['Value'],0) for x in values[0].get('Elts',[]));fd=FileDescriptorProto();fd.ParseFromString(raw);e=[ev(path,node['lines'])]
  def enum(en,parent):
   PB_ENUMS[parent+'.'+en.name]=[(x.name,x.number) for x in en.value];ENUM_EVIDENCE[parent+'.'+en.name]=e
  def message(m,parent):
   full=parent+'.'+m.name;assert full not in PROTO;PROTO[full]=dict(message=m,path=path,evidence=e)
   for n in m.nested_type:message(n,full)
   for n in m.enum_type:enum(n,full)
  for x in fd.message_type:message(x,fd.package)
  for x in fd.enum_type:enum(x,fd.package)
  DESCRIPTORS.append(dict(path=path,lines=node['lines'],file=fd.name,package=fd.package,syntax=fd.syntax,imports=list(fd.dependency),services=[x.name for x in fd.service],sha256=hashlib.sha256(raw).hexdigest()))
  add('claim','descriptor/'+hash(path),owner=source,statement='Stored generated literal FileDescriptorProto read without executing application/generated source: '+str(fd)+'. Generated artifact/runtime/deployment correspondence is separate.',basis='source_declared',inputs=[source],assumptions=[],evidence=e)
for name,p in PROTO.items():wireShapes[name]=add('shape','protobuf/'+name,representation='wire',label=name+' stored protobuf declaration',fields=[],completeness='closed',gaps=[],evidence=p['evidence'],wireType=name,encoding='protobuf',container='object',reservedNames=list(p['message'].reserved_name),reservedTags=[v for r in p['message'].reserved_range for v in range(r.start,r.end)])
for name,p in PROTO.items():
 fields=[]
 for f in p['message'].field:
  typ=f.type_name.lstrip('.') or FieldDescriptorProto.Type.Name(f.type);item=dict(name=f.name,type=typ,status='declared',wireTag=f.number,evidence=p['evidence']);sid=wireShapes.get(typ)
  if f.type_name and typ not in PROTO and typ not in PB_ENUMS:
   externalID=P+'shape/protobuf-external/'+hash(typ)
   if externalID not in R:
    g=gap(externalID,'protobuf-external/'+hash(typ),'external_schema_source','Generated descriptor imports '+typ+' but exact schema source is absent from this pinned repository.','Resolve exact protobuf dependency schema/artifact; do not invent fields or wire runtime.',p['evidence']);add('shape','protobuf-external/'+hash(typ),representation='wire',label='Imported protobuf '+typ+' source unavailable',wireType=typ,encoding='protobuf',fields=[],completeness='partial',gaps=[g],evidence=p['evidence'])
   sid=externalID;R[wireShapes[name]]['gaps']=list(dict.fromkeys(R[wireShapes[name]]['gaps']+R[externalID]['gaps']))
  if f.proto3_optional:item['optional']=True
  if typ in PB_ENUMS:item['enum']=list(dict.fromkeys(v for _,v in PB_ENUMS[typ]))
  if f.label==FieldDescriptorProto.LABEL_REPEATED:
   if not sid:sid=add('shape','protobuf-item/'+hash(name+f.name),representation='wire',label=typ+' protobuf item declaration',fields=[],completeness='closed',gaps=[],evidence=p['evidence'],wireType=typ)
   sid=add('shape','protobuf-array/'+hash(name+f.name),representation='wire',label=name+'.'+f.name+' repeated '+typ,fields=[],completeness='closed',gaps=[],evidence=p['evidence'],container='array',items=sid);item['type']='repeated '+typ
  if sid:item['shape']=sid
  fields.append(item)
 R[wireShapes[name]]['fields']=fields
 add('claim','protobuf/'+hash(name),owner=wireShapes[name],statement='Exact stored descriptor message '+str(p['message'])+'. Explicit optional, default, JSON-name, enum, oneof and deprecation metadata are source declarations; generated codec/wire execution separate.',basis='source_declared',inputs=[wireShapes[name]],assumptions=[],evidence=p['evidence'])
 pbSchemaAudit.append(dict(fullName=name,wireShape=wireShapes[name],path=p['path'],fields=[dict(name=f.name,type=f.type_name or FieldDescriptorProto.Type.Name(f.type),number=f.number,cardinality=f.label,proto3Optional=f.proto3_optional,deprecated=f.options.deprecated,jsonName=f.json_name) for f in p['message'].field]))
for name,values in PB_ENUMS.items():add('claim','protobuf-enum/'+hash(name),owner=source,statement='Stored protobuf enum symbols/numbers '+name+': '+str(values)+'. Enum zero is not a positive message field tag.',basis='source_declared',inputs=[source],assumptions=[],evidence=ENUM_EVIDENCE[name])
(D/'protobuf-descriptor-ledger.json').write_text(json.dumps(DESCRIPTORS,indent=2)+'\n');(D/'protobuf-schema-ledger.json').write_text(json.dumps(pbSchemaAudit,indent=2)+'\n')
