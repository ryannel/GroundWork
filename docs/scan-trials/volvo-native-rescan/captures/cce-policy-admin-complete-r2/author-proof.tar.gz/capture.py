"""Mutable source-owned Go checkpoint. Syntax is an aid; no acceptance claim yet."""
import json,hashlib,re,collections
from pathlib import Path
D=Path(__file__).resolve().parent;P='volvo/cce-policy-admin/88a3512f0307/local-r2/';PIN='88a3512f0307016b7b1dbcbc729c743fe83ed368';REPO='volvo-cars/cce-policy-admin';M=json.loads((D/'source-symbols.json').read_text());R={}
def hash(x):return hashlib.sha256(x.encode()).hexdigest()[:18]
def add(kind,key,**kw):
 r=dict(id=P+kind+'/'+key,kind=kind,**kw);old=R.get(r['id']);assert old is None or old==r,('Unequal ID collision',r['id']);R[r['id']]=r;return r['id']
def ev(path,lines):return add('evidence',hash(path+str(lines)),host='github.com',repo=REPO,commit=PIN,path=path,lines=lines,basis='source')
def gap(owner,key,obligation,reason,action,evidence):return add('gap',key,owner=owner,obligation=obligation,reason=reason,action=action,evidence=evidence)
source=add('source_revision','pin',repo=REPO,commit=PIN)
runtimeGap=gap(source,'runtime','external_runtime_correspondence','Exact imported Fx/Chi/Watermill/Azure/codec/runtime implementations and effective deployment are not bound. Local default Fx requires pgxpool.Pool without a visible default provider. Source registration intent does not prove activation.','Resolve exact imports/artifacts and deployment configuration separately.',[ev('internal/app/app.go',[1,124]),ev('go.mod',[1,73])])
shapeids={k:P+'shape/'+hash(k) for k in M['types']}
for key,t in M['types'].items():
 fs=[];evidence=[ev(t['path'],t['lines'])]
 for f in t['fields']:
  typ=f['type'] or f['sourceType'];item=dict(name=f['name'] or '<embedded:'+f['sourceType']+'>',type=typ,status='declared',evidence=[ev(t['path'],f['lines'])]);ref=shapeids.get(typ.lstrip('*'))
  if ref:item['shape']=ref
  fs.append(item)
  if f['tag']:add('claim','tag/'+hash(key+str(f['lines'])),owner=shapeids[key],statement='Exact Go source field/tag '+str(f['name'])+': '+f['tag']+'. Source name and effective imported encoding are distinct.',basis='source_declared',inputs=[shapeids[key]],assumptions=[],evidence=item['evidence'])
 add('shape',hash(key),representation='source',label=key,fields=fs,completeness='closed' if t['kind']=='StructType' else 'partial',gaps=[] if t['kind']=='StructType' else [runtimeGap],evidence=evidence)
 add('claim','type/'+hash(key),owner=shapeids[key],statement='Exact source '+t['kind']+' declaration '+t['source']+'. Alias/interface/generic and generated runtime execution remain explicit source boundaries.',basis='source_declared',inputs=[shapeids[key]],assumptions=[],evidence=evidence)
methods=[]
for m in M['methods']:
 key=hash(m['key']);iid=P+'implementation/'+key;entry=P+'operation/'+key+'/entry';evidence=[ev(m['path'],m['lines'])];params=[]
 for i,p in enumerate(m['parameters']):params.append(add('value',key+'/p/'+str(i),owner=iid,definition=entry,label=(p['name'] or '<unnamed>')+' '+str(p['type']),role='parameter',representation='source',shape=shapeids.get((p['type'] or '').lstrip('*')),accessPath=[],evidence=[ev(m['path'],p['lines'])]))
 attrs={}
 if m['receiver']:
  p=m['receiver'];attrs['receiver']=add('value',key+'/receiver',owner=iid,definition=entry,label=(p['name'] or '<receiver>')+' '+p['type'],role='receiver',representation='source',shape=shapeids.get(p['type'].lstrip('*')),accessPath=[],evidence=[ev(m['path'],p['lines'])])
 add('implementation',key,logicalId=m['path']+':'+str((m['receiver'] or {}).get('type',''))+'.'+m['name']+'('+','.join(str(p['type']) for p in m['parameters'])+')',scope=source,entry=entry,parameters=params,returnKind=m['returnKind'],evidence=evidence,**attrs)
 add('operation',key+'/entry',owner=iid,action='entry',label=m['package']+'.'+m['name'],resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=evidence)
 add('coverage',key,owner=iid,obligation='source_body_review',status='partial',scope='Mutable parse-aided source graph; finite semantic/entry/I/O review remains pending',gaps=[],evidence=evidence)
 methods.append({**m,'implementation':iid,'entry':entry,'parameters':params,'nativeReceiver':attrs.get('receiver')})
exec((D/'go-execution.py').read_text(),globals());expand_working()
exec((D/'source-schemas.py').read_text(),globals())
exec((D/'protobuf-schemas.py').read_text(),globals())
exec((D/'interfaces.py').read_text(),globals())
exec((D/'local-effects.py').read_text(),globals())
exec((D/'write-acks.py').read_text(),globals())
exec((D/'migration.py').read_text(),globals())
exec((D/'review.py').read_text(),globals())
exec((D/'audits.py').read_text(),globals())
exec((D/'configuration-closure.py').read_text(),globals())
(D/'native-method-ledger.json').write_text(json.dumps(methods,indent=2)+'\n');(D/'bundle.draft.json').write_text(json.dumps(dict(format='groundwork-knowledge/v3',workspace='volvo-cars',records=list(R.values())),indent=2)+'\n');print('mutable records',len(R))
