"""Complete pinned-file declarations and explicit unavailable referenced inputs."""
configFacts={
 '.gitignore':'Ignore declarations cover binaries/test/coverage outputs, optional vendor, go.work/go.work.sum and .env. Ignoring these files does not establish an active deployment or dependency content.',
 'README.md':'The README is only the cce-policy-admin title; it supplies no additional active runtime or API semantics.',
 'docker-compose.yaml':'Source compose declares local PostgreSQL17.2-alpine with5432mapping, TLS/certificate/initdb volume references, and Azurite ports10000/10001/10002. It does not declare or launch the Policy Admin app. Compose database intent does not supply the missing default Go pgxpool provider. Effective containers/certificates/data/ports are not observed.',
 'Makefile':'Make targets declare tests/lint/generator, local containers/migrations/SQL/certificates, SDK/client generation, sync curl examples, blob listing/container commands and dump/restore. No target was executed. Many referenced scripts/migration/API directories and .secrets.example are absent at this pin; command examples do not constitute application HTTP registrations or deployed broker/store identity. Go app uses volatile repositories; standalone Python migration is separate.',
 'go.sum':'Exact locked module checksum declarations retained by pinned file digest. These are module sums, not SHA256 actual deployed artifacts or downloaded implementation proof.',
 'internal/domain/configrule_test.go':'This file declares only package domain; no test assertion or executable production behaviour.',
 'internal/domain/policy_test.go':'Available test declares breadth-first child generations for parent1/2/5 and empty generation for leaf3/4, using equalGenerations ordering comparison. It is source assertion code read, not executed or a runtime/cycle-termination proof.',
 'internal/domain/old.go':'All legacy declarations/functions are commented out; available comments do not add active types/methods/calls.',
 'internal/command/carupdate.go':'Only package command is declared; no car-update handler is implemented.',
 'internal/messaging/handler.go':'Only package messaging is declared; no additional message handler/consumer registration.',
 'internal/database/inmemory/car_specs_110.json':'154 stored rows were structurally decoded as data. Each outer car_specification string has nested domain JSON structure. Source fixture data is neither a live service result nor the separate unused embedded carSpecRaw literal.'}
closure=[]
for item in json.loads((D/'repository-census.json').read_text())['files']:
 path=item['path'];e=anchor(path);fact=configFacts.get(path)
 if not fact:fact='Pinned available source '+path+' is fully inventoried and reviewed under its explicit executable/generated/schema/tool scope. Source tuple bytes/lines/SHA256 are in the file ledger; runtime activation is not inferred from declarations.'
 cid=claim('file-closure/'+hash(path),source,fact,[source],e);closure.append(dict(path=path,claim=cid,evidence=e,status='examined'))
# Parse exactly the two local textual proto files and verify matching stored descriptor declarations.
protoCorrespondence=[]
for path in ['internal/messaging/contracts/bto_car.proto','internal/messaging/contracts/car-configuration.proto']:
 raw=(SRC/path).read_text();package=re.search(r'package\s+([\w.]+)',raw).group(1);rows=[]
 for match in re.finditer(r'message\s+(\w+)\s*\{([^{}]*)\}',raw,re.S):
  full=package+'.'+match.group(1);assert full in PROTO;actual=PROTO[full]['message'];decl=[(m[1],m[0],int(m[2]),bool(m[3])) for m in []]
  textual=[]
  for f in re.finditer(r'(?:(repeated)\s+)?([\w.]+)\s+(\w+)\s*=\s*(\d+)\s*;',match.group(2)):
   typename=f.group(2);typename=package+'.'+typename if typename not in ['int32','string'] else 'TYPE_INT32' if typename=='int32' else 'TYPE_STRING';textual.append((f.group(3),typename,int(f.group(4)),bool(f.group(1))))
  stored=[(f.name,f.type_name.lstrip('.') or FieldDescriptorProto.Type.Name(f.type),f.number,f.label==FieldDescriptorProto.LABEL_REPEATED) for f in actual.field];assert textual==stored,(full,textual,stored);rows.append(dict(message=full,wireShape=wireShapes[full],fields=textual,storedPath=PROTO[full]['path']))
 cid=claim('local-proto/'+hash(path),source,'Co-located textual proto declaration and stored generated descriptor agree on exact message package/name/fieldname/number/type/repetition at this pin: '+str(rows)+'. Source go_package option names pop-pb-contracts/cce; this is declaration correspondence, not a deployed/generated artifact version or cross-repository execution binding.',[wireShapes[x['message']] for x in rows],anchor(path)+sum((PROTO[x['message']]['evidence'] for x in rows),[]));protoCorrespondence.append(dict(path=path,claim=cid,correspondence=rows))
missingInputs=['scripts/generate-postgres-certs.sh','scripts/check-hydrate.sh','scripts/check-instantiations-constructor.sh','scripts/wait-for-postgres.sh','scripts/fix-swag.sh','internal/database/postgres/migrations','.secrets.example','api/swagger.yaml','cmd/offer-service/main.go','internal/messaging/contracts/volvocars/contracts/carconfiguration/*.proto','docker-entrypoint-initdb.d','postgres_certs/server.crt','postgres_certs/server.key']
configGap=gap(source,'referenced-tool-inputs','unavailable_referenced_inputs','Pinned Makefile/compose reference inputs not present in this tree: '+str(missingInputs)+'. All tracked blobs are local; this is absent referenced input, not unexamined available source.','Inspect exact external/runtime tool inputs before claiming command execution, app launch or observed schema.',anchor('Makefile')+anchor('docker-compose.yaml'))
(D/'sourcefile-closure-ledger.json').write_text(json.dumps(closure,indent=2)+'\n');(D/'local-proto-correspondence-ledger.json').write_text(json.dumps(protoCorrespondence,indent=2)+'\n');(D/'unavailable-inputs-ledger.json').write_text(json.dumps(dict(gap=configGap,paths=missingInputs,trackedBlobsUnavailable=[]),indent=2)+'\n')
