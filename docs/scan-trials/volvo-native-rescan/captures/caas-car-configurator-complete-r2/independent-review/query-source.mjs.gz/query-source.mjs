import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
import {queryKnowledge} from '../../../../src/application/knowledge/query-knowledge.ts';
import {recordIndexes} from '../../../../src/domain/knowledge/knowledge-reader.ts';
import {knowledgeValidators} from '../../../../src/infrastructure/knowledge/knowledge-format.ts';
const input='reports/volvo-native-rescan/caas-car-configurator-complete/';
const output='reports/volvo-native-rescan/independent-review/caas/';
const bundle=JSON.parse(await readFile(input+'bundle.complete-02.json','utf8'));
const manifest=JSON.parse(await readFile(input+'snapshot.complete-02.json','utf8'));
const records=new Map(bundle.records.map(r=>[r.id,r])),indexes=new Map();
for(const record of bundle.records)for(const [field,values] of recordIndexes(record))for(const value of values){const key=field+'\0'+value,rows=indexes.get(key)??[];rows.push(record);indexes.set(key,rows);}
const reader={snapshot:manifest.id,rules:manifest.rules,get:id=>records.get(id),select:(field,value)=>indexes.get(field+'\0'+value)??[]};
const parse=await knowledgeValidators(),results=[],summary=[];
const base={format:'groundwork-query/v3',snapshot:manifest.id,query:'interactions',entry:'caas-car-configurator-5495209-complete-r2/entry/rpc/HealthCheck',value:null,context:[],outcome:null,changed:[],representation:'constructed',candidates:'exclude',maxNodes:2000,maxRecords:5000,environment:'pinned-source',ids:[],omit:[]};
function run(name,patch){let request={...base,...patch},first,pages=0;do{request=parse.request(request);const result=parse.response(queryKnowledge(reader,request));first??=result;results.push({name,page:pages,request,result});request=result.nextRequest;assert(++pages<100);}while(request);summary.push({name,nodes:first.nodes.length,edges:first.edges.length,limits:first.limitsHit,pages});return first;}
const entries=bundle.records.filter(r=>r.kind==='entry'&&r.trigger==='rpc');assert.equal(entries.length,9);
const interactions=bundle.records.filter(r=>r.kind==='interaction');assert.equal(interactions.length,17);
const pg='caas-car-configurator-5495209-complete-r2/runtime_component/postgres';
for(const entry of entries){
 const binding=bundle.records.find(r=>r.kind==='entry_binding'&&r.entry===entry.id);assert(binding);
 const contract=records.get(binding.contract);assert.equal(contract.protocol,'grpc');assert.equal(contract.method,'RPC');assert.equal(contract.path,entry.path);assert(entry.path.startsWith('/volvocars.contracts.carconfiguration.v2.CarConfigurationService/'));
 const name=entry.path.split('/').at(-1),result=run(name+' actual gRPC entry',{entry:entry.id});
 if(name==='HealthCheck'){assert.equal(result.edges.length,0);assert(!result.limitsHit.length);}
 else if(name==='CreateRuleset'){assert(result.limitsHit.includes('maxNodes'));}
 else {assert(result.edges.some(e=>records.get(e.record)?.target===pg),name+' must reach an actual Postgres boundary before any cutoff');}
 if(name==='DeleteRuleset'){assert(result.edges.some(e=>records.get(e.record)?.mode==='write'));assert(!result.limitsHit.length);}
}
run('All exact boundary records and duplicate record request IDs',{query:'records',ids:[interactions[0].id,...interactions.map(r=>r.id)],maxRecords:5000});
const writes=bundle.records.filter(r=>r.kind==='storage_write');assert.equal(writes.length,3);
for(const write of writes){
 assert.equal(write.acknowledgement,'success_result');assert.equal(write.atomicity,'unknown');assert(write.condition.includes('err==nil'));assert.notEqual(write.stagedAt,write.acknowledgedAt);
 run('Typed '+write.mode+' fields and acknowledgement',{query:'records',ids:[write.id]});
 for(const field of write.fields){assert(records.has(field.value));const result=run(write.mode+' field '+field.path.join('.'),{query:'value',entry:write.owner,value:field.value,representation:'source'});assert(result.nodes.some(n=>n.record===field.value));}
}
const stored=bundle.records.find(r=>r.kind==='shape'&&r.fields?.some(f=>f.name==='components2'));assert(stored);assert(!stored.fields.some(f=>f.name==='Components'));run('Persisted JSON names and nested declarations',{query:'records',ids:[stored.id]});
const solver=interactions.filter(r=>records.get(r.contract)?.protocol==='source-sdk'&&r.target?.endsWith('/solver'));assert.equal(solver.length,5);
for(const call of solver){assert.equal(call.boundary,'unresolved');assert(call.gaps.length);assert.equal(call.requestBindings.length,1);const op=records.get(call.operation);const result=run('Solver actual source argument '+call.id.split('/').at(-1),{query:'value',entry:op.owner,value:call.requestBindings[0].value,representation:'source'});assert(result.nodes.some(n=>n.record===call.requestBindings[0].value));}
const generic=interactions.find(r=>records.get(r.operation)?.label.includes('rt.next.RoundTrip'));assert.equal(generic.target,null);assert.equal(generic.boundary,'unresolved');
const commit=interactions.find(r=>records.get(r.operation)?.label==='Invoke tx.Commit(ctx)');assert(commit);run('Commit is separate from both helper write acknowledgements',{query:'records',ids:[commit.id,...writes.map(r=>r.id)]});
await writeFile(output+'root-r2-results.json.gz',gzipSync(JSON.stringify(results)));
await writeFile(output+'root-r2-acceptance.json',JSON.stringify({snapshot:manifest.id,status:'passed',qualification:'Independent bounded source-query review; CreateRuleset whole-entry traversal remains incomplete. No deployment, imported SDK transport or transaction durability proof.',queries:summary},null,2)+'\n');
console.log(JSON.stringify({snapshot:manifest.id,status:'passed',queries:summary.length,bounded:summary.filter(r=>r.limits.length).length}));
