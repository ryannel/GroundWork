# Finite source catalogue: imported activation, representation and durable effects are qualified.
entries=[];registrations=[];io=[];callerContracts=[];schemaLedger=[];subscriptions=[];construction=[]
def claim(key,owner,statement,inputs,evidence,basis='source_traced',assumptions=None):return add('claim',key,owner=owner,statement=statement,inputs=list(dict.fromkeys(x for x in inputs if x)),assumptions=assumptions or [],evidence=evidence,basis=basis)
def find(cls,name,arity=None):return next(m for m in methods.values() if m['ownerClass']['name']==cls and m['name']==name and (arity is None or len(m['parameters'])==arity))
def part(which,source,e,presence='present'):return dict(part=which,sourceShape=source,shape=None,presence=presence,contentType=None,gaps=[schemaGap],evidence=e)
def shape(key,label,fields,e,**kw):return add('shape','catalogue-shape/'+key,representation='source',label=label,fields=fields,completeness='partial',gaps=[schemaGap],evidence=e,**kw)
def contract(key,component,protocol,name,method,path,e,request=None,responses=None,authority='source_declared'):return add('interface_contract','contract/'+key,component=component,protocol=protocol,name=name,method=method,path=path,authority=authority,request=request or [],responses=responses or [],gaps=[schemaGap],evidence=e)
def expose(m,key,trigger,address,method=None,protocol=None):
 e=ev(m['ownerClass']['path'],m['declaration']['lines']);method=method or {'process':'PROCESS','startup':'STARTUP','callback':'CALLBACK','rest':'POST'}[trigger];protocol=protocol or {'process':'process','startup':'lifecycle','callback':'callback','rest':'http'}[trigger];eid=add('entry','entry/'+key,logicalId='cds-ecom-customer-crm-synchronizer:'+address,implementation=m['impl'],method=method,path=address,trigger=trigger,evidence=e);cid=contract('entry/'+key,host,protocol,address,method,address,e);add('entry_binding','entry-binding/'+key,entry=eid,execution=m['exec'],contract=cid,gaps=[schemaGap],evidence=e);row=dict(entry=eid,implementation=m['impl'],source=m['key'],trigger=trigger,address=address,contract=cid);entries.append(row);registrations.append(dict(row,policy='Source-declared registration; imported activation, dispatch, ordering and deployed settings unresolved'));return row
config=next(p for p in source_cache if p.endswith('/application.yml')) if any(p.endswith('/application.yml') for p in source_cache) else 'customer-crm-synchronizer-api/src/main/resources/application.yml'
configE=ev(config)
for fq,c in classes.items():
 sid=shapeids[fq];s=byid[sid]
 for field in s['fields']:
  if not field.get('shape') and re.fullmatch(r'(List|Set|Collection)<.+>',field['type']):
   item=generic_args(field['type'])[0];nested=shapeids.get(fqtype(item,c))
   if not nested:nested=shape('item/'+uid(fq+field['name']),item+' observed collection element',[],field['evidence'])
   field['shape']=shape('array/'+uid(fq+field['name']),field['type']+' source collection',[],field['evidence'],container='array',items=nested)
 claim('type/'+uid(fq),sid,'Exact source '+c['lex']['kind']+' '+fq+' declaration/annotations: '+str([(f['name'],f['type'],f['declaration']['text']) for f in c['fields']])+'. Extends '+str(c.get('extends'))+' implements '+str(c.get('implements'))+'. Record components are source data, enum constants are declarations rather than object fields. Imported JSON/validation formats are unresolved.',[sid],ev(c['path']),'source_declared')
# Actual source DTO setter intent, not asserted imported SDK/wire representation.
setterGroups=collections.defaultdict(list)
for row in audit:
 if '/cdb/mapper/' in row['path'] and re.fullmatch(r'set[A-Z].*',row['name']) and len(row['argumentValues'])==1:
  receiver=byid[row['operation']].get('receiver')
  if receiver:setterGroups[(row['owner'],receiver,row['receiverType'])].append(row)
for (owner,receiver,typ),rows in setterGroups.items():
 fields=[];e=[]
 for row in rows:
  name=row['name'][3:4].lower()+row['name'][4:];v=row['argumentValues'][0];revid=byid[row['operation']]['evidence'];e+=revid;f=dict(name=name,type=row['argumentTypes'][0],status='declared',evidence=revid)
  if byid[v].get('shape'):f['shape']=byid[v]['shape']
  fields.append(f)
 sid=shape('setter/'+uid(owner+receiver),typ+' exact source setter-intent projection (imported DTO semantics unresolved)',fields,list(dict.fromkeys(e)),container='object');byid[receiver]['shape']=sid
 for index,row in enumerate(rows):
  v=row['argumentValues'][0];op=row['operation'];name=fields[index]['name'];fv=add('value','setter-field/'+uid(op),owner=byid[op]['owner'],definition=op,label='Caller setter intent '+typ+'.'+name,role='definition',representation='constructed',shape=byid[v].get('shape'),accessPath=[name],evidence=byid[op]['evidence']);add('flow','setter-operand/'+uid(op),owner=byid[op]['owner'],**{'from':v,'to':fv},at=op,transform='Exact actual argument supplied to imported '+row['name']+'; source field intent only',gaps=[schemaGap],assumptions=['Imported setter implementation unavailable'],evidence=byid[op]['evidence']);add('flow','setter-object/'+uid(op),owner=byid[op]['owner'],**{'from':fv,'to':receiver},at=op,transform='Source setter invocation on this exact object variable; field construction association, not heap SSA or verified SDK mutation',gaps=[schemaGap],assumptions=['Caller setter intent; imported implementation unavailable'],evidence=byid[op]['evidence']);construction.append(dict(owner=owner,receiver=receiver,operation=op,field=name,actual=v,fieldValue=fv,shape=sid))
 claim('setter-intent/'+uid(owner+receiver),byid[receiver]['owner'],'Exact source new-object/setter construction for '+typ+'. The source passes these actuals to setters on this same object then uses/returns it. Native field operand lineage represents caller construction intent only; unavailable imported setter/body, serialization and every mutable state version are not asserted.',[receiver,sid]+[r['operation'] for r in rows],list(dict.fromkeys(e)))
# Partial imported DTO vocabulary closes known nested caller schemas across conditional variants.
importedVocabulary={}
for (_,_,typ),rows in setterGroups.items():
 importedVocabulary.setdefault(typ,{})
 for row in rows:
  name=row['name'][3:4].lower()+row['name'][4:];e=byid[row['operation']]['evidence'];field=importedVocabulary[typ].setdefault(name,dict(name=name,type=row['argumentTypes'][0],status='declared',optional=True,evidence=[]));field['evidence']=list(dict.fromkeys(field['evidence']+e))
importedIds={typ:P+'catalogue-shape/imported-vocabulary/'+typ for typ in importedVocabulary}
for typ,fields in importedVocabulary.items():
 e=list(dict.fromkeys(x for f in fields.values() for x in f['evidence']))
 for field in fields.values():
  ft=field['type'];base=clean(ft).split('.')[-1];nested=importedIds.get(base) or sidfor(base) if 'sidfor' in globals() else importedIds.get(base) or next((v for k,v in shapeids.items() if k.split('.')[-1]==base),None)
  if generic_args(ft):
   element=generic_args(ft)[0];item=importedIds.get(clean(element).split('.')[-1]) or next((v for k,v in shapeids.items() if k.split('.')[-1]==clean(element).split('.')[-1]),None)
   if item:nested=shape('imported-array/'+typ+'/'+field['name'],ft+' source caller collection',[],field['evidence'],container='array',items=item)
  if nested:field['shape']=nested
 shape('imported-vocabulary/'+typ,typ+' partial caller setter vocabulary across source branches; not allocated/wire object',list(fields.values()),e,container='object')
for row in audit:
 value=row.get('resultValue');base=clean(row['returnType']).split('.')[-1]
 if value and not byid[value].get('shape') and base in importedIds:byid[value]['shape']=importedIds[base]
for typ in importedVocabulary:
 claim('imported-model-vocabulary/'+typ,importedIds[typ],'Partial imported model '+typ+' field vocabulary consists solely of explicit available caller setters across source branches. Optional fields do not mean all branches set every field; exact branch/actual construction remains in the separate per-object projection. Unknown imported members, field assignment/wire encoding and constraints remain unresolved.',[importedIds[typ]],byid[importedIds[typ]]['evidence'],'source_declared')
# Propagate known source construction schema through exact copies, local returns/formals.
for _ in range(8):
 changed=False
 for r in list(records):
  if r['kind']=='flow' and not byid[r['to']].get('shape') and byid[r['from']].get('shape') and any(t in r['transform'] for t in ['Initialise source local','Source assignment','Source return','Source value']):
   byid[r['to']]['shape']=byid[r['from']]['shape'];changed=True
  if r['kind']=='operation' and r.get('resolution'):
   target=byid.get(byid[r['resolution']].get('target'),{})
   for b in r.get('bindings',[]):
    if byid[b['value']].get('shape') and not byid[b['parameter']].get('shape'):byid[b['parameter']]['shape']=byid[b['value']]['shape'];changed=True
   if r.get('result') and not byid[r['result']].get('shape'):
    returned=[byid[x['result']].get('shape') for x in records if x['kind']=='operation' and x['owner']==target.get('id') and x['action']=='return' and x.get('result')]
    known=set(x for x in returned if x)
    if len(known)==1:byid[r['result']]['shape']=next(iter(known));changed=True
 if not changed:break
for row in construction:
 field=next(f for f in byid[row['shape']]['fields'] if f['name']==row['field'])
 if byid[row['actual']].get('shape'):field['shape']=byid[row['actual']]['shape']
# Whole imported envelopes, partial observed metadata, and local payloads remain separate.
def sidfor(short):return next((v for k,v in shapeids.items() if k.split('.')[-1]==short),None)
metadataE=ev(find('CustomerEventConsumer','consume')['ownerClass']['path'])+ev(find('CustomerEventConsumer','getRemoteSystem')['ownerClass']['path'])
metadata=shape('metadata','Imported Event.Metadata observed projections only',[dict(name=n,type=t,status='declared',evidence=metadataE) for n,t in [('correlationId','String'),('type','String'),('attributes','Map<String,String>')]],metadataE,container='object')
envelopes={}
for payload in ['CustomerEventPayload','CdbSyncEventPayload']:
 payloadE=ev(next(c['path'] for c in classes.values() if c['name']==payload))+ev(find('CdbSyncEventDeserializer' if payload=='CdbSyncEventPayload' else 'CustomerEventDeserializer','deserialize')['ownerClass']['path'])
 envelopes[payload]=shape('event/'+payload,'Imported Event<'+payload+'> observed whole envelope',[dict(name='metadata',type='Event.Metadata',shape=metadata,status='declared',evidence=metadataE),dict(name='payload',type=payload,shape=sidfor(payload),status='declared',evidence=payloadE)],payloadE+metadataE,container='object')
customerE=ev(find('CustomerClient','getCustomer')['ownerClass']['path'])
customerEnvelope=shape('customer-envelope','Imported SuccessResponse<Customer> whole observed wrapper',[dict(name='data',type='Customer',shape=sidfor('Customer'),status='declared',evidence=customerE)],customerE,container='object')
# Named source codec and projection intentions; arbitrary imported call results are not argument-derived.
for row in audit:
 op=byid[row['operation']];out=row.get('resultValue');receiver=op.get('receiver');e=op['evidence'];name=row['name'];rt=clean(row['receiverType']).split('.')[-1]
 if not out:continue
 source=None;member=None;targetShape=None;reason=None
 if name=='readValue' and row['owner'].endswith('Deserializer#deserialize(String)'):
  source=row['argumentValues'][0];payload='CdbSyncEventPayload' if 'CdbSyncEventDeserializer' in row['owner'] else 'CustomerEventPayload';targetShape=envelopes[payload];reason='Exact source JsonMapper.readValue(eventJson, TypeReference<Event<'+payload+'>>); codec construction association, effective parser/format remains imported'
 if name in ['getMetadata','getPayload'] and rt=='Event':
  source=receiver;member='metadata' if name=='getMetadata' else 'payload';targetShape=metadata if member=='metadata' else sidfor('CdbSyncEventPayload' if 'CdbSync' in row['owner'] else 'CustomerEventPayload');reason='Exact source Event '+member+' accessor use, not a claim of exhaustive imported envelope'
 if name=='getAttributes' and rt=='Metadata':source=receiver;member='attributes';reason='Source Metadata.getAttributes() selects the observed map; effective imported implementation unresolved'
 if rt=='Actor' and name in ['id','emails','phoneNumbers','addresses','roles','cdbId','cdbTcId']:
  source=receiver;member=name;reason='Exact local Actor abstract accessor signature; available source Individual/CorporateEntity record component projection intent, generated dispatch remains unresolved'
 if name=='getOrDefault' and 'getRemoteSystem' in row['owner']:
  source=receiver;member='REMOTE_SYSTEM_ID';reason='Exact source attributes.getOrDefault(Constants.REMOTE_SYSTEM_ID,null) selection, with null fallback; imported Map execution returns normally'
 if name=='getBody' and any(x in row['owner'] for x in ['CdbClient#','CustomerClient#']):
  source=receiver;member='body';targetShape=customerEnvelope if 'CustomerClient' in row['owner'] else sidfor('CdbResponse' if 'createOrUpdateConsumer' in row['owner'] else 'CdbConsumerByVolvoIdResponse');reason='Exact source ResponseEntity.getBody use projects whole declared body envelope before data/responseDetails'
 if source and reason:
  if targetShape:byid[out]['shape']=targetShape
  if member:byid[out].update(role='field',accessPath=[member])
  add('flow','source-named-projection/'+uid(row['operation']),owner=op['owner'],**{'from':source,'to':out},at=op['id'],transform=reason,gaps=[schemaGap],assumptions=['Source caller codec/accessor intent; exact dependency/generated implementation unavailable'],evidence=e)
actor=next(c for c in classes.values() if c['fqn'].endswith('.actor.Actor'));actorShape=byid[shapeids[actor['fqn']]]
actorShape['fields']=[dict(name=m['name'],type=m['returnType'],status='declared',evidence=ev(actor['path'],m['declaration']['lines'])) for m in actor['methods'] if not m['parameters']]
claim('actor-implementations',shapeids[actor['fqn']],'Local Actor signatures and source record Individual/CorporateEntity implementing Actor establish source accessor/component correspondence. Runtime actor subtype dispatch and generated bodies remain conditional; no invented interface body.',[shapeids[actor['fqn']],sidfor('Individual'),sidfor('CorporateEntity')],ev(actor['path'])+ev(next(c['path'] for c in classes.values() if c['name']=='Individual'))+ev(next(c['path'] for c in classes.values() if c['name']=='CorporateEntity')),'source_declared')
# Source OpenAPI is independent contract authority, not evidence of generated/runtime body.
openapiPath='docs/openapi.json';openapi=json.loads(raw(openapiPath));openids={name:P+'catalogue-shape/openapi/'+name for name in openapi.get('components',{}).get('schemas',{})}
for name,s in openapi.get('components',{}).get('schemas',{}).items():
 fields=[]
 for n,f in s.get('properties',{}).items():
  item=dict(name=n,type=f.get('type',f.get('$ref','unresolved')),status='declared',optional=n not in s.get('required',[]),evidence=ev(openapiPath));ref=f.get('$ref','').split('/')[-1]
  if ref in openids:item['shape']=openids[ref]
  if f.get('type')=='array':
   itemRef=f.get('items',{}).get('$ref','').split('/')[-1];inner=openids.get(itemRef)
   if not inner:inner=shape('openapi-item/'+name+'/'+n,'OpenAPI '+name+'.'+n+' item '+json.dumps(f.get('items',{})),[],ev(openapiPath))
   item['shape']=shape('openapi-array/'+name+'/'+n,'OpenAPI '+name+'.'+n+' array',[],ev(openapiPath),container='array',items=inner)
  for constraint in ['nullable','maxLength','pattern','const']:
   if constraint in f:item[constraint]=f[constraint]
  if 'enum' in f:item['enum']=f['enum']
  fields.append(item)
 shape('openapi/'+name,'Pinned OpenAPI '+name+' declared contract',fields,ev(openapiPath),**({'container':'object'} if s.get('type')=='object' or fields else {}));schemaLedger.append(dict(authority='pinned_openapi',name=name,shape=openids[name]));claim('openapi/'+name,openids[name],'Exact pinned OpenAPI schema '+json.dumps(s)+'. Imported effective encoder/validator/source wrapper correspondence is not established.',[openids[name]],ev(openapiPath),'source_declared')
expose(find('App','main'),'main','process','source:App.main')
restSpecs=[('syncToCdb','PUT','/v1/{customerId}/cdb-sync'),('syncVehicleRelationToCdb','PUT','/v1/{customerId}/cdb-vehicle-sync'),('getConsumerByVolvoId','GET','/v1/consumer/volvoid/{volvoId}')]
for name,verb,path in restSpecs:
 m=find('CustomerCrmSyncControllerV1',name);r=expose(m,'rest/'+name,'rest',path,verb);e=byid[r['contract']]['evidence'];signature=shape('rest/'+name,path+' exact Java formals / annotations',[dict(name=p['name'],type=p['type'],status='declared',evidence=e,**({'shape':shapeids[fqtype(p['type'],m['ownerClass'])]} if fqtype(p['type'],m['ownerClass']) in shapeids else {})) for p in m['parameters']],e,container='object');c=byid[r['contract']];c['request']=[part('record',signature,e)];c['responses']=[dict(status='normal source return; annotation and imported HTTP handling separate',body=part('body',openids['BaseResponseCdbConsumerData'] if verb=='GET' else openids['BaseResponseString'],e),meaning='Whole SuccessResponse.ok(data, correlationId) wrapper; PUT null data is not null HTTP response body.',evidence=e)];claim('rest-policy/'+name,m['impl'],'Exact class @RequestMapping /v1/ and method mapping, VCC-Remote-System required header, formal annotations and @PreAuthorize role expression are source declarations. Header remoteSystem is not forwarded by Java body. Imported method-security activation/enforcement, EcomWebAppConfiguration virtual-path '+raw(config).split('virtual-path:')[-1].splitlines()[0]+' and gateway prefixes remain unresolved; no fabricated Java security call/order. Deprecated GET remains source-exposed. '+m['declaration']['text'],[r['entry'],m['impl']]+m['params'],e,'source_declared')
for m in list(methods.values()):
 text=m['declaration']['text'];head=text[:text.find('{')] if m['body'] else text
 if '@Bean' in head:expose(m,'bean/'+uid(m['key']),'startup','source:@Bean:'+m['key'])
 if '@PreDestroy' in head:expose(m,'destroy/'+uid(m['key']),'callback','source:@PreDestroy:'+m['key'])
 if '@ExceptionHandler' in head:expose(m,'advice/'+uid(m['key']),'callback','source:@ExceptionHandler:'+m['key'])
 if '@JsonCreator' in head:expose(m,'jsoncreator/'+uid(m['key']),'callback','source:@JsonCreator:'+m['key'])
for cls,name in [('HealthMetricsExportConfiguration','getStatusCode'),('KafkaHealthMetricsExportConfiguration','getKafkaStatusCode'),('CustomerEventRecoverer','accept')]:
 m=find(cls,name);expose(m,'callback/'+uid(m['key']),'callback','source:registered-callback:'+m['key'])
components={}
for key,label,technology in [('customer-service','Configured Customer Service','HTTP / JSON'),('cdb','Configured CDB Consumer API','HTTP / JSON'),('order-manager','Configured Order Manager','HTTP / JSON'),('kafka','Configured Kafka cluster','Kafka')]:
 components[key]=add('runtime_component','component/'+key,logicalId='cds-ecom-customer-crm-synchronizer:'+key,label=label,category='topic' if key=='kafka' else 'external',technology=technology,sources=[scope],basis='source_declared',gaps=[schemaGap],evidence=configE);claim('destination/'+key,components[key],'Source configured '+key+' intended destination. '+('spring.kafka bootstrap-servers/security and profile alternatives' if key=='kafka' else 'RestClientRegistry qualifier '+key+' and rest-client-config.clients.'+key+'.base-url/oauth registration')+'. Effective environment, host/credentials/imported OAuth connection policy and deployed identity remain unresolved.',[scope],configE,'source_declared')
# Exactly five terminal source HTTP invocations, not fluent builder or mapper calls.
specs={('CustomerClient','getCustomer'):('customer-service','GET','/v1/customers/{customerId}',None,customerEnvelope,0),('CustomerClient','patchCustomer'):('customer-service','PATCH','/v1/customers/{customerId}',1,None,0),('CdbClient','createOrUpdateConsumer'):('cdb','POST','/consumer',0,sidfor('CdbResponse'),None),('CdbClient','getCdbConsumerByVolvoId'):('cdb','GET','/consumer/alternativeIds/{alternativeId}?type={idType}',None,sidfor('CdbConsumerByVolvoIdResponse'),0),('OrderManagerClient','sendCustomerUpdateEventInOm'):('order-manager','POST','/internal/ordermanager/v1/orders/customer-update-event/{customerId}',0,None,1)}
for row in audit:
 if row['name'] not in ['toEntity','toBodilessEntity']:continue
 m=methods[row['owner']];spec=specs.get((m['ownerClass']['name'],m['name']))
 if not spec:continue
 key,verb,path,bodyIndex,responseShape,pathIndex=spec;e=byid[row['operation']]['evidence'];bindings=[];request=[]
 if pathIndex is not None:
  pv=m['params'][pathIndex];pn='alternativeId' if key=='cdb' else 'customerId';ss=shape('path/'+uid(row['operation']),path+' exact source path actual',[dict(name=pn,type='String',status='declared',evidence=e)],e,container='object');request.append(part('path',ss,e));bindings.append(dict(part='path',path=[pn],value=pv,transform='Exact source uri-template positional argument'))
 if bodyIndex is not None:
  v=m['params'][bodyIndex];request.append(part('body',byid[v].get('shape'),e));bindings.append(dict(part='body',path=[],value=v,transform='Exact source .body(actual) whole object; caller DTO construction separate from imported wire codec'))
 if key=='cdb' and verb=='GET':
  query=shape('cdb-idtype','Exact source CDB query',[dict(name='type',type='String',const='ALT_ID_MY_VOLVO_ID',status='declared',evidence=e)],e,container='object');request.append(part('query',query,e));actual=next(r for r in audit if r['owner']==row['owner'] and r['name']=='uri')['argumentValues'][-1];bindings.append(dict(part='query',path=['type'],value=actual,transform='Exact VOLVO_ID_TYPE source constant'))
 responses=[dict(status='normal retrieve result; status failures remain source catches/imported policy',body=part('body',responseShape,e,'present' if responseShape else 'none'),meaning='Whole declared decode envelope before getBody/responseDetails/data projection; bodiless response for mutation acknowledgement only.',evidence=e)]
 cid=contract('http/'+uid(row['operation']),components[key],'http',m['key'],verb,path,e,request,responses,'caller_construction');iid=add('interaction','http-io/'+uid(row['operation']),owner=m['impl'],execution=m['exec'],operation=row['operation'],target=components[key],targetEntry=None,contract=cid,effect=None,handoff=None,mode='request_response',boundary='network',waitsFor='response',condition='Only if source guards and imported fluent retrieval reach this terminal invocation; registry/OAuth/HTTP codec/status dispatch/retry execution unresolved. No local durable transaction or remote service implementation is inferred.',requestBindings=bindings,responseBindings=[dict(part='result',path=[],value=row['resultValue'],transform='Immediate ResponseEntity result, not projected inner DTO')] if row.get('resultValue') else [],gaps=[schemaGap],evidence=e);item=dict(row,interaction=iid,contract=cid,componentKey=key,targetComponent=components[key]);io.append(item);callerContracts.append(dict(source=m['key'],interaction=iid,contract=cid,method=verb,path=path,actualValues=[b['value'] for b in bindings]))
# Three actual source subscriptions: same customer topic, distinct groups/policies.
for cls,topic,group,payload,condition in [('CustomerEventConsumer','app5541-customer-events','${spring.kafka.consumer.group-id}','CustomerEventPayload','spring.kafka.consumer.enabled=true; concurrency=3'),('CustomerEventOMConsumer','app5541-customer-events','${spring.kafka.consumer.om-update.group-id}','CustomerEventPayload','spring.kafka.consumer.om-update.enabled=true'),('CdbSyncEventConsumer','${spring.kafka.consumer.cdb-sync.topic-name}','${spring.kafka.consumer.cdb-sync.group-id}','CdbSyncEventPayload','spring.kafka.consumer.cdb-sync.enabled=true; concurrency=3')]:
 m=find(cls,'consumeToUpdateOM' if cls=='CustomerEventOMConsumer' else 'consume');e=ev(m['ownerClass']['path'],m['declaration']['lines']);root=expose(m,'listener/'+cls,'callback','source:@KafkaListener:'+cls);rid=add('resource','topic/'+cls,label=topic,technology='Kafka topic',declaredDatabase=None,physicalLocation=None,shapes=[envelopes[payload]],gaps=[schemaGap],evidence=e+configE);add('resource_binding','topic-binding/'+cls,resource=rid,component=components['kafka'],role='transport',gaps=[schemaGap],evidence=e+configE);binding=add('channel_binding','channel/'+cls,resource=rid,source=scope,namespace=None,channel=topic if not topic.startswith('${') else None,environment='source-profiles',profile=condition,basis='committed_configuration',conditions=[condition],gaps=[schemaGap],evidence=e+configE);policy=add('delivery_policy','delivery/'+cls,owner=m['impl'],operation=byid[m['impl']]['entry'],awaited=True,brokerPersistenceRequired=None,offsetCommit='unresolved',retryLimit=None,deduplication='unknown',deduplicationKeys=[],ordering='not_established',deliveryGuarantee='not_established',gaps=[schemaGap],evidence=e+configE);sub=add('subscription','subscription/'+cls,owner=m['impl'],binding=binding,header=None,messageType=None,headerFilter='none',payload=m['params'][0],group=group,policy=policy,gaps=[schemaGap],evidence=e+configE);cid=contract('consume/'+cls,components['kafka'],'kafka',cls,None,topic,e,[part('message',envelopes[payload],e)]);iid=add('interaction','consume-io/'+cls,owner=m['impl'],execution=m['exec'],operation=byid[m['impl']]['entry'],target=components['kafka'],targetEntry=None,contract=cid,effect=None,handoff=None,mode='consume',boundary='network',waitsFor='unknown',condition=condition+'; imported Kafka framework callback/offset/retry/ack policies unresolved.',requestBindings=[dict(part='message',path=[],value=m['params'][0],transform='Actual String eventJson formal before explicit Event<T> deserialization; observed schema is not the allocated parameter type')],responseBindings=[],gaps=[schemaGap],evidence=e);subscriptions.append(dict(source=cls,subscription=sub,entry=root['entry'],implementation=m['impl'],interaction=iid,topic=topic,group=group,payloadShape=envelopes[payload]));io.append(dict(owner=m['key'],operation=byid[m['impl']]['entry'],interaction=iid,contract=cid,componentKey='kafka',targetComponent=components['kafka'],name='consume',argumentValues=m['params']))
# Actual Admin health request, separately rooted by metric callback; no invented consumer producer/DLQ.
m=find('KafkaHealthIndicator','health');row=next(r for r in audit if r['owner']==m['key'] and r['name']=='describeCluster');e=byid[row['operation']]['evidence'];cid=contract('kafka-health',components['kafka'],'kafka-admin','describeCluster',None,None,e,[part('record',None,e)]);iid=add('interaction','kafka-health-io',owner=m['impl'],execution=m['exec'],operation=row['operation'],target=components['kafka'],targetEntry=None,contract=cid,effect=None,handoff=None,mode='request_response',boundary='network',waitsFor='response',condition='Health invoked via KafkaHealthMetrics callback only when indicator bean enabled; describeCluster(options timeoutMs3000).clusterId().get awaited, exceptions become Health.down. Imported scheduling/activation is unresolved.',requestBindings=[dict(part='record',path=['options'],value=row['argumentValues'][0],transform='Exact source DescribeClusterOptions timeout3000 field')],responseBindings=[dict(part='result',path=[],value=row['resultValue'],transform='Immediate DescribeClusterResult, clusterId future/get is separate')],gaps=[schemaGap],evidence=e);io.append(dict(row,interaction=iid,contract=cid,componentKey='kafka',targetComponent=components['kafka']))
# Finite, source-reviewed behavioural policies complement control/value graphs.
policies=[('sync','CustomerSyncService','syncToCdb',3,'Fetch customer, individual CDB synchronisations then signatory selection then corporate CDB synchronisations; construct result then patch customer IDs and conditional OM event. Earlier CDB changes are not rolled back if a later actor, PATCH or OM call fails. No local database, shared transaction or compensation exists in available source.'),('individual','IndividualSyncService','syncToCdb',4,'create=false and missing cdbId skips; US individual exactly PAYER role skips; unnamed APPROVER only skips. Skipped actor retains old IDs/isUpdated=false. Source isUnchanged(null,old)=true, but changed branch returns both newly extracted values and can return one null when the other changed. Stream terminal toList executes source actor mapping conditionally.'),('corporate','CorporateEntitySyncService','syncToCdb',5,'Skip create=false/missingCdbId, no roles, no SOLD_TO, or fleetAccountId present. Related signatory CDB identifier selection is source-specific. Same nullable new-ID changed behaviour as individual.'),('customer','CustomerService','updateCustomerCdbIds',2,'Only isUpdated actors map into PatchCustomerRequest. If either patch list nonempty, customer PATCH precedes OM CRM_UPDATE; no transaction/compensation. Empty patch lists perform neither call.'),('om','OrderManagerClient','sendCustomerUpdateEventInOm',2,'ResourceAccessException rethrown; HTTP404/409 are logged and swallowed, all other RestClientException wrapped. Source comment about remote duplication is not proof of remote state. source void method has no returned domain result.'),('om-enabled','OrderManagerService','sendCustomerUpdateEventInOm',2,'order-manager.enabled defaults true; false logs and suppresses actual remote call. Actual categories CRM_UPDATE after PATCH and CUSTOMER_UPDATE for independent Kafka consumer.'),('recoverer','CustomerEventRecoverer','accept',2,'Null key random UUID, String identity otherwise toString; payload null/String/other similarly. Throwable cause chain search suppresses CdbDataRejectedException; other exhausted failures print/log. No source dead-letter publication. Imported DefaultErrorHandler controls invocation and offsets.'),('cdb-post','CdbClient','createOrUpdateConsumer',1,'POST decodes whole CdbResponse then requires nonnull wrapper and responseDetails; ResourceAccessException rethrows; BadRequest description containing case-sensitive LOCKED or MODIFIED creates CdbConsumerLockedException, otherwise CdbDataRejectedException. Other RestClientException wrapped.'),('cdb-error','CdbClient','getErrorDescription',1,'Blank body -> no response body; JSON nounFailure errorMessage descriptions joined with semicolon-space, root errorMessage fallback then original body; JacksonException returns original body.'),('customer-consumer','CustomerEventConsumer','consume',1,'Deserialize and metadata correlationId dereference precede try. Self-origin azureAppId match and CUSTOMER_ARCHIVED each skip; only CustomerNotFoundException caught around syncToCdb(id,false). Other errors propagate.'),('om-consumer','CustomerEventOMConsumer','consumeToUpdateOM',1,'Distinct group on same customer topic; correlationId dereference occurs before nullable metadata archive guard. No self-origin filter, no CustomerNotFound catch. Nonarchived calls OM CUSTOMER_UPDATE.'),('order-consumer','CdbSyncEventConsumer','consume',1,'CDB-sync topic/order-create factory: payload order/customer logging occurs before try; syncToCdb(customerId,true), catches only CustomerNotFoundException.'),('kafka-config','CustomerEventConfig','createErrorHandler',0,'DefaultErrorHandler(recoverer, FixedBackOff from configured interval/maxAttempts) declares CdbDataRejectedException nonretryable. Kafka backoff maxAttempts5 is distinct from HTTP @Retryable maxRetriesString property3. Effective imported delivery/commit/exhaustion remains gap.'),('consumer-get','CdbConsumerService','getConsumerByVolvoId',1,'CDB GET may return null responseDetails; service dereferences responseDetails/consumerInfo without equivalent guard, preserve source null failure risk rather than inventing successful empty DTO.'),('addresses','CreateOrUpdateAddressMapper','toList',1,'Filter previous addresses then deduplicate using ComparableAddress normalization of eight components: trim, collapse spaces, lowercase Locale.ENGLISH; line5/county are not forwarded. Source active=true, HOME for individual/BUSINESS for corporate.'),('alternative-id','CreateOrUpdateAlternativeConsumerIdMapper','fromActor',1,'TC_ID existing nonblank cdbTcId else ECOM_CUSTOMER_ID actor.id. Individual MyVolvoId only for initial sync without cdbId and with volvoId. Source caller intent, imported field/wire policy unresolved.')]
for key,cls,name,arity,text in policies:
 try:m=find(cls,name,arity)
 except StopIteration:
  matches=[m for m in methods.values() if m['ownerClass']['name']==cls and m['name']==name];assert len(matches)==1,(key,[(x['key']) for x in matches]);m=matches[0]
 claim('policy/'+key,m['impl'],text,[m['impl']]+[r['operation'] for r in audit if r['owner']==m['key']],ev(m['ownerClass']['path'],m['declaration']['lines']))
for g in graphs:
 m=g.m;claim('body/'+uid(m['key']),m['impl'],'Full original source body: '+(m['body']['text'] if m['body'] else 'declaration only')+'. Exact ownership/formals/receiver/captures and retained branch/call/result facts are source representation. Guard feasibility, heap versions, imported signatures/activation/codec remain analysis/runtime frontiers.',[m['impl']],ev(m['ownerClass']['path'],m['declaration']['lines']))
for m in methods.values():
 text=m['declaration']['text']
 if '@Retryable' in text:claim('retry/'+uid(m['key']),m['impl'],'Exact source resilient-method annotation and declaration: '+text+'. RetryConfig EnableResilientMethods declares activation; unavailable imported proxy, maxRetries interpretation, exception matching, backoff, timing and actual attempts remain unresolved. No eager synthetic loop.',[m['impl']],ev(m['ownerClass']['path'],m['declaration']['lines']),'source_declared')
 if '@Bean' in text or 'Gauge.builder' in text or 'JsonMapper' in text:claim('registration/'+uid(m['key']),m['impl'],'Exact source registration/codec body '+text+'. Local referenced bodies are retained independently; imported scheduling/callback/serialization/bean dispatch remains unresolved rather than eager invocation.',[m['impl']],ev(m['ownerClass']['path'],m['declaration']['lines']),'source_declared')
# Source field initialisers and imported management mounts retain their actual declaration scope.
for fq,c in classes.items():
 for f in c['fields']:
  if len(f['declaration'].get('children',[]))>2:claim('initializer/'+uid(fq+f['name']),shapeids[fq],'Exact available source field declaration/initializer '+f['declaration']['text']+'. Static/instance initialization timing and imported helper allocation are declarations, not invented boot-to-all-controller execution.',[shapeids[fq]],ev(c['path'],f['declaration']['lines']),'source_declared')
for address in ['/actuator/health','/actuator/prometheus','/swagger-ui.html','/v3/api-docs','/v3/api-docs/swagger-config']:
 key='imported-mount/'+uid(address);mid=add('implementation',key,logicalId='source:configured-imported-mount:'+address,scope=scope,entry=P+'operation/'+key,parameters=[],returnKind='unresolved',evidence=configE);operation=add('operation','operation/'+key,owner=mid,action='opaque',label='Configured imported mount '+address+'; no available local handler body',resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=configE);ex=add('execution_binding','execution/'+key,implementation=mid,component=host,basis='source_declared',artifactBinding=None,gaps=[schemaGap],evidence=configE);fake=dict(key='imported:'+address,impl=mid,exec=ex,ownerClass=dict(path=config),declaration=dict(lines=[1,len(raw(config).splitlines())]));expose(fake,key,'rest',address,'GET');claim('mount/'+uid(address),mid,'Source management exposure health/prometheus, Springdoc Swagger/docs settings and imported EcomWeb configuration declare this mount. Effective framework default paths, management port8779 versus application8080, source virtual-path/profile prefixing and exact runtime activation are unresolved. No local body or direct boot-to-metrics callback is invented.',[mid],configE,'source_declared')
# Imported setter calls used as source statements have no consumed return value; do not manufacture fluent data.
unusedSetterResults=set()
for row in audit:
 if '/cdb/mapper/' in row['path'] and row['name'].startswith('set') and row.get('resultValue'):
  unusedSetterResults.add(row['resultValue']);byid[row['operation']]['result']=None;row['resultValue']=None;row['returnType']='unresolved; result unused in source statement'
removed={r['id'] for r in records if r['kind']=='value' and r['id'] in unusedSetterResults or r['kind']=='flow' and (r['from'] in unusedSetterResults or r['to'] in unusedSetterResults)}
records=[r for r in records if r['id'] not in removed];byid={r['id']:r for r in records}
for r in records:
 if r['kind']=='claim':r['inputs']=[v for v in r['inputs'] if v not in removed]
 if r['kind']=='transition':r['values']=[v for v in r['values'] if v not in removed]
sourceReview=[];testLedger=[];fileRows=json.loads((OUT/'source-files.json').read_text())['files']
for f in fileRows:
 path=f['path'];bodyRows=[r for r in ledger if r['path']==path];e=ev(path) if f.get('text') and f.get('lines') else [];role=f['role'];note='Full pinned '+role+' source classified; no build/application/live calls. Production Java bodies and actual registrations reviewed; tests are non-executed assertions; docs/config/CI are declarations, not runtime proof.'
 if e:claim('file/'+uid(path),scope,note+(' Exact configuration/support: '+raw(path) if role=='configuration_support' and len(raw(path))<40000 else ''),[scope]+[r['implementation'] for r in bodyRows],e,'source_declared')
 sourceReview.append(dict(**f,nativeBodies=len(bodyRows),status='source_examined' if f.get('text') else 'binary_support_excluded_from_text_execution',notes=note))
for file in AST['files']:
 if '/src/test/' not in file['path']:continue
 for c in file['classes']:
  for m in c['methods']:
   if not m['body']:continue
   e=ev(file['path'],m['declaration']['lines']);byid[e[0]]['basis']='test_assertion';cid=claim('test/'+uid(file['path']+str(m['declaration']['start'])),scope,'Non-executed source test '+c['name']+'.'+m['name']+': '+m['body']['text'],[scope],e,'source_declared');testLedger.append(dict(path=file['path'],method=c['name']+'.'+m['name'],lines=m['declaration']['lines'],claim=cid,basis='test_assertion',executed=False))
import xml.etree.ElementTree as ET
dependencies=[];ns={'m':'http://maven.apache.org/POM/4.0.0'}
for f in fileRows:
 if not f['path'].endswith('pom.xml'):continue
 pom=ET.fromstring(raw(f['path']));props={x.tag.split('}')[-1]:x.text for x in (list(pom.find('m:properties',ns)) if pom.find('m:properties',ns) is not None else [])}
 for dep in list(pom.findall('.//m:dependency',ns))+[pom.find('m:parent',ns)]:
  if dep is None:continue
  group=dep.findtext('m:groupId',None,ns);name=dep.findtext('m:artifactId',None,ns);version=dep.findtext('m:version',None,ns) or 'parent-managed-unresolved';version=props.get(version[2:-1],version) if version.startswith('${') else version;coordinate=group+':'+name
  if any(r['coordinate']==coordinate and r['version']==version for r in dependencies):continue
  aid=add('artifact','artifact/'+uid(coordinate+version),coordinate=coordinate,version=version,sourceCommit=None,correspondence='declared',digest=None,evidence=ev(f['path']));dependencies.append(dict(coordinate=coordinate,version=version,artifact=aid))
for name,rows in [('entry-ledger',entries),('registration-ledger',registrations),('io-ledger',io),('caller-contract-ledger',callerContracts),('subscription-ledger',subscriptions),('construction-ledger',construction),('source-review',sourceReview),('test-assertion-ledger',testLedger),('dependency-ledger',dependencies),('openapi-ledger',schemaLedger),('schema-ledger',[dict(id=r['id'],label=r['label'],fields=len(r['fields'])) for r in records if r['kind']=='shape'])]:(OUT/(name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
