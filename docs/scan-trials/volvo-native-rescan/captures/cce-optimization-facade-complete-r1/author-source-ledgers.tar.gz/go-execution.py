"""Native body transcription, developed against pinned Go AST; working acceptance remains partial."""
import re,collections
AST=json.loads((D/'source-ast.json').read_text());F={x['path']:x for x in AST['files']};nodes={}
def walknode(x):
 if isinstance(x,dict):
  yield x
  for k,v in x.items():
   if k!='text':yield from walknode(v)
 elif isinstance(x,list):
  for n in x:yield from walknode(n)
for path,f in F.items():
 f['imports']={}
 for i in f['ast'].get('Imports',[]):
  p=i['Path']['text'].strip('"');name=(i.get('Name') or {}).get('Name') or p.split('/')[-1]
  if name not in ['.','_']:f['imports'][name]=p
 for n in walknode(f['ast']):
  if n.get('kind') in ['FuncDecl','FuncLit']:nodes[path+':'+str(n['start'])]=n
B={x['key']:x for x in methods};FUN=collections.defaultdict(list);REC=collections.defaultdict(list)
for m in methods:
 if m['name'].startswith('<lambda'):continue
 if m['receiver']:REC[(m['receiver']['type'].lstrip('*'),m['name'])].append(m)
 else:FUN[(m['package'],m['name'])].append(m)
CALLS=[];CLOSURES=[];LIMITS=[];VT={};DELEGATE={};METHOD_RECEIVER={}
TYPE_REFERENCES={x['type'].lstrip('*') for m in M['methods'] for x in [*m['parameters'],*m['results'],*([m['receiver']] if m['receiver'] else [])] if x['type']}
TYPE_REFERENCES.update(f['type'].lstrip('*') for t in M['types'].values() for f in t['fields'] if f['type'])
# Exact source Fx associations prepared separately; only host-invariant unique concrete types bound.
exec((D/'di.py').read_text(),globals())
FIELD_TARGET_TYPES={}
LOCAL_METHOD_SIGNATURES={};LOCAL_FUNCTION_SIGNATURES={}
def signature(n,path):
 ps=(n.get('Params') or {}).get('List',[]);return {'path':path,'lines':n['lines'],'source':n['text'],'parameterCount':sum(len(f.get('Names',[])) or 1 for f in ps),'variadic':bool(ps and ps[-1]['Type']['kind']=='Ellipsis'),'returnKind':'value' if (n.get('Results') or {}).get('List') else 'void'}
def normsig(t):return re.sub(r'\s+','',t or '')
for path,f in F.items():
 for n in walknode(f['ast']):
  if n.get('kind')=='FuncType':LOCAL_FUNCTION_SIGNATURES[normsig(n['text'])]=signature(n,path)
  if n.get('kind')!='TypeSpec':continue
  t=n['Type'];key='cce-optimization-facade/'+path.rsplit('/',1)[0]+'::'+n['Name']['Name']
  if t['kind']=='FuncType':LOCAL_FUNCTION_SIGNATURES[key]=signature(t,path)
  if t['kind']=='InterfaceType':
   for fld in (t.get('Methods') or {}).get('List',[]):
    if fld['Type']['kind']=='FuncType':
     for name in fld.get('Names',[]):LOCAL_METHOD_SIGNATURES[(key,name['Name'])]=signature(fld['Type'],path)
LOCAL_SIGNATURE_CALLS=[];RANGES=[];MAP_CONSTRUCTIONS=[]
def tx(n):return (n or {}).get('text','')
def maptypes(t):
 if not t or not t.startswith('map['):return None,None
 depth=1;i=4
 while i<len(t) and depth:
  if t[i]=='[':depth+=1
  elif t[i]==']':depth-=1
  i+=1
 return (t[4:i-1],t[i:]) if depth==0 else (None,None)
def tupletypes(t):
 parts=[];start=0;depth=0
 for i,c in enumerate(t):
  if c in '[({':depth+=1
  elif c in '])}':depth-=1
  elif c==',' and depth==0:parts.append(t[start:i]);start=i+1
 parts.append(t[start:]);return parts
def alias(t):
 seen=set()
 while t and t in M['types'] and t not in seen:
  seen.add(t);a=M['types'][t].get('alias')
  if not a:break
  t=a
 return t
class Body:
 def __init__(self,m):
  self.m=m;self.key=hash(m['key']);self.owner=m['implementation'];self.n=nodes[m['key']];self.front=[(m['entry'],'normal',None,[])];self.env={};self.count=0;self.pending=[];self.loop=[];self.breaks=[];self.fallthrough=[];self.defers=[];self.conditional_defers=set();self.defer_depth=0
  for p,v in zip(next(x for x in M['methods'] if x['key']==m['key'])['parameters'],m['parameters']):self.env[p['name']]=v;VT[v]='[]'+p['type'][3:] if (p['type'] or '').startswith('...') else p['type']
  if m['receiver'] and m['receiver']['name']:self.env[m['receiver']['name']]=m['nativeReceiver'];VT[m['nativeReceiver']]=m['receiver']['type']
  for name,v in m.get('captureEnv',{}).items():self.env[name]=v
 def evidence(self,n):return [ev(self.m['path'],(n or self.n)['lines'])]
 def op(self,action,label,n=None,result=None,**kw):
  self.count+=1;key=self.key+'/n/'+str(self.count);e=self.evidence(n);oid=add('operation',key,owner=self.owner,action=action,label=label or action,resolution=None,bindings=[],result=result,exit=None,httpStatus=None,evidence=e)
  R[oid].update(kw)
  for i,(f,on,cond,vals) in enumerate(self.front):add('transition',key+'/'+str(i),owner=self.owner,**{'from':f,'to':oid},on=on,condition=cond,values=[v for v in vals if v],evidence=e)
  self.front=[(oid,'normal',None,[])];return oid
 def val(self,at,label,n=None,typ=None,role='definition',path=None):
  v=add('value',self.key+'/v/'+str(len(R)),owner=self.owner,definition=at,label=label or '<source value>',role=role,representation='source',shape=shapeids.get((typ or '').lstrip('*')),accessPath=path or [],evidence=self.evidence(n));VT[v]=typ;return v
 def flow(self,a,b,at,why,n=None):
  if a and b:add('flow',self.key+'/'+hash(a+b+at+why),owner=self.owner,**{'from':a,'to':b},at=at,transform=why,evidence=self.evidence(n),gaps=[],assumptions=[])
 def compute(self,n,label,inputs=(),typ=None,path=None):
  op=self.op('compute',label,n);v=self.val(op,label,n,typ,path=path);R[op]['result']=v
  for a in inputs:self.flow(a,v,op,label,n)
  return v
 def limitation(self,n,reason,inputs=()):
  key=self.key+'/'+hash(str(n.get('start'))+reason);g=gap(self.owner,'execution/'+key,'Source execution projection',reason,'Use source association; complete pending native semantics or retain documented automatic query limit.',self.evidence(n));add('claim','execution/'+key,owner=self.owner,statement=reason,basis='source_declared',inputs=list(dict.fromkeys([g,*[x for x in inputs if x]])),assumptions=[],evidence=self.evidence(n));self.pending.append(g);LIMITS.append({'owner':self.owner,'path':self.m['path'],'lines':n['lines'],'reason':reason,'gap':g});return g
 def typ(self,n):
  if not n:return None
  k=n['kind']
  if k=='ParenExpr':return self.typ(n['X'])
  if k in ['StructType','InterfaceType','FuncType']:return tx(n)
  if k=='ChanType':
   t=self.typ(n['Value']);return ('<-chan ' if tx(n).startswith('<-chan') else 'chan ')+t if t else None
  if k=='Ident':
   name=n['Name'];key=self.m['package']+'::'+name
   return name if name in ['string','bool','int','int32','int64','uint','uint32','uint64','byte','rune','any','error','float32','float64'] else key if key in M['types'] else None
  if k=='SelectorExpr' and tx(n['X']) not in self.env and tx(n['X']) in F[self.m['path']]['imports']:return F[self.m['path']]['imports'][tx(n['X'])]+'::'+tx(n['Sel'])
  if k=='StarExpr':
   t=self.typ(n['X']);return '*'+t if t else None
  if k=='ArrayType':
   t=self.typ(n['Elt']);return '[]'+t if t else None
  if k=='MapType':
   a,b=self.typ(n['Key']),self.typ(n['Value']);return 'map['+a+']'+b if a and b else None
  return None
 def field(self,typ,name,seen=None):
  seen=set() if seen is None else seen;typ=(typ or '').lstrip('*')
  if typ in seen:return None
  seen.add(typ);decl=M['types'].get(typ)
  if not decl:return None
  direct=next((f for f in decl['fields'] if f['name']==name),None)
  if direct:return direct['type']
  for f in decl['fields']:
   if f['name'] is None:
    if (f['type'] or '').lstrip('*').split('::')[-1]==name:return f['type']
    t=self.field(f['type'],name,seen)
    if t:return t
  return None
 def local_signature(self,fun,receiver,closure,args):
  sig=None
  if fun['kind']=='SelectorExpr' and receiver:
   t=(VT.get(receiver) or '').lstrip('*');sig=LOCAL_METHOD_SIGNATURES.get((t,tx(fun['Sel'])))
   if not sig:sig=LOCAL_FUNCTION_SIGNATURES.get(normsig(self.field(t,tx(fun['Sel']))))
  elif closure:
   t=VT.get(closure);sig=LOCAL_FUNCTION_SIGNATURES.get(t) or LOCAL_FUNCTION_SIGNATURES.get(normsig(t))
  if sig and (len(args)==sig['parameterCount'] or sig['variadic'] and len(args)>=sig['parameterCount']-1):return sig
  return None
 def promoted_receiver(self,fun,receiver):
  if fun.get('kind')!='SelectorExpr' or not receiver:return receiver
  typ=(VT.get(receiver) or '').lstrip('*');name=tx(fun['Sel'])
  if REC.get((typ,name)):return receiver
  frontier=[(typ,[])];seen=set()
  while frontier:
   nxt=[];matches=[]
   for typ,path in frontier:
    if typ in seen:continue
    seen.add(typ);decl=M['types'].get(typ)
    if not decl:continue
    for f in decl['fields']:
     if f['name'] is not None:continue
     t=(f['type'] or '').lstrip('*');field=t.split('::')[-1];route=path+[(field,f['type'])]
     if len(REC.get((DI.get(t,t),name),[]))==1:matches.append(route)
     else:nxt.append((t,route))
   if matches:
    if len(matches)!=1:return receiver
    for field,t in matches[0]:receiver=self.compute(fun,'Source promoted method embedded receiver '+field,[receiver],t,path=[field])
    return receiver
   frontier=nxt
  return receiver
 def target(self,fun,receiver):
  if fun['kind'] in ['IndexExpr','IndexListExpr']:
   generic=self.target(fun['X'],receiver)
   if generic and (nodes[generic['key']]['Type'].get('TypeParams') or {}).get('List'):return generic
   return None
  k=fun['kind'];c=[]
  if k=='Ident' and fun['Name'] not in self.env:c=FUN.get((self.m['package'],fun['Name']),[])
  elif k=='SelectorExpr':
   name=tx(fun['Sel']);x=tx(fun['X']);imp=F[self.m['path']]['imports'].get(x) if x not in self.env else None
   if imp:c=FUN.get((imp,name),[])
   elif receiver:
    typ=FIELD_TARGET_TYPES.get(receiver,(VT.get(receiver) or '').lstrip('*'));typ=DI.get(typ,typ);c=REC.get((typ,name),[])
  return c[0] if len(c)==1 else None
 def expr(self,n,need=True):
  if not n:return None
  k=n['kind'];s=tx(n)
  if k=='Ident':
   if n['Name'] in self.env:return self.env[n['Name']]
   candidates=FUN.get((self.m['package'],n['Name']),[])
   if len(candidates)==1:
    target=candidates[0];v=self.compute(n,'Source function reference '+s);DELEGATE[v]=(target,[]);add('claim','function-reference/'+hash(v),owner=self.owner,statement='Source function value references available declaration; this is registration/construction, not eager invocation.',basis='source_declared',inputs=[v,target['implementation']],assumptions=[],evidence=self.evidence(n));return v
   return self.compute(n,s,typ='bool' if s in ['true','false'] else self.typ(n))
  if k=='BasicLit':return self.compute(n,s,typ={'STRING':'string','INT':'untyped-int','FLOAT':'untyped-float'}.get(n.get('Kind')))
  if k=='ParenExpr':return self.expr(n['X'],need)
  if k=='SelectorExpr':
   if tx(n['X']) not in self.env and tx(n['X']) in F[self.m['path']]['imports']:
    target=self.target(n,None);v=self.compute(n,'Source package-qualified symbol '+s)
    if target:
     DELEGATE[v]=(target,[]);add('claim','function-reference/'+hash(v),owner=self.owner,statement='Source package-qualified function value references available declaration; package name is compile-time qualification, not a runtime receiver or eager invocation.',basis='source_declared',inputs=[v,target['implementation']],assumptions=[],evidence=self.evidence(n))
    return v
   x=self.expr(n['X']);x=self.promoted_receiver(n,x);target=self.target(n,x)
   if target:
    v=self.compute(n,'Source method/function reference '+s,[x]);DELEGATE[v]=(target,[])
    if target['receiver']:METHOD_RECEIVER[v]=x
    add('claim','method-reference/'+hash(v),owner=self.owner,statement='Source method/function value association; receiver retained for instance method, no eager invocation or imported policy assumed.',basis='source_declared',inputs=[v,target['implementation'],x],assumptions=[],evidence=self.evidence(n));return v
   typ=self.field(VT.get(x),tx(n['Sel']));v=self.compute(n,'Source field projection '+s,[x],typ=typ,path=[tx(n['Sel'])]);concrete=DI_FIELDS.get(((VT.get(x) or '').lstrip('*'),tx(n['Sel'])))
   if concrete:FIELD_TARGET_TYPES[v]=concrete
   return v
  if k in ['UnaryExpr','StarExpr']:
   x=self.expr(n['X']);typ=VT.get(x)
   if k=='StarExpr':typ=typ[1:] if typ and typ.startswith('*') else None
   elif n.get('Op')=='&':typ='*'+typ if typ else None
   elif n.get('Op')=='<-':typ=re.sub(r'^(?:<-)?chan\s+','',alias(typ))if alias(typ)and re.match(r'^(?:<-)?chan\s+',alias(typ))else None
   return self.compute(n,'Source '+('dereference' if k=='StarExpr' else n.get('Op','unary'))+' '+s,[x],typ)
  if k in ['BinaryExpr','IndexExpr','SliceExpr','TypeAssertExpr']:
   children=[n.get(x) for x in (['X','Y'] if k=='BinaryExpr' else ['X','Index'] if k=='IndexExpr' else ['X','Low','High','Max'] if k=='SliceExpr' else ['X'])];inputs=[]
   if k=='BinaryExpr' and n['Op'] in ['&&','||']:
    left=self.expr(n['X']);b=self.op('branch','Short-circuit '+n['Op'],n);rightcond='left true' if n['Op']=='&&' else 'left false';skipcond='left false' if n['Op']=='&&' else 'left true';env=self.env.copy();self.front=[(b,'condition',rightcond,[left])];right=self.expr(n['Y']);rightfront=self.front;self.env=env;self.front=rightfront+[(b,'condition',skipcond,[left])];return self.compute(n,'Source short-circuit boolean '+s,[left,right],'bool')
   for c in children:
    if c:inputs.append(self.expr(c))
   typ=None
   if k=='BinaryExpr':typ='bool' if n['Op'] in ['==','!=','<','>','<=','>='] else VT.get(inputs[0])
   elif k=='TypeAssertExpr':typ=self.typ(n.get('Type'))
   elif inputs:
    t=alias(VT.get(inputs[0]));typ=t[2:] if t and t.startswith('[]') and k=='IndexExpr' else maptypes(t)[1] if t and t.startswith('map[') and k=='IndexExpr' else t if k=='SliceExpr' else None
   return self.compute(n,'Source '+k+' '+s,inputs,typ)
  if k=='CompositeLit':
   vals=[];keys=[];compositeType=self.typ(n.get('Type'));isMap=(alias(compositeType) or '').startswith('map[') or (n.get('Type') or {}).get('kind')=='MapType'
   for i,e in enumerate(n.get('Elts',[])):
    if e['kind']=='KeyValueExpr':
     keyvalue=self.expr(e['Key']) if isMap else None;value=self.expr(e['Value']);name=tx(e['Key']);keys.append((name,keyvalue,value)) if isMap else None
    else:value=self.expr(e);name=str(i)
    vals.append((name,value))
   at=self.op('compute','Source composite construction '+tx(n.get('Type')),n);v=self.val(at,s,n,compositeType);R[at]['result']=v
   for name,x in vals:self.flow(x,v,at,('Source map entry payload for key expression ' if isMap else 'Source constructed field/index ')+name,n)
   for name,keyvalue,x in keys:self.flow(keyvalue,v,at,'Source evaluated map key expression '+name,n)
   if isMap:
    row={'owner':self.owner,'path':self.m['path'],'lines':n['lines'],'operation':at,'map':v,'entries':[{'sourceKey':name,'key':k,'value':x} for name,k,x in keys]};MAP_CONSTRUCTIONS.append(row);add('claim','map-construction/'+hash(at),owner=self.owner,statement='Exact map construction with evaluated key expressions; keys are not struct field names: '+json.dumps(row),basis='source_declared',inputs=[at,v,*[x for _,k,value in keys for x in [k,value] if x]],assumptions=[],evidence=self.evidence(n))
   add('claim','construction/'+hash(at),owner=self.owner,statement='Exact source composite initializer: '+json.dumps(vals)+'. No imported wire body or complete heap state is inferred.',basis='source_declared',inputs=[at,v,*[x for _,x in vals if x],*[k for _,k,_ in keys if k]],assumptions=[],evidence=self.evidence(n));return v
  if k=='CallExpr':return self.call(n,need)
  if k=='FuncLit':
   target=B[self.m['path']+':'+str(n['start'])];v=self.compute(n,'Create source closure '+target['name']);captures=[];paramnames={x['Name'] for f in (n['Type'].get('Params') or {}).get('List',[]) for x in f.get('Names',[])};locals=set()
   for a in walknode(n.get('Body')):
    if a.get('kind')=='AssignStmt' and a.get('Tok')==':=':locals.update(x['Name'] for x in a.get('Lhs',[]) if x.get('kind')=='Ident')
    if a.get('kind')=='ValueSpec':locals.update(x['Name'] for x in a.get('Names',[]))
   used=set()
   def names(x):
    if isinstance(x,dict):
     if x.get('kind')=='Ident':used.add(x['Name']);return
     for key,y in x.items():
      if key not in ['text','Sel','Type','Name','Key']:names(y)
    elif isinstance(x,list):
     for y in x:names(y)
   names(n.get('Body'))
   for name in sorted((used&set(self.env))-paramnames-locals):
    actual=self.env[name];cid=add('value',hash(target['key'])+'/capture/'+hash(name),owner=target['implementation'],definition=target['entry'],label='Captured Go variable cell '+name,role='capture',representation='source',shape=R[actual].get('shape'),accessPath=[],evidence=self.evidence(n));VT[cid]=VT.get(actual);target.setdefault('captureEnv',{})[name]=cid;R[target['implementation']].setdefault('captures',[])
    if cid not in R[target['implementation']]['captures']:R[target['implementation']]['captures'].append(cid)
    captures.append({'name':name,'capture':cid,'value':actual,'mode':'reference'})
   DELEGATE[v]=(target,captures);claim=add('claim','closure/'+hash(v),owner=self.owner,statement='Source closure registration association; captures are variable-cell associations, not frozen field copies or scheduling: '+json.dumps(captures),basis='source_declared',inputs=[v,target['implementation'],*[x for c in captures for x in [c['capture'],c['value']]]],assumptions=[],evidence=self.evidence(n));CLOSURES.append({'owner':self.owner,'value':v,'callback':target['implementation'],'captures':captures,'claim':claim});return v
  self.limitation(n,'Unexpanded source expression '+k+': '+s);return self.compute(n,'Unexpanded source expression '+k+': '+s)
 def prepare(self,n):
  fun=n['Fun'];receiver=None;closure=None
  if fun['kind']=='SelectorExpr' and (tx(fun['X']) in self.env or tx(fun['X']) not in F[self.m['path']]['imports']):receiver=self.expr(fun['X'])
  elif fun['kind']=='FuncLit':closure=self.expr(fun)
  elif fun['kind']=='Ident':closure=self.env.get(fun['Name'])
  elif fun['kind']=='CallExpr' or fun['kind']in ['ParenExpr','TypeAssertExpr']and self.typ(fun)is None or fun['kind']=='IndexExpr'and self.target(fun,None)is None and (fun['X']['kind']=='Ident'and tx(fun['X'])in self.env or fun['X']['kind']not in ['Ident','SelectorExpr'] or fun['X']['kind']=='SelectorExpr'and tx(fun['X']['X'])not in F[self.m['path']]['imports']):closure=self.expr(fun)
  receiver=self.promoted_receiver(fun,receiver)
  actuals=n.get('Args',[])
  if fun['kind']=='Ident' and fun['Name'] in ['make','new'] and fun['Name'] not in self.env and (fun['Name']=='make' or self.typ(actuals[0]) is not None and not (actuals[0]['kind']=='Ident'and actuals[0]['Name']in self.env)):actuals=actuals[1:] # First operand is source type syntax, never an evaluated runtime argument.
  args=[self.expr(x) for x in actuals];return receiver,args,closure
 def call(self,n,need=True,prepared=None):
  fun=n['Fun'];receiver,args,closure=prepared or self.prepare(n)
  target=self.target(fun,receiver);captures=[];localSignature=self.local_signature(fun,receiver,closure,args)
  if closure in DELEGATE:
   target,captures=DELEGATE[closure]
   if target['receiver']:receiver=METHOD_RECEIVER.get(closure)
  name=tx(fun)
  conversion=self.typ(fun)
  is_conversion=not target and (fun['kind'] in ['Ident','StarExpr','ArrayType','InterfaceType','FuncType','ParenExpr'] and bool(conversion) or fun['kind']=='SelectorExpr' and conversion in TYPE_REFERENCES)
  if is_conversion:return self.compute(n,'Source Go type conversion '+name,args,conversion)
  if fun['kind']=='Ident' and name not in self.env and name=='panic':
   self.unwind_defers()
   value=args[0] if args else None;op=self.op('throw','Go panic '+tx(n),n,result=value,exit='exception');self.front=[];self.limitation(n,'Go panic value and local deferred-call associations retained; recover stack context and process-wide propagation are not mechanically established.',[op,*args]);return None
  if fun['kind']=='Ident' and name not in self.env and name in ['len','cap','make','new','append','copy','delete','clear','complex','real','imag','panic','recover']:
   typ='int' if name in ['len','cap','copy'] else self.typ((n.get('Args') or [None])[0]) if name in ['make','new'] else VT.get(args[0]) if args and name=='append' else None
   if name=='new':
    typ=typ or (VT.get(args[0]) if args else None)
    if typ:typ='*'+typ
   if name in ['delete','clear'] or not need:
    op=self.op('compute','Source builtin '+tx(n),n);return None
   return self.compute(n,'Source builtin '+tx(n),args,typ)
  params=[] if not target else next(x for x in M['methods'] if x['key']==target['key'])['parameters']
  ellipsis=bool(re.search(r'\.\.\.\s*\)$',tx(n)));variadic=bool(params and (params[-1]['type'] or '').startswith('...'))
  if target and not (len(args)==len(params) or variadic and len(args)>=len(params)-1):target=None
  if target and variadic and not ellipsis:
   fixed=len(params)-1;packed=self.compute(n,'Go source variadic argument slice construction',args[fixed:],'[]'+params[-1]['type'][3:]);args=args[:fixed]+[packed]
  op=self.op('call','Invoke '+tx(n),n);e=self.evidence(n)
  resolution=add('resolution',self.key+'/call/'+str(self.count),owner=self.owner,requestedArtifact=None,basis='source_local' if target else 'unresolved',target=target['implementation'] if target else None,candidates=[],evidence=e,binding=None);R[op]['resolution']=resolution
  if not target and receiver and fun['kind']=='SelectorExpr':
   rt=(VT.get(receiver)or'').lstrip('*');names=tx(fun['Sel']);alternatives=[]
   for host,bindings in HOST_DI.items():
    for candidate in REC.get((bindings.get(rt,rt),names),[]):
     if candidate['implementation']not in alternatives:alternatives.append(candidate['implementation'])
   R[resolution]['candidates']=alternatives
  if receiver:R[op]['receiver']=receiver
  if target:
   R[op]['bindings']=[{'parameter':p,'value':a} for p,a in zip(target['parameters'],args)]
   if captures:R[op]['captureBindings']=[{'capture':c['capture'],'value':self.env.get(c['name'],c['value']),'mode':'reference'} for c in captures]
   if not target['receiver']:R[op].pop('receiver',None)
   resulttypes=[x['type'] for x in target['results']];typ=resulttypes[0] if len(resulttypes)==1 else 'source-tuple('+','.join(resulttypes)+')' if resulttypes else None
  else:resulttypes=[];typ=None
  v=self.val(op,'Source invocation result '+tx(n),n,typ) if need and (not target or target['returnKind']!='void') and not (not target and localSignature and localSignature['returnKind']=='void') else None;R[op]['result']=v
  if target and fun['kind'] in ['IndexExpr','IndexListExpr']:
   targs=fun.get('Indices') or [fun.get('Index')];add('claim','generic-call/'+hash(op),owner=self.owner,statement='Exact source explicit generic instantiation '+tx(fun)+'; type operands are not runtime formal arguments. Actual source method identity/signature is retained; general inferred type substitution/heap dispatch is not claimed.',basis='source_declared',inputs=[op,target['implementation']],assumptions=[],evidence=e)
  if localSignature:
   se=[ev(localSignature['path'],localSignature['lines'])];sg=add('claim','local-signature/'+hash(op),owner=self.owner,statement='Actual local interface/function-type signature establishes immediate return kind and arity, not concrete implementation or imported policy: '+json.dumps(localSignature),basis='source_declared',inputs=[op],assumptions=[],evidence=se+self.evidence(n));LOCAL_SIGNATURE_CALLS.append({'operation':op,'owner':self.owner,'callSource':tx(n),'signature':localSignature,'result':v,'boundImplementation':target['implementation'] if target else None,'claim':sg})
  claim=add('claim','call-operands/'+hash(op),owner=self.owner,statement='Exact source call operands/result association. No generic argument-to-result lineage. '+json.dumps({'callee':name,'functionValue':closure,'receiver':receiver,'arguments':args,'result':v,'returnedSourceTypes':resulttypes}),basis='source_declared',inputs=[op,*args,*([closure]if closure else[]),*([receiver] if receiver else []),*([v] if v else [])],assumptions=[],evidence=e)
  if self.m['path'].startswith('internal/database/postgres/') and fun['kind']=='SelectorExpr' and tx(fun['Sel'])=='Scan':
   for arg,actual in zip(n.get('Args',[]),args):
    if arg['kind']=='UnaryExpr' and arg.get('Op')=='&' and arg['X']['kind']=='Ident':
     name=arg['X']['Name'];before=self.env.get(name);after=self.val(op,'Source post-Scan local '+name+'; decoded field contents unresolved',n,VT.get(before));self.env[name]=after
     self.limitation(n,'Exact local pointer-out mutation: '+name+' is passed by address to row.Scan then read by local conversion. Post-call source value is retained separately from prior zero initialisation and Scan error result. Imported decoding/heap contents are not mechanically inferred.',[op,actual,before,after,receiver])
  if self.m['path'].startswith('internal/database/postgres/') and fun['kind']=='SelectorExpr' and tx(fun['Sel'])=='Scan':
   roots={}
   for arg,actual in zip(n.get('Args',[]),args):
    if arg['kind']=='UnaryExpr' and arg.get('Op')=='&' and arg['X']['kind']=='SelectorExpr':
     root=arg['X']
     while root.get('kind')=='SelectorExpr':root=root['X']
     if root.get('kind')=='Ident' and root['Name']in self.env:roots.setdefault(root['Name'],[]).append((tx(arg['X']),actual))
   for name,fields in roots.items():
    before=self.env[name];after=self.val(op,'Source post-Scan struct '+name+'; decoded fields unresolved',n,VT.get(before));self.env[name]=after
    self.limitation(n,'Exact pointer-out selector mutation through row.Scan: '+json.dumps(fields)+'. Post-call aggregate remains distinct from zero initializer/error result; field decoding/alias joins are not automatically inferred.',[op,before,after,receiver,*[a for f,a in fields]])
  codec=None
  if fun['kind']=='SelectorExpr':
   root=F[self.m['path']]['imports'].get(tx(fun['X'])) if tx(fun['X']) not in self.env else None
   if root in ['encoding/json','encoding/xml','google.golang.org/protobuf/proto'] and tx(fun['Sel'])=='Unmarshal':codec=root+'.Unmarshal'
   if tx(fun['Sel'])=='Decode' and fun['X'].get('kind')=='CallExpr':
    cf=fun['X']['Fun'];pkg=F[self.m['path']]['imports'].get(tx(cf.get('X'))) if cf.get('kind')=='SelectorExpr' else None
    if pkg in ['encoding/json','encoding/xml'] and tx(cf.get('Sel'))=='NewDecoder':codec=pkg+'.Decoder.Decode'
  if target and target['path'] in ['internal/gateway/assortment/client.go','internal/gateway/carfeatures/client.go'] and target['name']=='doRequest':codec='Available local doRequest response-formal to decoder alias'
  if codec:
   for arg,actual in zip(n.get('Args',[]),args):
    if arg['kind']=='UnaryExpr' and arg.get('Op')=='&' and arg['X']['kind']=='Ident':
     name=arg['X']['Name'];before=self.env.get(name);after=self.val(op,'Source post-decoding pointee '+name+'; conditional imported decoded fields unresolved',n,VT.get(before));self.env[name]=after
     self.limitation(n,'Exact source decoding/out-pointer association through '+codec+': '+name+' is supplied by address and read after the call. Post-call value is distinct from prior zero state and error result; conditional mutation, exact codec field contents and caller/callee alias joins remain query limitations.',[op,actual,before,after,receiver,*args])
  CALLS.append({'owner':self.owner,'path':self.m['path'],'lines':n['lines'],'source':tx(n),'operation':op,'functionValue':closure,'receiver':receiver,'arguments':args,'result':v,'target':target['implementation'] if target else None,'resultTypes':resulttypes,'claim':claim})
  return v
 def assign(self,lhs,value,n,declared=None):
  if lhs['kind']=='Ident':
   name=lhs['Name']
   if name=='_':return
   v=self.compute(n,'Source variable assignment '+name,[value],declared or VT.get(value));self.env[name]=v
   if value in DELEGATE:DELEGATE[v]=DELEGATE[value]
   if value in METHOD_RECEIVER:METHOD_RECEIVER[v]=METHOD_RECEIVER[value]
  else:
   refs=[]
   if lhs['kind'] in ['SelectorExpr','IndexExpr','StarExpr']:refs.append(self.expr(lhs['X']))
   if lhs['kind']=='IndexExpr':refs.append(self.expr(lhs['Index']))
   op=self.op('compute','Source mutable assignment '+tx(lhs),n);v=self.val(op,'Assigned '+tx(lhs),n,VT.get(value),role='field',path=[tx(lhs)]);R[op]['result']=v;self.flow(value,v,op,'Source assignment to '+tx(lhs),n)
   add('claim','mutation/'+hash(op),owner=self.owner,statement='Source mutation with receiver/index/value association. No automatic heap alias or per-iteration cell unification: '+json.dumps({'target':tx(lhs),'receiverAndIndex':refs,'value':value,'assigned':v}),basis='source_declared',inputs=[op,v,*refs,*([value] if value else [])],assumptions=[],evidence=self.evidence(n))
 def joinenv(self,envs,base,n):
  out={}
  for name,orig in base.items():
   vals=list(dict.fromkeys(e.get(name,orig) for e in envs))
   out[name]=vals[0] if len(vals)==1 else self.compute(n,'Source reaching definitions join '+name,vals,VT.get(orig))
  self.env=out
 def stmts(self,ns):
  for n in ns:
   if not self.front:break
   self.stmt(n)
 def stmt(self,n):
  if not n:return
  k=n['kind']
  if k=='BlockStmt':self.stmts(n.get('List',[]));return
  if k=='ExprStmt':self.expr(n['X'],False);return
  if k=='AssignStmt':
   vals=[]
   for r in n.get('Rhs',[]):
    v=self.expr(r);vals.append(v)
   lhs=n.get('Lhs',[])
   if len(vals)==1 and len(lhs)>1:
    t=VT.get(vals[0]);types=[]
    if t and t.startswith('source-tuple('):types=tupletypes(t[len('source-tuple('):-1])
    elif n['Rhs'][0]['kind'] in ['IndexExpr','TypeAssertExpr']:types=[t,'bool']
    source=vals[0];vals=[self.compute(n,'Source Go multiple-result projection ['+str(i)+'] from '+tx(n['Rhs'][0]),[source],types[i] if i<len(types) else 'bool' if i==1 and n['Rhs'][0]['kind'] in ['IndexExpr','TypeAssertExpr'] else None,path=[str(i)]) for i in range(len(lhs))]
   for l,v in zip(lhs,vals):
    if n['Tok'] not in ['=',':=']:v=self.compute(n,'Source compound assignment '+n['Tok'],[self.expr(l),v],VT.get(v))
    self.assign(l,v,n)
   return
  if k=='DeclStmt':
   for spec in n['Decl'].get('Specs',[]):
    if spec['kind']!='ValueSpec':continue
    vals=[self.expr(x) for x in spec.get('Values',[])];typ=self.typ(spec.get('Type'))
    for i,name in enumerate(spec.get('Names',[])):
     v=vals[i] if i<len(vals) else self.compute(spec,'Go zero initialisation '+name['Name'],typ=typ)
     self.assign(name,v,spec,typ)
   return
  if k=='ReturnStmt':
   values=[self.expr(x) for x in n.get('Results',[])]
   if not values:values=[self.env.get(r['name']) for r in self.m['results'] if r['name']]
   value=values[0] if len(values)==1 else self.compute(n,'Source Go return-signature tuple projection (not allocated runtime/wire object)',values,'source-tuple('+','.join(str(r['type']) for r in self.m['results'])+')') if values else None
   self.unwind_defers()
   op=self.op('return','Return source values '+tx(n),n,result=value,exit='normal');self.front=[];return
  if k=='IfStmt':
   outer=self.env.copy();self.stmt(n.get('Init'));base=self.env.copy();base_defers=list(self.defers);branch_defers=[];cond=self.expr(n['Cond']);branch=self.op('branch','If '+tx(n['Cond']),n);ends=[];envs=[]
   for body,guard in [(n['Body'],'true: '+tx(n['Cond'])),(n.get('Else'),'false: '+tx(n['Cond']))]:
    self.env=base.copy();self.defers=list(base_defers);self.front=[(branch,'condition',guard,[cond])];self.defer_depth+=1;self.stmt(body);self.defer_depth-=1;branch_defers.extend(d for d in self.defers if d not in base_defers)
    if self.front:ends.extend(self.front);envs.append(self.env.copy())
   self.defers=base_defers+list({d[2]:d for d in branch_defers}.values());self.front=ends
   if ends:
    joinedbase=outer.copy();shadow=set()
    init=n.get('Init')
    if init and init['kind']=='AssignStmt' and init['Tok']==':=':shadow={x['Name'] for x in init['Lhs'] if x['kind']=='Ident'}
    for e in envs:
     for name in shadow:
      if name in outer:e[name]=outer[name]
    self.joinenv(envs,joinedbase,n)
   return
  if k=='TypeSwitchStmt':
   outer=self.env.copy();self.stmt(n.get('Init'));base=self.env.copy();ass=n['Assign'];assertion=(ass.get('Rhs') or [ass.get('X')])[0];actual=self.expr(assertion['X']);name=(ass.get('Lhs') or [{}])[0].get('Name');remaining=self.front;ends=[];envs=[];default=None
   for case in n['Body'].get('List',[]):
    if not case.get('List'):default=case;continue
    matched=[];self.env=base.copy();self.front=remaining
    for typ in case['List']:
     predicate=self.compute(typ,'Source dynamic type test '+tx(typ),[actual],'bool');branch=self.op('branch','Type case '+tx(typ),typ);matched.append((branch,'condition','dynamic type matches '+tx(typ),[predicate]));self.front=[(branch,'condition','dynamic type does not match '+tx(typ),[predicate])]
    remaining=self.front;self.front=matched;self.env=base.copy()
    if name:
     projected=self.compute(case,'Source type-switch case variable '+name,[actual],self.typ(case['List'][0]) if len(case['List'])==1 else VT.get(actual));self.env[name]=projected
    self.defer_depth+=1;self.stmts(case.get('Body',[]));self.defer_depth-=1
    if self.front:ends.extend(self.front);envs.append(self.env.copy())
   self.front=remaining;self.env=base.copy()
   if default:
    if name:self.env[name]=actual
    self.stmts(default.get('Body',[]))
   if self.front:ends.extend(self.front);envs.append(self.env.copy())
   self.front=ends
   if ends:self.joinenv(envs,outer,n)
   return
  if k=='SwitchStmt':
   outer=self.env.copy();self.stmt(n.get('Init'));base=self.env.copy();tag=self.expr(n.get('Tag'));remaining=self.front;ends=[];envs=[];cases=n['Body'].get('List',[]);casefronts={};default=None
   # Evaluate predicates in source order; default selected only after all predicates fail.
   for i,case in enumerate(cases):
    if not case.get('List'):default=i;continue
    matched=[];self.env=base.copy();self.front=remaining
    for c in case['List']:
     cv=self.expr(c);predicate=self.compute(c,'Source switch case equality '+tx(c),[tag,cv] if tag else [cv],'bool');branch=self.op('branch','Case predicate '+tx(c),c);matched.append((branch,'condition','case matches: '+tx(c),[predicate]));self.front=[(branch,'condition','case does not match: '+tx(c),[predicate])]
    remaining=self.front;casefronts[i]=matched
   if default is not None:casefronts[default]=remaining
   else:ends.extend(remaining);envs.append(base.copy())
   self.front=[];after=self.op('compute','Source switch exit join',n);fall=[];fallenvironments=[];breakscope=[];self.breaks.append((after,breakscope))
   for i,case in enumerate(cases):
    self.front=casefronts.get(i,[])+fall;self.env=base.copy()
    if fallenvironments:self.joinenv([base,*fallenvironments],base,case)
    self.fallthrough.append([]);self.defer_depth+=1;self.stmts(case.get('Body',[]));self.defer_depth-=1;nextfall=self.fallthrough.pop()
    if self.front:ends.extend(self.front);envs.append(self.env.copy())
    fall=[f for f,e in nextfall];fallenvironments=[e for f,e in nextfall]
   self.breaks.pop();envs.extend(breakscope)
   for f,on,condition,values in ends:add('transition',self.key+'/switch-exit/'+hash(f+after+str(condition)),owner=self.owner,**{'from':f,'to':after},on=on,condition=condition,values=values,evidence=self.evidence(n))
   self.front=[(after,'normal',None,[])] if ends or breakscope else []
   if self.front:self.joinenv(envs,outer,n)
   return
  if k in ['ForStmt','RangeStmt']:
   outer=self.env.copy();self.stmt(n.get('Init'));collection=self.expr(n.get('X')) if k=='RangeStmt' else None;header=self.op('compute','Go loop iteration entry',n);self.front=[(header,'normal',None,[])];cond=self.expr(n.get('Cond')) if k=='ForStmt' else collection;b=self.op('branch','Loop condition: '+(tx(n.get('Cond')) or ('next element of '+tx(n.get('X')) if k=='RangeStmt' else 'true')),n)
   save=self.front;self.front=[];after=self.op('compute','Loop exit join',n);self.front=[];post=self.op('compute','Loop post/continue target',n);self.front=[(b,'condition','iteration exists' if k=='RangeStmt' else 'condition true',[cond] if cond else [])]
   if k=='RangeStmt':
    t=alias(VT.get(collection));mapkey,mapval=maptypes(t);keytype=None;itemtype=None;rangeKind='unresolved'
    if mapkey:keytype,itemtype,rangeKind=mapkey,mapval,'map'
    elif t and t.startswith('[]'):keytype,itemtype,rangeKind='int',t[2:],'slice-or-array-source-projection'
    elif t and re.match(r'^\[\d+\]',t):keytype,itemtype,rangeKind='int',t.split(']',1)[1],'array'
    elif t=='string':keytype,itemtype,rangeKind='int','rune','string'
    elif t in ['int','int8','int16','int32','int64','uint','uint8','uint16','uint32','uint64','uintptr','untyped-int']:keytype,rangeKind=('int' if t=='untyped-int' else t),'integer'
    elif t and re.match(r'^(?:<-)?chan\s+',t):keytype,rangeKind=re.sub(r'^(?:<-)?chan\s+','',t),'channel-element'
    RANGES.append({'owner':self.owner,'path':self.m['path'],'lines':n['lines'],'expression':tx(n['X']),'sourceType':VT.get(collection),'resolvedUnderlyingType':t,'rangeKind':rangeKind,'keyType':keytype,'valueType':itemtype,'collection':collection})
    add('claim','range-type/'+hash(self.owner+str(n['start'])),owner=self.owner,statement='Source range association: '+json.dumps(RANGES[-1])+'. Unknown collection/constraint types stay unresolved; no default int index is inferred. Channel single-variable range yields element; imported iterator/alias policy and generic substitution are not guessed.',basis='source_declared',inputs=[collection,b],assumptions=[],evidence=self.evidence(n))
    for key,label,typ in [('Key','key or first yielded value',keytype),('Value','element value',itemtype)]:
     lhs=n.get(key)
     if lhs:
      v=self.compute(n,'Source range '+label+' for this iteration',[collection],typ,path=['<iteration '+label+'>']);self.assign(lhs,v,n)
   self.loop.append((after,post));self.breaks.append((after,[]));self.defer_depth+=1;self.stmt(n['Body']);self.defer_depth-=1;self.breaks.pop();self.loop.pop();bodyenv=self.env.copy()
   for f,on,c,v in self.front:add('transition',self.key+'/loop-post/'+hash(f+post),owner=self.owner,**{'from':f,'to':post},on=on,condition=c,values=v,evidence=self.evidence(n))
   self.front=[(post,'normal',None,[])];self.stmt(n.get('Post'))
   for f,on,c,v in self.front:add('transition',self.key+'/loop-back/'+hash(f+header),owner=self.owner,**{'from':f,'to':header},on='iterate',condition='next source iteration',values=v,evidence=self.evidence(n))
   if k=='RangeStmt' or n.get('Cond'):add('transition',self.key+'/loop-end/'+hash(b+after),owner=self.owner,**{'from':b,'to':after},on='condition',condition='iteration exhausted' if k=='RangeStmt' else 'condition false',values=[cond] if cond else [],evidence=self.evidence(n))
   self.front=[(after,'normal',None,[])];self.joinenv([outer,bodyenv],outer,n);return
  if k=='BranchStmt':
   if n.get('Label'):
    self.limitation(n,'Source labelled branch target retained, not automatically linked: '+tx(n));self.front=[];return
   if n['Tok']=='fallthrough' and self.fallthrough:
    op=self.op('compute','Source fallthrough into next case body without predicate',n);self.fallthrough[-1].append(((op,'normal',None,[]),self.env.copy()));self.front=[];return
   if n['Tok']=='break' and self.breaks:
    target,envs=self.breaks[-1];op=self.op('compute','Source break',n);add('transition',self.key+'/branch/'+hash(op+target),owner=self.owner,**{'from':op,'to':target},on='break',condition=None,values=[],evidence=self.evidence(n));envs.append(self.env.copy());self.front=[];return
   if n['Tok']=='continue' and self.loop:
    target=self.loop[-1][1];op=self.op('compute','Source continue',n);add('transition',self.key+'/branch/'+hash(op+target),owner=self.owner,**{'from':op,'to':target},on='continue',condition=None,values=[],evidence=self.evidence(n));self.front=[];return
   self.limitation(n,'Source branch outside supported context: '+tx(n));return
  if k=='IncDecStmt':
   v=self.compute(n,'Source '+n['Tok'],[self.expr(n['X'])],'int');self.assign(n['X'],v,n);return
  if k=='SendStmt':
   channel=self.expr(n['Chan']);value=self.expr(n['Value']);op=self.op('compute','Source channel send '+tx(n),n)
   self.limitation(n,'Exact source channel send evaluates channel and payload before communication: '+tx(n)+'. Matching receiver, blocking/cancellation, iteration cells and cross-goroutine message/heap lineage are not mechanically joined.',[op,channel,value]);return
  if k=='DeferStmt':
   prepared=self.prepare(n['Call']);op=self.op('compute','Register defer (arguments evaluated now; invocation at exit)',n);self.defers.append((n['Call'],prepared,op))
   if self.defer_depth:self.conditional_defers.add(op)
   return
  if k=='GoStmt':
   self.call(n['Call'],False);op=self.front[-1][0];R[op]['waitsFor']='none';R[op]['result']=None;self.limitation(n,'Source Go goroutine starts without result handle. Scheduler/interleaving/process-wide panic/recover effects are not established by local query frame separation.',[op]);return
  self.limitation(n,'Unexpanded source statement '+k+': '+tx(n))
 def unwind_defers(self):
  for call,prepared,registration in reversed(self.defers):
   continuation=[]
   if registration in self.conditional_defers:
    branch=self.op('branch','Deferred call executes only if its source registration was reached in this invocation',call);continuation=[(branch,'condition','registration not reached',[])];self.front=[(branch,'condition','registration reached',[])]
   self.call(call,False,prepared)
   self.front+=continuation
   self.limitation(call,'Deferred source invocation after evaluating return values. Registration-time actuals and LIFO order retained; conditional registration, repeated loop registration, named result cells, panic/recover and heap aliases remain explicit finite query limitations.',[registration,*prepared[1]])
 def expand(self):
  for r in self.m['results']:
   if r['name']:
    v=self.val(self.m['entry'],'Go named result zero initialisation '+r['name'],self.n,r['type']);self.env[r['name']]=v
  self.stmt(self.n.get('Body'))
  if self.front:
   self.unwind_defers()
   vals=[self.env.get(x['name']) for x in self.m['results'] if x['name']];v=vals[0] if len(vals)==1 else None
   self.op('return','Implicit source function end',self.n,result=v,exit='normal');self.front=[]
  return self.pending

def expand_working():
 for m in methods:
  body=Body(m);pending=body.expand();coverage=R[P+'coverage/'+hash(m['key'])];coverage['scope']='Working native body transcription, source call/value/control review and acceptance are pending. Available source is not labelled external.';coverage['status']='partial';coverage['gaps'].extend(pending)
 (D/'map-construction-ledger.json').write_text(json.dumps(MAP_CONSTRUCTIONS,indent=2)+'\n')
 (D/'range-type-ledger.json').write_text(json.dumps(RANGES,indent=2)+'\n')
 (D/'local-signature-call-ledger.json').write_text(json.dumps(LOCAL_SIGNATURE_CALLS,indent=2)+'\n')
 (D/'native-call-ledger.json').write_text(json.dumps(CALLS,indent=2)+'\n');(D/'callback-associations.json').write_text(json.dumps(CLOSURES,indent=2)+'\n');(D/'native-expansion-limits.json').write_text(json.dumps(LIMITS,indent=2)+'\n')
