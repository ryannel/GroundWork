"""Finite source-reviewed invariants, separate from strict graph-query acceptance."""
import json,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;load=lambda n:json.loads((D/(n+'.json')).read_text());b=load('working.bundle');R={r['id']:r for r in b['records']};W=load('write-ledger');C=load('native-call-ledger');M=load('native-method-ledger');proof=[]
def checked(name,rows,fieldnames,selectors=None):
 assert rows,name
 for w in rows:
  assert [c for c,v in w['fields']]==fieldnames,(name,w['fields']);assert R[w['write']]['acknowledgement']=='success_result';assert 'nil' in R[w['write']]['condition'];assert R[w['effect']]['selection']==w['selection']
  if selectors is not None:assert len(w['selection'])==selectors,(name,w['selection'])
 proof.append({'name':name,'writes':[w['write']for w in rows],'sourceEvidence':list(dict.fromkeys(e for w in rows for e in R[w['operation']]['evidence']))})
checked('Car update SET excludes WHERE id',[w for w in W if 'SET versions = $2' in (w['sql']or'')],['versions','produced_from','produced_to'],1)
checked('Ruleset ID write excludes four WHERE keys',[w for w in W if 'SET ruleset_id = $1' in (w['sql']or'')and 'pno12 = $2'in w['sql']],['ruleset_id'],4)
checked('Delete car id is selector only',[w for w in W if (w['sql']or'').startswith('DELETE FROM cars')],[],1)
for table,fields in [('markets',['name']),('clients',['client_type']),('policies',['policy_type']),('offer_mappings',['client_id','policy_id','customer_type','business_model','sales_model'])]:
 checked(table+' conflict update writes source SET fields only',[w for w in W if (w['sql']or'').startswith('INSERT INTO '+table+' ')and w['branch']=='conflict-update'],fields,1)
wrapper=next(m for m in M if m['path']=='internal/gateway/client.go'and m['name']=='Do');oapi=[c for c in C if c['path']=='internal/gateway/carspecadapter/client.gen.go'and c['source'].startswith('c.Client.Do(')];assert oapi and all(c['target']==wrapper['implementation']for c in oapi);io=load('io-ledger');assert not any(c['path']=='internal/gateway/carspecadapter/client.gen.go'for c in io);assert any(c['path']=='internal/gateway/client.go'and c['family']=='dynamic-http'for c in io);proof.append({'name':'Adapter default injected Do is local; underlying net/http Do is one unresolved-destination transport','localWrapper':wrapper['implementation'],'calls':[c['operation']for c in oapi]})
for name in ['GetCarSpecification','GetLocalEditions']:
 assert any(r.get('family')=='adapter'and r.get('name')==name for r in load('outbound-construction-ledger'))
assert all(R[w['write']]['fields']==[]for w in W if R[w['write']]['mode']=='delete')
assert len(load('subscription-ledger'))==3 and len(load('worker-registration-ledger'))==4
assert len(load('rest-registration-ledger'))==45
report={'status':'passed','scope':'Finite independently source-read SQL column/selection/upsert and local HTTP wrapper invariants; not a replacement for strict graph queries or whole source ledger.','bundleFileSHA256':hashlib.sha256((D/'working.bundle.json').read_bytes()).hexdigest(),'assertions':proof};(D/'source-acceptance.json').write_text(json.dumps(report,indent=2)+'\n');print('Source invariants passed',len(proof))
