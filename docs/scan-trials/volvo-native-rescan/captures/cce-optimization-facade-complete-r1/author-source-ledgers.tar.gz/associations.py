"""Source registration/dispatch/shape/constructor associations; never eager callback execution."""
HIGHER=[];DISPATCH=[];DECL=[];LIFECYCLE=[];SWAGGER=[]
for c in CALLS:
 m=lookupmethod[c['owner']]
 for i,arg in enumerate(c['arguments']):
  if arg not in DELEGATE:continue
  target,caps=DELEGATE[arg];callee=lookupmethod.get(c['target']);formal=callee['parameters'][i]if callee and i<len(callee['parameters'])else None;row={'caller':c['owner'],'operation':c['operation'],'argumentIndex':i,'value':arg,'callback':target['implementation'],'receiver':METHOD_RECEIVER.get(arg),'captures':caps,'callee':c['target'],'formal':formal,'source':c['source'],'path':c['path'],'lines':c['lines']};HIGHER.append(row)
  add('claim','higher-order/'+hash(c['operation']+str(i)),owner=c['owner'],statement='Exact source higher-order registration/formal/target/captured-variable association: '+json.dumps(row)+'. Caller closure and available local helper bodies are inspected. Imported policy and generic delegate/heap dispatch may remain automatic query limitations; registration is not eager invocation.',basis='source_declared',inputs=[c['operation'],arg,target['implementation'],*([formal]if formal else[]),*([row['receiver']]if row['receiver']else[]),*[x for cap in caps for x in [cap['capture'],cap['value']]]],assumptions=[],evidence=[ev(c['path'],c['lines'])])
 if 'query.AddHandler['in c['source']or'command.AddHandler['in c['source']or'query.Dispatch['in c['source']or'command.Dispatch['in c['source']or c['path'].endswith('/dispatcher.go'):
  row={**c,'actualTypes':[VT.get(v)for v in c['arguments']]};DISPATCH.append(row);add('claim','dispatch/'+hash(c['operation']),owner=c['owner'],statement='Exact local generic dispatcher source association: '+json.dumps(row)+'. Query key is reflect.TypeOf(key[Q,R]); command key key[C]. Registration preserves actual concrete handler/constructor, distinct per host. Handle formals and map lookup/type assertion body are available/inspected. Automatic inferred generic value dispatch and registry/heap context joining remain partial; not an external service or missing local code.',basis='source_declared',inputs=[c['operation'],*c['arguments'],*([c['target']]if c['target']else[])],assumptions=[],evidence=[ev(c['path'],c['lines'])])
# Exact top-level source value declarations including GraphQL documents, protobuf descriptors and global registries.
for path,f in F.items():
 for n in f['ast'].get('Decls',[]):
  if n['kind']!='GenDecl'or n.get('Tok')not in ['var','const']:continue
  cid=add('claim','declaration/'+hash(path+str(n['start'])),owner=source,statement='Exact source declaration; not fabricated execution: '+n['text'],basis='source_declared',inputs=[source],assumptions=[],evidence=[ev(path,n['lines'])]);DECL.append({'path':path,'lines':n['lines'],'claim':cid})
# Lifecycle callbacks: Fn formal/captures remain native; scheduling supplied by imported Fx.
seen=set()
for m in methods:
 for n in walknode(nodes[m['key']].get('Body')):
  if n.get('kind')!='CompositeLit'or tx(n.get('Type'))!='fx.Hook':continue
  for field in n.get('Elts',[]):
   if field['kind']!='KeyValueExpr'or tx(field['Key'])not in ['OnStart','OnStop']or field['Value']['kind']!='FuncLit':continue
   callback=B[m['path']+':'+str(field['Value']['start'])];kind=tx(field['Key'])
   for host in executions[m['implementation']]:
    if (callback['implementation'],host)in seen:continue
    seen.add((callback['implementation'],host));address=m['path']+'#'+kind+'@'+str(field['lines'][0]);e=[ev(m['path'],field['lines'])];row=expose('lifecycle/'+hash(address+host),callback,host,'startup'if kind=='OnStart'else'callback','lifecycle'if kind=='OnStart'else'callback','STARTUP'if kind=='OnStart'else'CALLBACK',address,e);row.update(registrationOwner=m['implementation'],hook=kind);LIFECYCLE.append(row)
# Explicit opaque frames for imported Swagger registration targets, no invented local method/formals.
for host in ['api','marketmapping']:
 row=next(r for r in rest_rows if r['host']==host and r['path']=='/swagger/*');key='swagger/'+host;iid=add('implementation',key,logicalId='registration-target:cce-optimization-facade:'+host+':'+row['handlerSource'],scope=source,entry=P+'operation/'+key+'/entry',parameters=[],returnKind='unresolved',evidence=[row['evidence']]);entry=add('operation',key+'/entry',owner=iid,action='entry',label='Imported Swagger handler registration target',resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=[row['evidence']]);opaque=add('operation',key+'/opaque',owner=iid,action='opaque',label='Exact imported handler body/signature unavailable',resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=[row['evidence']]);add('transition',key,owner=iid,**{'from':entry,'to':opaque},on='normal',condition=None,values=[],evidence=[row['evidence']]);g=gap(iid,key,'Imported registered handler','Pinned source names '+row['handlerSource']+'; imported implementation and formals unavailable.','Inspect exact http-swagger implementation before body/response claims.',[row['evidence']]);add('coverage',key,owner=iid,obligation='Imported registered handler',status='partial',scope='Source registration examined, body unavailable.',gaps=[g],evidence=[row['evidence']]);executions[iid]={};target={'implementation':iid};registration=expose('rest/'+key,target,host,'rest','http','GET','/swagger/*',[row['evidence']]);SWAGGER.append(registration);row.update(registration,status='source-bound-imported-target')
# Committed declared dependencies, no inferred implementation correspondence.
deps=[]
for match in re.finditer(r'^\s*([^\s()]+)\s+(v[^\s]+)(?:\s+//\s+indirect)?\s*$',pinned('go.mod'),re.M):
 module,version=match.groups();aid=add('artifact','go-module/'+hash(module),coordinate=module,version=version,correspondence='declared',sourceCommit=None,digest=None,evidence=anchor('go.mod'));deps.append({'module':module,'version':version,'artifact':aid})
# Every inspected source note remains a pinned native related fact, not sidecar-only analysis.
for i,note in enumerate(json.load(open(D/'review-notes.json'))):
 paths=note.get('paths',[]);e=sum((anchor(p)for p in paths),[])
 if not e:continue
 add('claim','source-review/'+str(i),owner=source,statement='Source semantic inspection: '+' '.join(note.get('facts',[])),basis='source_declared',inputs=[source],assumptions=['Source facts only; runtime configuration/activation/transport are separate.'],evidence=e)
(D/'higher-order-ledger.json').write_text(json.dumps(HIGHER,indent=2)+'\n');(D/'dispatch-ledger.json').write_text(json.dumps(DISPATCH,indent=2)+'\n');(D/'declaration-ledger.json').write_text(json.dumps(DECL,indent=2)+'\n');(D/'registration-ledger.json').write_text(json.dumps({'lifecycle':LIFECYCLE,'swagger':SWAGGER},indent=2)+'\n');(D/'dependency-audit.json').write_text(json.dumps(deps,indent=2)+'\n');(D/'rest-registration-ledger.json').write_text(json.dumps(rest_rows,indent=2)+'\n')

# Only market-mapping NewMarketMappingServer actually configures WithReadinessCheck.
m=method('internal/database/postgres/readycheck.go','IsReady');ready=expose('callback/readiness/marketmapping',m,'marketmapping','callback','callback','CALLBACK','internal/api/httpserver/server.go#WithReadinessCheck(postgres)',anchor('internal/api/httpserver/server.go')+[ev(m['path'],m['lines'])]);LIFECYCLE.append(ready)
(D/'registration-ledger.json').write_text(json.dumps({'lifecycle':LIFECYCLE,'swagger':SWAGGER},indent=2)+'\n')
# Source-owned Go init declarations are real language startup entries. Keep each path/start identity;
# package import closure is independent of which Fx provider constructor is eventually requested.
INITIALISERS=[]
for m in methods:
 if m['name']!='init':continue
 for host in executions[m['implementation']]:
  address=m['path']+'#init@'+str(m['lines'][0]);row=expose('go-init/'+hash(m['key']+host),m,host,'startup','lifecycle','STARTUP',address,[ev(m['path'],m['lines'])]);INITIALISERS.append(row)
  add('claim','go-init/'+hash(m['key']+host),owner=m['implementation'],statement='Actual source Go init declaration in the local package import closure of '+host+'. Every available production-named package file contributes imports, including blank Swagger imports. Distinct init declarations keep path/start identity. Package/global value initializer declarations are retained separately; exact imported module initialization, build/runtime activation and implicit ordering are not mechanically expanded as ordinary source calls.',basis='source_declared',inputs=[row['entry'],m['implementation'],components[host]],assumptions=['Source-compatible default Go file/profile; runtime observation and imported initializers unavailable.'],evidence=[ev(m['path'],m['lines'])]+app_e)
(D/'registration-ledger.json').write_text(json.dumps({'lifecycle':LIFECYCLE,'goInitialisers':INITIALISERS,'swagger':SWAGGER},indent=2)+'\n')
FX_INVOKES=[];FX_PROVIDERS=[]
for h in HIGHER:
 if h['source'].startswith('fx.Invoke('):
  m=lookupmethod[h['callback']]
  for host in executions[h['caller']]:
   address=h['path']+'#Fx.Invoke@'+str(h['lines'][0])+'/argument'+str(h['argumentIndex']);row=expose('fx-invoke/'+hash(h['operation']+str(h['argumentIndex'])+host),m,host,'startup','lifecycle','STARTUP',address,[ev(h['path'],h['lines']),ev(m['path'],m['lines'])]);row.update(registrationOperation=h['operation'],actualFunctionValue=h['value']);FX_INVOKES.append(row)
   add('claim','fx-invoke/'+hash(row['entry']),owner=m['implementation'],statement='Actual default source Fx.Invoke callback registration: '+json.dumps(row)+'. Genuine method/closure formals and captures retained; imported Fx activation/provisioning/timing and supplied options remain unresolved. The registration is not an eager call during option/delegate construction.',basis='source_declared',inputs=[row['entry'],h['operation'],h['value'],m['implementation']],assumptions=[],evidence=[ev(h['path'],h['lines']),ev(m['path'],m['lines'])])
 elif h['source'].startswith('fx.Provide(')or h['source'].startswith('fx.Annotate('):FX_PROVIDERS.append({**h,'entryDisposition':'Source provider/annotation declaration, not a separate inbound entry or proof of eager activation. Exact function reference/constructor body/formals/host binding associations retained; activation depends on imported Fx policy and dependency demand.'})
(D/'registration-ledger.json').write_text(json.dumps({'lifecycle':LIFECYCLE,'goInitialisers':INITIALISERS,'fxInvokes':FX_INVOKES,'fxProviders':FX_PROVIDERS,'swagger':SWAGGER},indent=2)+'\n')

stdlib=add('artifact','go-stdlib',coordinate='Go standard library',version='1.27.1 (consumer module declaration)',correspondence='declared',sourceCommit=None,digest=None,evidence=anchor('go.mod'))
for c in CALLS:
 op=R[c['operation']];resolution=R.get(op.get('resolution'))
 if not resolution or resolution['target']:continue
 node=callnode(c);prefixes=[]
 if node and node['Fun']['kind']=='SelectorExpr':
  prefix=F[c['path']]['imports'].get(tx(node['Fun']['X']))
  if prefix:prefixes.append(prefix)
 if c['receiver']and VT.get(c['receiver']):prefixes.append(VT[c['receiver']].lstrip('*').split('::')[0])
 if c.get('functionValue')and VT.get(c['functionValue']):prefixes.append(VT[c['functionValue']].lstrip('*').split('::')[0])
 candidates=[d for d in deps if any(p==d['module']or p.startswith(d['module']+'/')for p in prefixes)]
 if candidates:resolution['requestedArtifact']=max(candidates,key=lambda d:len(d['module']))['artifact']
 elif any(p and'.'not in p.split('/')[0]and not p.startswith('cce-optimization-facade')for p in prefixes):resolution['requestedArtifact']=stdlib
# Finite source generic registry correspondence. This does not bypass the actual map lookup/guard
# or specialise original method identities into fake static dispatch implementations.
def source_type(n,path,package):
 if not n:return None
 k=n['kind']
 if k=='Ident':return n['Name']if n['Name']in ['string','bool','int','error','any']else package+'::'+n['Name']
 if k=='SelectorExpr':
  prefix=F[path]['imports'].get(tx(n['X']));return prefix+'::'+tx(n['Sel'])if prefix else None
 if k=='StarExpr':
  typ=source_type(n['X'],path,package);return '*'+typ if typ else None
 if k=='ArrayType':
  typ=source_type(n['Elt'],path,package);return '[]'+typ if typ else None
 return None
REGISTRY=[];REGISTRY_CALLS=[];source_methods={m['key']:m for m in M['methods']}
for c in CALLS:
 if not re.match(r'(query|command)\.AddHandler\[',c['source'])or not c['arguments']:continue
 concrete=(VT.get(c['arguments'][0])or'').lstrip('*');targets=REC.get((concrete,'Handle'),[])
 if len(targets)!=1:continue
 handle=targets[0];decl=source_methods[handle['key']];assert len(decl['parameters'])==2
 kind=c['source'].split('.',1)[0];qtype=decl['parameters'][1]['type'];rtype=decl['results'][0]['type']if kind=='query'else None
 record={'kind':kind,'registrationOwner':c['owner'],'registrationOperation':c['operation'],'actualHandler':c['arguments'][0],'handlerSourceType':concrete,'genericRegistration':c['target'],'genericHandlerFormal':lookupmethod[c['target']]['parameters'][0],'keyQueryOrCommandType':qtype,'keyResultType':rtype,'handleImplementation':handle['implementation'],'handleFormals':handle['parameters'],'hosts':list(executions[c['owner']])};cid=add('claim','registry-registration/'+hash(c['operation']),owner=c['owner'],statement='Exact source registry registration/concrete Handle signature association: '+json.dumps(record)+'. Query key uses both Q and R, command key uses C. Original method identity/formals retained; imported Fx activation and mutable registry policy are not replaced with eager execution.',basis='source_declared',inputs=[c['operation'],record['actualHandler'],record['genericHandlerFormal'],handle['implementation'],*handle['parameters']],assumptions=[],evidence=R[c['operation']]['evidence']+[ev(handle['path'],handle['lines'])]);record['claim']=cid;REGISTRY.append(record)
for c in CALLS:
 if not re.match(r'(query\.Dispatch\[|command\.Dispatch\()',c['source']):continue
 kind=c['source'].split('.',1)[0];caller=lookupmethod[c['owner']];node=callnode(c);fun=node['Fun'];indices=fun.get('Indices')or([fun['Index']]if fun['kind']=='IndexExpr'else[])
 qtype=source_type(indices[0],c['path'],caller['package'])if indices else VT.get(c['arguments'][1])if len(c['arguments'])>1 else None
 rtype=source_type(indices[1],c['path'],caller['package'])if kind=='query'and len(indices)>1 else None
 matches=[]
 for host in executions[c['owner']]:
  selected=[r for r in REGISTRY if host in r['hosts']and r['kind']==kind and r['keyQueryOrCommandType']==qtype and(kind=='command'or r['keyResultType']==rtype)]
  for registration in selected:matches.append({'host':host,'registrationOperation':registration['registrationOperation'],'registrationClaim':registration['claim'],'handler':registration['handleImplementation'],'bindings':[{'formal':p,'actual':v}for p,v in zip(registration['handleFormals'],c['arguments'])]})
 detail={'operation':c['operation'],'source':c['source'],'kind':kind,'keyQueryOrCommandType':qtype,'keyResultType':rtype,'actuals':c['arguments'],'defaultSourceHostMatches':matches,'mechanicalLimit':'Actual Dispatch still performs reflect.TypeOf(key[Q,R]/key[C]) map lookup, missing-handler error and type assertion. Known source registration/callsite/signature correspondence is not automatic value-dispatch or runtime registry/heap proof.'};cid=add('claim','registry-call/'+hash(c['operation']),owner=c['owner'],statement='Exact source typed call→registry→local Handle correspondence: '+json.dumps(detail),basis='source_declared',inputs=[c['operation'],*c['arguments'],*[x for m in matches for x in [m['registrationOperation'],m['registrationClaim'],m['handler'],*[b['formal']for b in m['bindings']]]]],assumptions=['Default source host/profile only; supplied Fx options/registry mutation/runtime observation unresolved.'],evidence=R[c['operation']]['evidence']+anchor('internal/service/'+kind+'/dispatcher.go'));detail['claim']=cid;detail['owner']=c['owner'];REGISTRY_CALLS.append(detail)
(D/'typed-registry-ledger.json').write_text(json.dumps({'registrations':REGISTRY,'calls':REGISTRY_CALLS},indent=2)+'\n')
