"""Reviewed source Fx.As declarations by host; no global short-interface guessing."""
tx=lambda n:(n or {}).get('text','')
BASE='cce-optimization-facade/internal/'
DI_ROWS=[];HOST_DI={};alltargets=collections.defaultdict(set)
for host,path in [('api','internal/app/app.go'),('event','internal/app/appevent.go'),('marketmapping','internal/app/appmarketmapping.go')]:
 bindings={}
 for n in walknode(F[path]['ast']):
  if n.get('kind')!='CallExpr' or tx(n['Fun'])!='fx.Annotate':continue
  args=n.get('Args',[])
  if not args:continue
  constructor=args[0];name=tx(constructor);target=None;returns=[]
  if constructor['kind']=='FuncLit':
   target=B[path+':'+str(constructor['start'])];returns=[r['type']for r in target['results']]
  elif constructor['kind']=='SelectorExpr':
   pkg=F[path]['imports'].get(tx(constructor['X']));c=FUN.get((pkg,tx(constructor['Sel'])),[])
   if len(c)==1:target=c[0];returns=[r['type']for r in target['results']]
  elif constructor['kind']=='Ident':
   c=FUN.get(('cce-optimization-facade/internal/app',name),[])
   if len(c)==1:target=c[0];returns=[r['type']for r in target['results']]
  for annotation in args[1:]:
   if annotation.get('kind')!='CallExpr' or tx(annotation['Fun'])!='fx.As':continue
   for a in annotation.get('Args',[]):
    if a.get('kind')!='CallExpr' or tx(a['Fun'])!='new':continue
    operand=a['Args'][0];q=tx(operand)
    if operand['kind']=='SelectorExpr':q=F[path]['imports'][tx(operand['X'])]+'::'+tx(operand['Sel'])
    elif operand['kind']=='Ident':q='cce-optimization-facade/internal/app::'+q
    concrete=returns[0].lstrip('*') if returns else None
    row={'host':host,'path':path,'lines':n['lines'],'constructor':name,'implementation':target['implementation']if target else None,'interface':q,'concrete':concrete,'returnedTypes':returns};DI_ROWS.append(row)
    if concrete:bindings.setdefault(q,set()).add(concrete);alltargets[q].add(concrete)
 HOST_DI[host]={k:next(iter(v))for k,v in bindings.items()if len(v)==1}
DI={k:next(iter(v))for k,v in alltargets.items()if len(v)==1};DI_FIELDS={}
(D/'di-binding-ledger.json').write_text(json.dumps({'perHost':DI_ROWS,'hostInvariantBindings':DI,'varyingInterfaces':{k:sorted(v)for k,v in alltargets.items()if len(v)>1}},indent=2)+'\n')

# Exact local constructor paths independently read: NewGrpcClient -> generated constructor returns
# &carConfigurationServiceClient{cc}; NewClientWithResponses -> NewClient -> &ClientWithResponses{client}.
# These are default source construction associations, not a host-global short-name fallback.
CONSTRUCTOR_DI={BASE+'messaging/contracts::CarConfigurationServiceClient':BASE+'messaging/contracts::carConfigurationServiceClient',BASE+'gateway/carspecadapter::ClientInterface':BASE+'gateway/carspecadapter::Client'}
DI.update(CONSTRUCTOR_DI)
# Source constructor field associations, independently checked against actual assignments.
# They take precedence over host-level interfaces: cached wrappers must not call themselves.
DI_FIELDS.update({
 (BASE+'gateway/carspecadapter::Client','Client'):BASE+'gateway::HTTPClient',
 (BASE+'gateway/filterservice::CachedClient','client'):BASE+'gateway/filterservice::Client',
 (BASE+'gateway/cchconfiguration::CachedClient','client'):BASE+'gateway/cchconfiguration::Client',
 (BASE+'gateway/optimizationapi::CachedClient','client'):BASE+'gateway/optimizationapi::WrappedClient',
 (BASE+'gateway/carspecadapter::CachedLocalEditionsFetcher','client'):BASE+'gateway/carspecadapter::LocalEditionFetcher',
})
for owner in ['gateway/filterservice::CachedClient','gateway/cchconfiguration::CachedClient','gateway/optimizationapi::CachedClient','gateway/carspecadapter::CachedLocalEditionsFetcher','backend::CachedGraphqlClient']:
 DI_FIELDS[(BASE+owner,'cache')]=BASE+'caching::prefixedCache'
CONSTRUCTOR_DI[BASE+'domain::RulesetReplacement']=BASE+'database/postgres::RulesetReplacement'
DI.update(CONSTRUCTOR_DI)
(D/'constructor-binding-ledger.json').write_text(json.dumps({'interfaces':CONSTRUCTOR_DI,'fields':[{'owner':owner,'field':field,'concrete':concrete}for(owner,field),concrete in DI_FIELDS.items()],'scope':'Exact default source constructor assignments/returned concrete objects, not unique short-name coincidence, frozen mutable field values or deployed/runtime replacement proof.'},indent=2)+'\n')
