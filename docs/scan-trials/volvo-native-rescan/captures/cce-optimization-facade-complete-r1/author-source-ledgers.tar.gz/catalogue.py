"""Three source Fx hosts, source registrations and exact catalogue associations."""
S=Path('/tmp/cce-optimization-facade-pinned');BASE='cce-optimization-facade/internal/'
def pinned(path):return (S/path).read_text()
def anchor(path):return [ev(path,[1,len(pinned(path).splitlines())])]
def method(path,name):
 matches=[m for m in methods if m['path']==path and m['name']==name];assert len(matches)==1,(path,name,len(matches));return matches[0]
app_e=sum((anchor('internal/app/'+p)for p in ['app.go','appevent.go','appmarketmapping.go']),[]);cfg_e=anchor('internal/app/config.go');route_e=anchor('internal/api/httpserver/routes.go')
runtimegap=gap(source,'runtime','Source declarations versus activation','Pinned default Fx profiles are source declarations. Supplied options, deployed environment and imported lifecycle/transport/scheduling policy are not established.','Keep source configuration and runtime observations distinct.',app_e+cfg_e)
components={}
for k,label,cat,tech,paths in [
 ('api','CCE Optimization Facade','service','Go chi/Fx',['cmd/cce-optimization-facade/main.go','internal/app/app.go']),
 ('event','CCE Optimization Facade Event','service','Go chi/Fx/Watermill/River',['cmd/cce-optimization-facade-event/main.go','internal/app/appevent.go']),
 ('marketmapping','CCE Optimization Facade Market Mapping','service','Go chi/Fx',['cmd/cce-optimization-facade-market-mapping/main.go','internal/app/appmarketmapping.go']),
 ('postgres','Configured Facade PostgreSQL','store','PostgreSQL pgx',['internal/database/postgres/config.go']),
 ('riverdb','Configured River PostgreSQL','store','River PostgreSQL',['internal/database/queuedb/config.go']),
 ('redis','Configured Redis cache','store','go-redis cache',['internal/caching/redisCache.go']),
 ('optimization','Configured Optimization API','service','HTTP GraphQL',['internal/app/config.go']),
 ('optimization-background','Configured background Optimization API','service','HTTP GraphQL',['internal/app/config.go']),
 ('assortment','Configured Assortment API','service','HTTP OAuth',['internal/gateway/assortment/client.go']),
 ('filter','Configured Filter API','service','HTTP JSON',['internal/gateway/filterservice/client.go']),
 ('cch','Configured CCH Configuration API','service','HTTP JSON',['internal/gateway/cchconfiguration/client.go']),
 ('adapter','Configured Car Specification Adapter','service','HTTP OAuth',['internal/app/carspecadapter.go']),
 ('configurator','Configured CaaS Car Configurator','service','gRPC',['internal/app/grpc.go']),
 ('token','Configured OAuth token endpoint','service','HTTP form',['internal/gateway/tokensource.go']),
 ('jwks','Configured JWKS source','service','keyfunc',['internal/app/auth.go']),
 ('kafka','Configured Kafka transport','topic','Watermill/Sarama',['internal/app/kafka.go']),
 ('sentry','Configured Sentry purpose','service','sentry-go',['internal/app/sentry.go']),
 ('otlp','Configured OTLP telemetry purpose','service','OTLP/gRPC',['internal/observability/telemetry/providers.go']),
]:
 for p in paths:assert (S/p).exists(),p
 components[k]=add('runtime_component',k,logicalId='component:cce-optimization-facade:'+k,label=label,category=cat,technology=tech,sources=[source],basis='source_declared',gaps=[runtimegap],evidence=sum((anchor(p)for p in paths),[]))
# Hosts are source-compatible execution contexts. Exact Fx registrations/route bindings separately prove activation.
# A library is never a component. Distinct host-varying DI targets remain unresolved in shared source frames.
LOCAL_IMPORTS=collections.defaultdict(set)
for path,file in F.items():
 package='cce-optimization-facade/'+path.rsplit('/',1)[0]
 LOCAL_IMPORTS[package].update(i['Path']['text'].strip(chr(34))for i in file['ast'].get('Imports',[])if i['Path']['text'].strip(chr(34)).startswith('cce-optimization-facade/'))
IMPORT_CLOSURES={}
for host,package in [('api','cce-optimization-facade/cmd/cce-optimization-facade'),('event','cce-optimization-facade/cmd/cce-optimization-facade-event'),('marketmapping','cce-optimization-facade/cmd/cce-optimization-facade-market-mapping')]:
 reached=set();queue=[package]
 while queue:
  current=queue.pop()
  if current in reached:continue
  reached.add(current);queue.extend(LOCAL_IMPORTS[current]-reached)
 IMPORT_CLOSURES[host]=reached
(D/'package-initialisation-ledger.json').write_text(json.dumps({'imports':{k:sorted(v)for k,v in LOCAL_IMPORTS.items()},'hostImportClosures':{k:sorted(v)for k,v in IMPORT_CLOSURES.items()},'scope':'Go source package imports include every available production-named file in a package, independently of selected Fx constructors. Build/deployed profiles and imported module initializer bodies remain unresolved. Initializer method declarations retain distinct path/start identity.'},indent=2)+'\n')
executions={};host_rows=[]
for m in methods:
 p=m['path'];name=m['name'];hosts=[]
 if p.startswith('cmd/'):
  hosts=['event'if '-event/'in p else 'marketmapping'if '-market-mapping/'in p else 'api']
 elif p=='internal/app/app.go':hosts=['api']
 elif p=='internal/app/appevent.go':hosts=['event']
 elif p=='internal/app/appmarketmapping.go':hosts=['marketmapping']
 elif p.startswith(('internal/servicetest/','internal/fake/'))or p in ['internal/backend/optimization-api.go','internal/gateway/optimizationapi/generatedclient.go']:hosts=[]
 elif p=='internal/database/postgres/readycheck.go':hosts=['marketmapping']
 elif p.startswith('internal/gateway/assortment/'):hosts=['event']
 elif p.startswith('internal/gateway/cchconfiguration/'):hosts=['api']
 elif p=='internal/database/postgres/rulesetreplacer.go':hosts=['event']
 elif p.startswith('internal/messaging/contracts/'):hosts=['api','event']
 elif p.startswith(('internal/messaging/','internal/database/queuedb/')):hosts=['event']
 elif p.startswith('internal/api/httpserver/marketmapping/') or p.endswith('marketmappingroutes.go'):hosts=['marketmapping']
 elif p.endswith('eventroutes.go') or p.endswith('synccontroller.go'):hosts=['event']
 elif p.startswith(('internal/api/httpserver/components/','internal/api/httpserver/policy/','internal/facade/','internal/state/','internal/backend/')):hosts=['api','event'] if p.startswith('internal/backend/') else ['api']
 elif p.startswith('internal/service/command/'):hosts=['marketmapping']
 elif p.startswith('internal/service/query/'):hosts=['api','event','marketmapping']
 elif p.startswith(('internal/database/postgres/','internal/domain/','internal/observability/')):hosts=['api','event','marketmapping']
 else:hosts=['api','event']
 if name=='init':hosts=[host for host,packages in IMPORT_CLOSURES.items()if m['package']in packages]
 executions[m['implementation']]={}
 for host in hosts:executions[m['implementation']][host]=add('execution_binding',hash(m['key'])+'/'+host,implementation=m['implementation'],component=components[host],basis='source_declared',artifactBinding=None,gaps=[runtimegap],evidence=[ev(p,m['lines'])])
 host_rows.append({'implementation':m['implementation'],'path':p,'name':name,'hosts':hosts,'scope':'Source-compatible execution context only; exact Fx default registration/entry association is separate. No deployed activation or whole-package execution inferred.'})
(D/'host-binding-ledger.json').write_text(json.dumps(host_rows,indent=2)+'\n')
for row in DI_ROWS:add('claim','di/'+hash(json.dumps(row,sort_keys=True)),owner=source,statement='Exact per-host Fx.As registration: '+json.dumps(row)+'. Supplied Fx options and imported activation remain separate; host-varying interfaces are not globally merged.',basis='source_declared',inputs=[source,components[row['host']],*([row['implementation']]if row['implementation']else [])],assumptions=[],evidence=[ev(row['path'],row['lines'])])
exec((D/'wire-schemas.py').read_text(),globals())
def expose(key,m,host,trigger,protocol,verb,path,e,request=None,responses=None):
 if host not in executions[m['implementation']]:executions[m['implementation']][host]=add('execution_binding',hash(m.get('key',m['implementation']))+'/'+host,implementation=m['implementation'],component=components[host],basis='source_declared',artifactBinding=None,gaps=[runtimegap],evidence=e)
 entry=add('entry',key,logicalId='entry:cce-optimization-facade:'+host+':'+protocol+':'+verb+':'+path,trigger=trigger,method=verb,path=path,implementation=m['implementation'],evidence=e)
 contract=add('interface_contract',key,component=components[host],protocol=protocol,name=key,method=verb,path=path,authority='source_declared',request=request or [],responses=responses or [],gaps=[runtimegap],evidence=e)
 add('entry_binding',key,entry=entry,execution=executions[m['implementation']][host],contract=contract,gaps=[runtimegap],evidence=e);return {'entry':entry,'contract':contract,'implementation':m['implementation'],'host':host,'path':path,'method':verb}
rest_rows=[]
# Read actual nested chi route registrations; child router lambda is registration, never an eager handler invocation.
for host,path in [('api','internal/api/httpserver/routes.go'),('event','internal/api/httpserver/eventroutes.go'),('marketmapping','internal/api/httpserver/marketmappingroutes.go')]:
 if path not in F:
  candidates=[p for p in F if 'route'in p.lower()];raise AssertionError((path,candidates))
 root=method(path,'AddRoutes');node=nodes[root['key']];routerprefix={};calls=[]
 def registrations(n,prefix=''):
  if not isinstance(n,dict):
   if isinstance(n,list):
    for v in n:registrations(v,prefix)
   return
  if n.get('kind')=='CallExpr'and n['Fun']['kind']=='SelectorExpr':
   verb=tx(n['Fun']['Sel']);args=n.get('Args',[])
   if verb=='Route'and len(args)==2 and args[0]['kind']=='BasicLit'and args[1]['kind']=='FuncLit':
    segment=json.loads(args[0]['Value']);registrations(args[1]['Body'],(prefix.rstrip('/')+'/'+segment.lstrip('/')).rstrip('/'));return
   if verb in ['Get','Post','Put','Delete','Patch','Handle','HandleFunc']and len(args)>=2 and args[0]['kind']=='BasicLit':
    segment=json.loads(args[0]['Value']);full=prefix.rstrip('/')+'/'+segment.lstrip('/');calls.append((n,verb.upper(),full,args[1]));return
  for k,v in n.items():
   if k!='text':registrations(v,prefix)
 registrations(node['Body'])
 for i,(n,verb,full,handler)in enumerate(calls):
  expression=tx(handler);factory=handler['kind']=='CallExpr';fun=handler['Fun']if factory else handler;candidates=[]
  if fun['kind']=='SelectorExpr':
   name=tx(fun['Sel']);receiver=tx(fun['X']);field=receiver.split('.')[-1];typ=M['types'].get((root['receiver']['type'] or '').lstrip('*'))
   if typ:
    f=next((f for f in typ['fields']if f['name']==field),None)
    if f:candidates=REC.get(((f['type']or'').lstrip('*'),name),[])
  if not candidates:
   candidates=[m for m in methods if m['name']==tx(fun.get('Sel'))and m['path'].startswith('internal/')]
  if len(candidates)!=1:
   add('claim','route-unresolved/'+host+'/'+str(i),owner=source,statement='Actual source route '+verb+' '+full+' handler '+expression+' remains imported/unresolved declaration; no fake ordinary framework call.',basis='source_declared',inputs=[source,components[host]],assumptions=[],evidence=[ev(path,n['lines'])]);rest_rows.append({'host':host,'path':full,'method':verb,'handlerSource':expression,'status':'imported/unresolved','evidence':ev(path,n['lines'])});continue
  target=candidates[0];factorymethod=target
  if factory:
   lambdas=[m for m in methods if m['path']==target['path']and m['name'].startswith('<lambda')and target['lines'][0]<=m['lines'][0]<=target['lines'][1]]
   # Returned closure is last top-level return expression, not goroutine/comparison callback.
   returns=[x for x in walknode(nodes[target['key']]['Body'])if x.get('kind')=='ReturnStmt'and any(y.get('kind')=='FuncLit'for y in x.get('Results',[]))]
   returnlambdas=[B[target['path']+':'+str(y['start'])]for r in returns for y in r['Results']if y.get('kind')=='FuncLit']
   if len(returnlambdas)==1:target=returnlambdas[0]
   elif target['path']=='internal/facade/api.go':
    adapter=method(target['path'],'httpHandlerAdapterForPolytopeBasedBackend');returnlambdas=[B[adapter['path']+':'+str(y['start'])]for r in walknode(nodes[adapter['key']]['Body'])if r.get('kind')=='ReturnStmt'for y in r.get('Results',[])if y.get('kind')=='FuncLit'];assert len(returnlambdas)==1;target=returnlambdas[0]
   else:raise AssertionError(('route factory target',expression,target['name'],len(returnlambdas)))
  e=[ev(path,n['lines']),ev(target['path'],target['lines'])];key='rest/'+host+'/'+str(i);request=[part('body',None,None,presence='unresolved',content=None,gaps=[runtimegap],e=e)];row=expose(key,target,host,'rest','http',verb,full,e,request,[]);row.update(handlerSource=expression,factoryImplementation=factorymethod['implementation']if factory else None,status='source-bound')
  gs=gap(target['implementation'],'route-context/'+host+'/'+str(i),'Framework handler context and middleware projection','Source route binds this handler/returned closure. Enclosing receiver/business-model capture, HTTP request decoding, source response construction and middleware are retained in actual frames/associations; imported router invocation and automatic cross-capture/heap context are not inferred.','Use exact route/factory/source value claims; do not equate factory invocation with handler execution.',e)
  add('claim','route/'+host+'/'+str(i),owner=target['implementation'],statement='Exact source route/handler association: '+json.dumps(row)+'. Common JWT on main and market mapping; event route chain has no JWT. Route-specific permission/error/pagination policies remain actual source bodies, not universal synthetic filter calls.',basis='source_declared',inputs=[row['entry'],row['contract'],factorymethod['implementation'],target['implementation'],gs],assumptions=[],evidence=e);rest_rows.append(row)
for host,path in [('api','cmd/cce-optimization-facade/main.go'),('event','cmd/cce-optimization-facade-event/main.go'),('marketmapping','cmd/cce-optimization-facade-market-mapping/main.go')]:expose('process/'+host,method(path,'main'),host,'process','process','PROCESS',path+'#main',anchor(path))
(D/'rest-registration-ledger.json').write_text(json.dumps(rest_rows,indent=2)+'\n')
