"""Offline syntax/signature projection. Binding candidates require source review before acceptance."""
import json,posixpath,collections
from pathlib import Path
D=Path(__file__).resolve().parent;AST=json.loads((D/'source-ast.json').read_text());MODULE='cce-optimization-facade/'
def text(n):return (n or {}).get('text','')
def walk(n,kind=None):
 if isinstance(n,dict):
  if kind is None or n.get('kind')==kind:yield n
  for k,v in n.items():
   if k!='text':yield from walk(v,kind)
 elif isinstance(n,list):
  for v in n:yield from walk(v,kind)
files={f['path']:f for f in AST['files']};types={};methods=[];funcs={};byrecv={}
for p,f in files.items():
 f['package']=MODULE+posixpath.dirname(p);f['imports']={}
 for imp in f['ast'].get('Imports',[]):
  path=text(imp.get('Path')).strip('"');alias=(imp.get('Name') or {}).get('Name') or path.split('/')[-1]
  if alias not in ['_','.']:f['imports'][alias]=path
 def qualify(n):
  if not n:return None
  k=n['kind']
  if k=='Ident':return n['Name'] if n['Name'] in ['bool','string','int','int8','int16','int32','int64','uint','uint8','uint16','uint32','uint64','byte','rune','any','error','float32','float64','uintptr','complex64','complex128'] else f['package']+'::'+n['Name']
  if k=='SelectorExpr':return f['imports'].get(text(n['X']),text(n['X']))+'::'+text(n['Sel'])
  if k=='StarExpr':return '*'+str(qualify(n['X']))
  if k=='ArrayType':return ('['+text(n.get('Len'))+']')+str(qualify(n['Elt']))
  if k=='MapType':return 'map['+str(qualify(n['Key']))+']'+str(qualify(n['Value']))
  if k=='Ellipsis':return '...'+str(qualify(n['Elt']))
  if k in ['IndexExpr','IndexListExpr']:return text(n) # Generic substitution not inferred from text.
  return text(n)
 f['qualify']=qualify # Used only within this first pass; closures are not persisted.
 # Bind qualifier values now, avoiding later loop-variable closure capture.
 def fields(n):
  out=[]
  for field in (n or {}).get('List',[]):
   names=[x['Name'] for x in field.get('Names',[])] or [None]
   out.extend({'name':name,'type':qualify(field.get('Type')),'sourceType':text(field.get('Type')),'lines':field['lines'],'tag':text(field.get('Tag'))} for name in names)
  return out
 for n in walk(f['ast'],'TypeSpec'):
  enclosing=[a for a in walk(f['ast'],'FuncDecl') if a['start']<n['start']<a['end']]
  key=f['package']+'::'+n['Name']['Name']+('@'+p+':'+str(n['start']) if enclosing else '');typ=n['Type']
  assert key not in types,('Unequal source type identity collision',key)
  types[key]={'key':key,'name':n['Name']['Name'],'package':f['package'],'path':p,'lines':n['lines'],'kind':typ['kind'],'source':text(typ),'fields':fields(typ.get('Fields')) if typ['kind']=='StructType' else [],'alias':qualify(typ) if typ['kind'] not in ['StructType','InterfaceType'] else None}
 for n in walk(f['ast']):
  if n.get('kind') not in ['FuncDecl','FuncLit']:continue
  name=(n.get('Name') or {}).get('Name') or '<lambda@'+str(n['start'])+'>';recv=fields(n.get('Recv'));params=fields(n['Type'].get('Params'));results=fields(n['Type'].get('Results'));key=p+':'+str(n['start'])
  m={'key':key,'name':name,'path':p,'package':f['package'],'lines':n['lines'],'receiver':recv[0] if recv else None,'parameters':params,'results':results,'returnKind':'value' if results else 'void','node':n,'generated':p.endswith('.pb.go'),'calls':[]};methods.append(m)
  if n['kind']=='FuncDecl':
   if recv:byrecv.setdefault((recv[0]['type'].lstrip('*'),name),[]).append(m)
   else:funcs.setdefault((f['package'],name),[]).append(m)
# This is deliberately not a recovered compiler type checker. Unknowns stay unknown.
for m in methods:
 f=files[m['path']];env={x['name']:x['type'] for x in m['parameters']+m['results'] if x['name']};
 if m['receiver'] and m['receiver']['name']:env[m['receiver']['name']]=m['receiver']['type']
 def typename(n):
  if not n:return None
  k=n['kind'];s=text(n)
  if k=='Ident':
   return env.get(n['Name']) or (n['Name'] if n['Name'] in ['string','bool','int','int32','int64','uint32','uint64','byte','error','float64','any'] else f['package']+'::'+n['Name'] if f['package']+'::'+n['Name'] in types else None)
  if k=='SelectorExpr' and text(n['X']) in f['imports']:return f['imports'][text(n['X'])]+'::'+text(n['Sel'])
  if k=='StarExpr':return '*'+str(typename(n['X']))
  if k=='ArrayType':return '[]'+str(typename(n['Elt']))
  return None
 def infer(n):
  if not n:return [None]
  k=n['kind']
  if k=='Ident':return [env.get(n['Name'])]
  if k=='BasicLit':return [{'STRING':'string','INT':'untyped-int','FLOAT':'untyped-float','CHAR':'untyped-rune'}.get(n.get('Kind'))]
  if k in ['ParenExpr','StarExpr','UnaryExpr']:
   t=infer(n['X'])[0]
   if k=='StarExpr':return [t[1:] if t and t.startswith('*') else None]
   if n.get('Op')=='&':return ['*'+t if t else None]
   return [t]
  if k=='CompositeLit':return [typename(n.get('Type'))]
  if k=='SelectorExpr':
   typ=(infer(n['X'])[0] or '').lstrip('*');decl=types.get(typ)
   if decl:
    field=next((x for x in decl['fields'] if x['name']==text(n['Sel'])),None)
    if field:return [field['type']]
   return [None]
  if k in ['IndexExpr','SliceExpr']:
   typ=infer(n['X'])[0]
   if typ and typ.startswith('[]'):return [typ if k=='SliceExpr' else typ[2:]]
   return [None]
  if k=='TypeAssertExpr':return [typename(n.get('Type')),'bool']
  if k=='CallExpr':
   fun=n['Fun'];candidates=[];receiver=None
   if fun['kind']=='Ident':candidates=funcs.get((m['package'],fun['Name']),[])
   elif fun['kind']=='SelectorExpr':
    x=fun['X'];name=text(fun['Sel'])
    if text(x) in f['imports']:candidates=funcs.get((f['imports'][text(x)],name),[])
    else:
     receiver=infer(x)[0];candidates=byrecv.get(((receiver or '').lstrip('*'),name),[])
   args=[infer(x)[0] for x in n.get('Args',[])];target=candidates[0] if len(candidates)==1 else None
   if target:
    count=len(target['parameters']);variadic=bool(count and target['parameters'][-1]['type'].startswith('...'))
    if not (len(args)==count or variadic and len(args)>=count-1):target=None
   row={'path':m['path'],'caller':m['key'],'start':n['start'],'lines':n['lines'],'source':text(n),'calleeExpression':text(fun),'receiverType':receiver,'arguments':[{'source':text(x),'inferredType':t} for x,t in zip(n.get('Args',[]),args)],'signatureCandidate':target['key'] if target else None,'candidateReturnTypes':[x['type'] for x in target['results']] if target else [],'status':'source-signature candidate; receiver/DI/argument review required' if target else 'unresolved signature; available local body search required before external classification'}
   m['calls'].append(row)
   if target:return [x['type'] for x in target['results']] or [None]
   if fun['kind']=='Ident' and fun['Name'] in ['make','new']:
    t=typename((n.get('Args') or [None])[0]);return ['*'+t if fun['Name']=='new' and t else t]
   return [None]
  return [None]
 def visit(n):
  if not isinstance(n,dict):return
  k=n.get('kind')
  if k=='FuncLit':return # Its own lexical environment/captures must be analysed separately.
  if k=='AssignStmt':
   values=[]
   for x in n.get('Rhs',[]):values.extend(infer(x))
   for lhs,t in zip(n.get('Lhs',[]),values):
    if lhs['kind']=='Ident' and lhs['Name']!='_':env[lhs['Name']]=t
   return
  if k=='CallExpr':infer(n);return
  if k=='ValueSpec':
   ts=[infer(x)[0] for x in n.get('Values',[])];declared=typename(n.get('Type'))
   for i,x in enumerate(n.get('Names',[])):env[x['Name']]=declared or (ts[i] if i<len(ts) else None)
   return
  if k in ['IfStmt','SwitchStmt','TypeSwitchStmt','ForStmt','RangeStmt']:
   # No branch-derived type may leak to another branch. This projection is not SSA.
   original=env.copy()
   for key,v in n.items():
    if isinstance(v,dict):visit(v)
    elif isinstance(v,list):
     for item in v:visit(item)
    if key in ['Body','Else','List']:env.clear();env.update(original)
   env.clear();env.update(original);return
  for key,v in n.items():
   if isinstance(v,dict):visit(v)
   elif isinstance(v,list):
    for item in v:visit(item)
 visit(m['node'].get('Body'))
 # Duplicate evaluation can occur when a nested result is needed more than once. Keep exact callsite once.
 m['calls']=list({r['start']:r for r in m['calls']}.values())
public=[{k:v for k,v in m.items() if k!='node'} for m in methods]
(D/'source-symbols.json').write_text(json.dumps({'types':types,'methods':public,'qualification':'source syntax signature candidates only, not accepted runtime dispatch'},indent=2)+'\n')
print('Types',len(types),'methods',len(methods),'calls',sum(len(m['calls']) for m in methods),'signature candidates',sum(bool(c['signatureCandidate']) for m in methods for c in m['calls']))
