"""Record completed source reads; never mark inventory/candidate counts as review."""
import json,sys,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;item=json.load(sys.stdin);notes=json.loads((D/'review-notes.json').read_text());fingerprint=hashlib.sha256(json.dumps(item,sort_keys=True).encode()).hexdigest();item['reviewFingerprint']=fingerprint
if not any(n.get('reviewFingerprint')==fingerprint for n in notes):notes.append(item)
(D/'review-notes.json').write_text(json.dumps(notes,indent=2)+'\n');ledger=json.loads((D/'source-review-ledger.json').read_text());known={f['path']for f in ledger['files']};assert all(p in known for p in item['paths'])
for f in ledger['files']:
 if f['path']in item['paths']:f['status']='body-reviewed'
(D/'source-review-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print('Recorded source group',len(item['paths']),'total reviewed',sum(f['status']=='body-reviewed'for f in ledger['files']))
