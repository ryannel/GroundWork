"""Mutable native working capture. Never select until HANDOFF/acceptance seal exists."""
import json,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;P='cce-optimization-facade-8da8ebe-complete-r1/';PIN='8da8ebe3227a43817bbbca25fdec182edfaa6584';REPO='volvo-cars/cce-optimization-facade';M=json.loads((D/'source-symbols.json').read_text());R={}
def hash(x):return hashlib.sha256(x.encode()).hexdigest()[:16]
def add(kind,key,**kw):
 rec={'id':P+kind+'/'+key,'kind':kind,**kw};old=R.get(rec['id'])
 if old is not None:assert old==rec,('Unequal/cross-kind ID collision',old,rec)
 else:R[rec['id']]=rec
 return rec['id']
def ev(path,lines):return add('evidence',hash(path+str(lines)),host='github.com',repo=REPO,commit=PIN,path=path,lines=lines,basis='source')
source=add('source_revision','source',repo=REPO,commit=PIN)
def gap(owner,key,obligation,reason,action,evidence):return add('gap',key,owner=owner,obligation=obligation,reason=reason,action=action,evidence=evidence)
shapeids={k:P+'shape/'+hash(k) for k in M['types']}
for key,t in M['types'].items():
 evidence=[ev(t['path'],t['lines'])];sid=shapeids[key];fs=[]
 for i,f in enumerate(t['fields']):
  typ=f['type'] or f['sourceType'];name=f['name'] or '<embedded:'+f['sourceType']+'>';row={'name':name,'type':typ,'status':'declared','nullable':typ.startswith('*') or typ.startswith('[]') or typ.startswith('map['),'evidence':[ev(t['path'],f['lines'])]}
  ref=shapeids.get(typ.lstrip('*'))
  if ref:row['shape']=ref
  fs.append(row)
 special=t['kind'] not in ['StructType'];gs=[]
 if special:gs=[gap(sid,'type/'+hash(key),'Source declaration representation',f"Exact {t['kind']} declaration retained; callable/alias/container projection pending: {t['source']}",'Complete source alias/container/method schema projection before acceptance.',evidence)]
 add('shape',hash(key),representation='source',label=key,fields=fs,completeness='partial' if special else 'closed',gaps=gs,evidence=evidence)
 for i,f in enumerate(t['fields']):
  if f['tag']:add('claim','tag/'+hash(key+str(i)),owner=sid,statement='Exact Go source struct tag on '+str(f['name'])+': '+f['tag']+'. Source field identity and tagged encoding are distinct.',basis='source_declared',inputs=[sid],assumptions=[],evidence=[ev(t['path'],f['lines'])])
methods=[]
for m in M['methods']:
 key=hash(m['key']);iid=P+'implementation/'+key;entry=P+'operation/'+key+'/entry';evidence=[ev(m['path'],m['lines'])];params=[]
 for i,p in enumerate(m['parameters']):
  ref=shapeids.get((p['type'] or '').lstrip('*'));params.append(add('value',key+'/p/'+str(i),owner=iid,definition=entry,label=(p['name'] or '<unnamed-'+str(i)+'>')+' '+str(p['type']),role='parameter',representation='source',shape=ref,evidence=[ev(m['path'],p['lines'])],accessPath=[]))
 attrs={}
 if m['receiver']:
  p=m['receiver'];attrs['receiver']=add('value',key+'/receiver',owner=iid,definition=entry,label=(p['name'] or '<unnamed receiver>')+' '+p['type'],role='receiver',representation='source',shape=shapeids.get(p['type'].lstrip('*')),evidence=[ev(m['path'],p['lines'])],accessPath=[])
 add('implementation',key,logicalId='impl:cce-optimization-facade:'+m['path']+':'+str((m['receiver'] or {}).get('type',''))+'.'+m['name']+'('+','.join(str(x['type']) for x in m['parameters'])+')',scope=source,entry=entry,parameters=params,returnKind=m['returnKind'],evidence=evidence,**attrs)
 add('operation',key+'/entry',owner=iid,action='entry',label=m['package']+'.'+m['name'],resolution=None,bindings=[],result=None,exit=None,httpStatus=None,evidence=evidence)
 g=gap(iid,'pending-body/'+key,'Working native transcription','Actual source frame and genuine signature retained. Control/value transcription and reviewed call binding are pending in this mutable working capture.','Finish source review and native expansion; do not publish this checkpoint.',evidence)
 add('coverage',key,owner=iid,obligation='Native source execution expansion',status='partial',scope='Working source-signature checkpoint only. No claim that entry-only frame captures body behaviour.',gaps=[g],evidence=evidence)
 methods.append({**m,'implementation':iid,'entry':entry,'parameters':params,'nativeReceiver':attrs.get('receiver')})
exec((D/'go-execution.py').read_text(),globals())
expand_working()
exec((D/'source-schemas.py').read_text(),globals())
exec((D/'catalogue.py').read_text(),globals())
exec((D/'io-catalogue.py').read_text(),globals())
exec((D/'associations.py').read_text(),globals())
exec((D/'channels.py').read_text(),globals())
exec((D/'contracts.py').read_text(),globals())
(D/'native-method-ledger.json').write_text(json.dumps(methods,indent=2)+'\n')
(D/'working.bundle.json').write_text(json.dumps({'format':'groundwork-knowledge/v3','workspace':'volvo-cars','records':list(R.values())},indent=2)+'\n')
print('Working declaration records',len(R),'not publication candidate')
