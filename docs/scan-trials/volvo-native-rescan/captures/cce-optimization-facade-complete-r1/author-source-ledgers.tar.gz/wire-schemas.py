# Tagged JSON declarations: own source shapes remain separate from this wire-intent projection.
json_shapes={k:P+'shape/json/'+hash(k) for k,t in M['types'].items() if t['kind']=='StructType'}
def jsonshape(typ,e):
 typ=(typ or '').lstrip('*')
 if typ in json_shapes:return json_shapes[typ]
 if typ.startswith('[]'):
  item=jsonshape(typ[2:],e);return add('shape','json-array/'+hash(typ+str(e)),representation='wire',label='Declared JSON array '+typ,encoding='json',container='array',items=item,fields=[],completeness='closed',gaps=[],evidence=e)
 if typ in ['string','bool','int','int32','int64','uint32','uint64','float32','float64','byte']:
  return add('shape','json-scalar/'+hash(typ+str(e)),representation='wire',label='Declared JSON scalar '+typ,encoding='json',wireType=typ,fields=[],completeness='closed',gaps=[],evidence=e)
 if typ in M['types'] and M['types'][typ].get('alias'):return jsonshape(M['types'][typ]['alias'],e)
 sid=P+'shape/json-external/'+hash(typ+str(e));g=gap(sid,'json-external/'+hash(typ+str(e)),'JSON declaration expansion','Source field uses imported/generic/map type '+typ+'; exact effective fields/codec are not expanded.','Retain source type; inspect exact available dependency/constructed context.',e)
 return add('shape','json-external/'+hash(typ+str(e)),representation='wire',label='Partial JSON declaration '+typ,encoding='json',fields=[],completeness='partial',gaps=[g],evidence=e)
for key,sid in json_shapes.items():
 t=M['types'][key];e=[ev(t['path'],t['lines'])];fs=[];gs=[]
 for f in t['fields']:
  if f['name'] is None:
   g=gap(sid,'json-embedded/'+hash(key+str(f['lines'])),'Embedded JSON declaration','Embedded '+str(f['type'])+' field flattening/conflict or imported codec not mechanically expanded here; source declaration retained.','Use exact source embedding and serializer before complete wire closure.',[ev(t['path'],f['lines'])]);gs.append(g);continue
  if not f['name'][0].isupper():continue
  tag=re.search(r'json:"([^"]*)"',f['tag'] or '');parts=tag[1].split(',') if tag else [f['name']]
  if parts[0]=='-':continue
  field={'name':parts[0] or f['name'],'type':f['type'] or f['sourceType'],'status':'declared','nullable':(f['type'] or '').startswith(('*','[]','map[')),'shape':jsonshape(f['type'],[ev(t['path'],f['lines'])]),'evidence':[ev(t['path'],f['lines'])]}
  if 'omitempty' in parts:field['optional']=True
  fs.append(field)
 add('shape','json/'+hash(key),representation='wire',label='Declared JSON tags '+key,encoding='json',fields=fs,completeness='partial' if gs else 'closed',gaps=gs,evidence=e)
# Actual generated protobuf field tags; source .proto files are absent at pin.
proto_shapes={k:P+'shape/protobuf/'+hash(k) for k,t in M['types'].items() if t['path'].startswith('internal/messaging/contracts/') and any('protobuf:' in (f['tag'] or '') for f in t['fields'])}
for key,sid in proto_shapes.items():
 t=M['types'][key];fs=[];gs=[];e=[ev(t['path'],t['lines'])]
 for f in t['fields']:
  tag=re.search(r'protobuf:"([^"]+)"',f['tag'] or '')
  if not tag:continue
  parts=tag[1].split(',');name=next(x[5:] for x in parts if x.startswith('name='));typ=f['type'];field={'name':name,'type':typ,'wireTag':int(parts[1]),'status':'declared','nullable':typ.startswith(('*','[]')),'evidence':[ev(t['path'],f['lines'])]}
  if 'oneof' in parts:field['optional']=True
  ref=proto_shapes.get(typ.lstrip('*'))
  if typ.startswith('[]'):
   itemtype=typ[2:].lstrip('*');refitem=proto_shapes.get(itemtype)
   if not refitem:refitem=add('shape','protobuf-scalar/'+hash(itemtype+str(e)),representation='wire',label='Protobuf source scalar '+itemtype,encoding='protobuf',wireType=itemtype,fields=[],completeness='closed',gaps=[],evidence=e)
   ref=add('shape','protobuf-array/'+hash(key+name),representation='wire',label='Protobuf repeated '+name,encoding='protobuf',container='array',items=refitem,fields=[],completeness='closed',gaps=[],evidence=field['evidence'])
  if ref:field['shape']=ref
  elif typ.lstrip('*') not in ['string','int32','int64','bool','float32','float64','uint32','uint64']:
   g=gap(sid,'protobuf-import/'+hash(key+name),'Imported protobuf field','Generated field '+name+' refers to '+typ+' absent imported definition.','Resolve exact matching protobuf dependency schema; do not invent wrapper fields.',field['evidence']);gs.append(g)
  fs.append(field)
 add('shape','protobuf/'+hash(key),representation='wire',label='Generated protobuf declaration '+t['name'],encoding='protobuf',wireType=t['name'],fields=fs,completeness='partial' if gs else 'closed',gaps=gs,evidence=e)
(D/'protobuf-schema-ledger.json').write_text(json.dumps([{'sourceType':k,'sourceShape':shapeids[k],'protobufShape':v,'fields':R[v]['fields']} for k,v in proto_shapes.items()],indent=2)+'\n')
def part(kind,shape=None,sourceShape=None,presence='present',content='application/json',gaps=None,e=None):return {'part':kind,'presence':presence,'shape':shape,'sourceShape':sourceShape,'contentType':content,'gaps':gaps or [],'evidence':e or route_e}
