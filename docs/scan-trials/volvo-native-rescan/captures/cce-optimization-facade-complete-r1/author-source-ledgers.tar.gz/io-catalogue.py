"""Exact source I/O families with indexed caller values; imported codec/ack policy stays explicit."""
IO=[];WRITES=[];resources={};INITIALISATION=[]
def resource(key,component,label,technology='source-configured boundary',table=None,sourceEvidence=None):
 if key in resources:return resources[key]
 e=(sourceEvidence or [])+cfg_e+app_e;attrs={}
 if table:attrs['address']={'basis':'source_declared','connectionSetting':'DATABASE_HOST/DATABASE_PORT/DATABASE_NAME','database':None,'table':table,'container':None,'path':None,'key':None}
 rid=add('resource',key,label=label,technology=technology,declaredDatabase=None,physicalLocation=None,shapes=[],gaps=[runtimegap],evidence=e,**attrs);resources[key]=rid
 if component:add('resource_binding',key,resource=rid,component=components['event'if component=='memory'else component],**({'scope':'in_process'}if component=='memory'else{}),role='storage'if component in ['postgres','riverdb','redis']else 'transport'if component in ['kafka','memory']else 'remote_interface',gaps=[runtimegap],evidence=e)
 return rid
for key in ['postgres','riverdb','redis','optimization','optimization-background','assortment','filter','cch','adapter','configurator','token','jwks','kafka','memory','sentry','otlp']:resource(key,key,'Configured '+key)
resource('dynamic-http',None,'Reusable dynamic HTTP transport')
lookupmethod={m['implementation']:m for m in methods}
DECLARED_TABLES={name for file in S.glob('internal/database/postgres/migrations/*.sql')for name in re.findall(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)',file.read_text(),re.I)}
incoming=collections.defaultdict(list);constructed={}
for r in list(R.values()):
 if r['kind']=='flow':incoming[r['to']].append(r['from'])
 if r['kind']=='claim'and r['statement'].startswith('Exact source composite initializer: '):constructed[r['inputs'][1]]=json.loads(r['statement'].split('Exact source composite initializer: ',1)[1].split('. No imported wire',1)[0])
def items(v,seen=None):
 seen=set()if seen is None else seen
 if v in seen:return None
 seen.add(v)
 if v in constructed:return constructed[v]
 return items(incoming[v][0],seen)if len(incoming[v])==1 else None
def callnode(c):
 m=lookupmethod[c['owner']];matches=[n for n in walknode(nodes[m['key']])if n.get('kind')=='CallExpr'and n['text']==c['source']and n['lines']==c['lines']];return matches[0]if matches else None
def literal(expr,m,position,seen=None):
 seen=set()if seen is None else seen
 if not expr:return None
 if expr['kind']=='BasicLit'and expr.get('Kind')=='STRING':return expr['Value'][1:-1]if expr['Value'].startswith('`')else json.loads(expr['Value'])
 if expr['kind']=='BinaryExpr'and expr.get('Op')=='+':
  a,b=literal(expr['X'],m,position,seen.copy()),literal(expr['Y'],m,position,seen.copy());return a+b if a is not None and b is not None else None
 if expr['kind']=='Ident':
  name=expr['Name']
  if name in seen:return None
  seen.add(name);definitions=[]
  for n in walknode(nodes[m['key']]):
   if n.get('start',0)>=position:continue
   if n.get('kind')=='AssignStmt':
    for i,x in enumerate(n.get('Lhs',[])):
     if tx(x)==name and i<len(n.get('Rhs',[])):definitions.append((n['start'],n['Rhs'][i]))
   if n.get('kind')=='ValueSpec':
    for i,x in enumerate(n.get('Names',[])):
     if tx(x)==name and i<len(n.get('Values',[])):definitions.append((n['start'],n['Values'][i]))
  if definitions:return literal(max(definitions,key=lambda x:x[0])[1],m,position,seen)
  for d in F[m['path']]['ast'].get('Decls',[]):
   if d['kind']!='GenDecl':continue
   for spec in d.get('Specs',[]):
    if spec.get('kind')=='ValueSpec':
     for i,x in enumerate(spec.get('Names',[])):
      if tx(x)==name and i<len(spec.get('Values',[])):return literal(spec['Values'][i],m,position,seen)
 return None
def boundary(c,family,effecttype,protocol,meaning,hosts=None,targetOverride=None):
 key=hash(c['operation']+family);op=R[c['operation']];e=op['evidence'];owner=c['owner'];g=gap(owner,'io/'+key,'Imported boundary policy',meaning+' Exact imported transport/codec/active configuration and delivery/durability remain unresolved.','Use source call values; inspect exact runtime/dependency before stronger claims.',e);rows=[]
 signature=add('shape','caller-signature/'+key,representation='source',label='Indexed source invocation signature '+c['source'].split('(')[0]+' (not runtime/wire envelope)',fields=[{'name':'argument'+str(i),'type':VT.get(v)or'unresolved source expression type','status':'declared','evidence':e,**({'shape':source_shape(VT.get(v),e)}if VT.get(v)else{})}for i,v in enumerate(c['arguments'])],completeness='closed',gaps=[],evidence=e)
 for host,execution in executions[owner].items():
  if hosts and host not in hosts:continue
  actualfamily=family
  if family=='optimization'and host=='event':actualfamily='optimization-background'
  target=components.get('event'if actualfamily=='memory'else actualfamily)if targetOverride is None else targetOverride.get(host)
  rid=resource(actualfamily,actualfamily if actualfamily in components or actualfamily=='memory'else None,'Configured '+actualfamily)
  contract=add('interface_contract','caller/'+key+'/'+host,component=target,protocol=protocol,name=c['source'].split('(')[0],method=None,path=None,authority='caller_construction',request=[part('body',None,signature,presence='unresolved',content=None,gaps=[g],e=e)],responses=[],gaps=[g],evidence=e)
  effect=add('effect','io/'+key+'/'+host,owner=owner,operation=c['operation'],effect=effecttype,resource=rid,modality='source_traced',representation='logical',selection=c['arguments'][1:2]if protocol=='postgresql'else [],payload=c['arguments'],evidence=e)
  inter=add('interaction','io/'+key+'/'+host,owner=owner,execution=execution,operation=c['operation'],target=target,targetEntry=None,contract=contract,effect=effect,handoff=None,mode=effecttype if effecttype in ['read','write','publish']else'unknown'if actualfamily in ['postgres','riverdb']else'request_response',boundary='in_process'if actualfamily=='memory'else'unresolved',waitsFor='store_result'if actualfamily in ['postgres','riverdb','redis']else'producer_result'if effecttype=='publish'else'response',condition=meaning,requestBindings=[{'part':'selection','path':['argument'+str(i)],'value':v,'transform':'Exact indexed source invocation actual '+str(i)+'; source signature projection, no inferred wire placement.'}for i,v in enumerate(c['arguments'])],responseBindings=[{'part':'result','path':[],'value':c['result'],'transform':'Immediate Go return/error/tuple/handle only; out-pointer decoding, remote payload, commit and durability are distinct.'}]if c['result']else[],gaps=[g],evidence=e)
  row={**c,'host':host,'family':actualfamily,'interaction':inter,'effect':effect,'contract':contract,'resource':rid,'gap':g};IO.append(row);rows.append(row)
 add('claim','caller-context/'+key,owner=owner,statement='Exact source boundary operands: '+json.dumps({'callee':c['source'],'receiver':c['receiver'],'arguments':c['arguments'],'result':c['result']})+'. Indexed source signature is a declaration projection; no fabricated object/wire body or generic argument-to-result flow.',basis='source_declared',inputs=[c['operation'],signature,*c['arguments'],*([c['receiver']]if c['receiver']else[]),*[r['interaction']for r in rows]],assumptions=[],evidence=e)
 if not rows:
  add('claim','unhosted-boundary/'+key,owner=owner,statement='Available source boundary declaration has no established application host activation: '+meaning+' Exact source call/actual values retained; no extra runtime interaction or service edge is inferred.',basis='source_declared',inputs=[c['operation'],signature,*c['arguments'],g],assumptions=[],evidence=e)
 return rows
LIBRARIES=[]
def library_boundary(c,meaning):
 key=hash(c['operation']);e=R[c['operation']]['evidence'];g=gap(c['owner'],'library/'+key,'Imported SDK continuation/cache/refresh policy',meaning,'Keep source receiver/formals/actual values and registration associations; inspect exact imported policy before runtime transport claims.',e)
 for host,execution in executions[c['owner']].items():
  contract=add('interface_contract','library/'+key+'/'+host,component=None,protocol='source-library',name=c['source'].split('(')[0],method=None,path=None,authority='caller_construction',request=[],responses=[],gaps=[g],evidence=e)
  inter=add('interaction','library/'+key+'/'+host,owner=c['owner'],execution=execution,operation=c['operation'],target=None,targetEntry=None,contract=contract,effect=None,handoff=None,mode='unknown',boundary='unresolved',waitsFor='unknown',condition=meaning,requestBindings=[{'part':'selection','path':['argument'+str(i)],'value':v,'transform':'Actual SDK continuation argument; not a wire/body envelope or an established additional transport call.'}for i,v in enumerate(c['arguments'])],responseBindings=[{'part':'result','path':[],'value':c['result'],'transform':'Immediate SDK result only; cache/refresh/transport continuation policy unresolved.'}]if c['result']else[],gaps=[g],evidence=e);LIBRARIES.append({**c,'host':host,'interaction':inter,'contract':contract,'gap':g})
 add('claim','library/'+key,owner=c['owner'],statement=meaning+' Exact source receiver/arguments/result: '+json.dumps(c)+'. Constructor stores clientcredentials.Config.TokenSource(Background) using TokenURL/clientID/clientSecret/resource EndpointParams; Authorize reads AccessToken, appends authorization Bearer header, then calls the supplied UnaryInvoker. Captured config is not fabricated Token() formal arguments. No extra network service, per-token request, cached-value lineage or duplicate gRPC send is asserted.',basis='source_declared',inputs=[c['operation'],*c['arguments'],*([c['functionValue']]if c.get('functionValue')else[]),*([c['receiver']]if c['receiver']else[])],assumptions=[],evidence=e+anchor('internal/gateway/carconfigurator/auth.go'))
for c in CALLS:
 head=c['source'].split('(')[0];name=head.split('.')[-1];p=c['path'];key=hash(c['operation']);m=lookupmethod[c['owner']];node=callnode(c)
 if p=='internal/gateway/carconfigurator/auth.go'and head in ['a.tokenSource.Token','invoker']:library_boundary(c,'Actual imported OAuth token evaluation / supplied gRPC continuation inside Authorizer. SDK may use cached token or refresh configured endpoint; continuation transport/interceptor policy is unresolved.')
 elif p.startswith('internal/database/postgres/')and name in ['Query','QueryRow','Exec']and head.startswith(('r.pool.','tx.')):
  args=(node or{}).get('Args',[]);sql=literal(args[1],m,node['start'])if len(args)>1 else None;verb=re.match(r'\s*(\w+)',sql)[1].upper()if sql else None;action='write'if verb in ['INSERT','UPDATE','DELETE']or name=='Exec'else'read';rows=boundary(c,'postgres',action,'postgresql','Actual pgx '+name+' source SQL invocation; returned rows/command/error versus Scan and transaction commit are separate. SQL '+str(sql))
  if sql:
   tablematch=re.search(r'(?:INSERT\s+INTO|UPDATE|DELETE\s+FROM|FROM)\s+([A-Za-z_][A-Za-z0-9_]*)',sql,re.I)
   if tablematch:
    table=tablematch[1];rid=resource('postgres/table/'+table,'postgres','Declared SQL table '+table,'PostgreSQL table',table,R[c['operation']]['evidence'])
    for row in rows:R[row['effect']]['resource']=rid;row['resource']=rid
  values=c['arguments'][2:]
  if len(values)==1 and re.search(r'\.\.\.\s*\)$',c['source']):
   expanded=items(values[0]);values=[v for k,v in expanded]if expanded else values
  pairs=[]
  if sql:
   if verb=='INSERT':
    match=re.search(r'INSERT\s+INTO\s+\w+\s*\((.*?)\)\s*VALUES\s*\((.*?)\)',sql,re.I|re.S)
    if match:
     for col,expr in zip(match[1].split(','),match[2].split(',')):
      index=re.fullmatch(r'\s*\$(\d+)\s*',expr)
      if index and int(index[1])<=len(values):pairs.append((col.strip(),values[int(index[1])-1]))
   else:
    fieldsql=sql
    if verb=='UPDATE':
     setpart=re.search(r'\bSET\b(.*?)(?:\bWHERE\b|\bRETURNING\b|$)',sql,re.I|re.S);fieldsql=setpart[1]if setpart else ''
    pairs=[(col,values[int(i)-1])for col,i in re.findall(r'(\w+)\s*=\s*\$(\d+)',fieldsql)if int(i)<=len(values)]
  claim=add('claim','sql/'+key,owner=c['owner'],statement='Exact source SQL/positional arguments: '+json.dumps({'sql':sql,'sourceSQLExpression':tx(args[1])if len(args)>1 else None,'arguments':c['arguments'],'expandedSourceSliceValues':values,'columnValues':pairs})+'. Dynamic builder/placeholder context stays explicit; no wider atomicity or successful write is inferred from normal Go return.',basis='source_declared',inputs=[c['operation'],*c['arguments'],*values],assumptions=[],evidence=R[c['operation']]['evidence'])
  selectionsql=sql.split('WHERE',1)[1]if sql and 'WHERE'in sql.upper()and 'WHERE'in sql else ''
  selection=[values[int(i)-1]for i in dict.fromkeys(re.findall(r'\$(\d+)',selectionsql))if int(i)<=len(values)]
  if sql and 'ON CONFLICT'in sql.upper():
   conflict=re.search(r'ON\s+CONFLICT\s*\((.*?)\)',sql,re.I|re.S);insertfields=dict(pairs)
   if conflict:selection=[insertfields[n.strip()]for n in conflict[1].split(',')if n.strip()in insertfields]
  for row in rows:
   R[row['effect']]['selection']=selection;R[row['effect']]['payload']=[v for col,v in pairs]if action=='write'else []
  if sql and action=='read':
   primary={row['resource']for row in rows};logical=[]
   for table in dict.fromkeys(re.findall(r'(?:FROM|JOIN)\s+([A-Za-z_][A-Za-z0-9_]*)',sql,re.I)):
    if table not in DECLARED_TABLES:continue
    rid=resource('postgres/table/'+table,'postgres','Declared SQL table '+table,'PostgreSQL table',table,R[c['operation']]['evidence'])
    if rid in primary:continue
    logical.append(add('effect','sql-logical-read/'+key+'/'+table,owner=c['owner'],operation=c['operation'],effect='read',resource=rid,modality='source_traced',representation='logical',selection=selection,payload=[],evidence=R[c['operation']]['evidence']))
   if logical:add('claim','sql-join-effects/'+key,owner=c['owner'],statement='One actual driver SQL invocation has source-declared logical FROM/JOIN reads of these additional table resources. These effects are not extra physical network calls or independent transaction acknowledgements.',basis='source_declared',inputs=[c['operation'],*logical,*[r['interaction']for r in rows]],assumptions=[],evidence=R[c['operation']]['evidence'])
  for row in rows:
   if action!='write':continue
   assert name=='Exec',('Write acknowledgement needs separate source review',c['source'])
   mode='upsert'if sql and 'ON CONFLICT'in sql.upper()else'insert'if verb=='INSERT'else'update'if verb=='UPDATE'else'delete'if verb=='DELETE'else'unknown'
   branches=[('source',pairs if mode!='delete'else [],'Source '+mode+' statement branch.')]
   if mode=='upsert':
    updatepart=re.search(r'DO\s+UPDATE\s+SET(.*)',sql,re.I|re.S);assert updatepart
    conflictfields=[];insertfields=dict(pairs)
    for col,excluded,position in re.findall(r'(\w+)\s*=\s*(?:EXCLUDED\.(\w+)|\$(\d+))',updatepart[1],re.I):
     actual=insertfields.get(excluded)if excluded else values[int(position)-1];assert actual;conflictfields.append((col,actual))
    assert conflictfields;branches=[('insert',pairs,'Only when the INSERT branch is selected.'),('conflict-update',conflictfields,'Only when the ON CONFLICT DO UPDATE branch is selected; conflict/WHERE keys are selectors and are not field writes.')]
   for branch,fields,condition in branches:
    write=add('storage_write',key+'/'+row['host']+'/'+branch,owner=c['owner'],effect=row['effect'],stagedAt=c['operation'],acknowledgedAt=c['operation'],mode=mode,acknowledgement='success_result',atomicity='store_call_only',fields=[{'path':[col],'value':v,'transform':'Exact source SQL write assignment '+col+' for conditional '+branch+' branch'}for col,v in fields],gaps=[row['gap']],evidence=R[c['operation']]['evidence'],condition=condition+' Conditional success means the immediate source Exec error result == nil, not normal Go function return. UPDATE excludes WHERE-only keys; DELETE supplies selectors in effect.selection and does not write column values. Caller Commit is separate; no delivery/durability or wider transaction success is asserted.');WRITES.append({'write':write,'branch':branch,'sql':sql,'fields':fields,'selection':selection,'claim':claim,**row})
 elif p.startswith(('internal/database/postgres/','internal/database/queuedb/'))and name in ['Begin','BeginTx','Commit','Rollback','Ping']or p=='internal/database/rollback.go'and name=='Rollback':boundary(c,'riverdb'if '/queuedb/'in p else'postgres','call','postgresql','Actual source transaction/readiness '+name+'; nil-error success, commit, deferred rollback and ErrTxClosed suppression remain distinct.')
 elif p=='internal/database/postgres/migrator.go'and head=='migration.Up':boundary(c,'postgres','call','postgresql','Actual embedded migration Up; source ErrNoChange suppression. DDL declarations are not observed applied schema.')
 elif p=='internal/database/queuedb/migrator.go'and head=='migrator.Migrate':boundary(c,'riverdb','call','postgresql','Actual River migration DirectionUp with5minute timeout, deferred close; imported River DDL unavailable.')
 elif p=='internal/database/queuedb/client.go'and name=='InsertTx':boundary(c,'riverdb','write','postgresql','Actual typed River InsertTx(ctx,tx,job,nil), followed by distinct Commit; insertion result alone is not transaction/delivery acknowledgement.')
 elif p=='internal/caching/redisCache.go'and head in ['c.redis.Get','c.redis.Set','c.redis.Delete']:boundary(c,'redis','read'if name=='Get'else'write','redis','Actual imported go-redis/cache '+name+'; source TTL/cache.Item and out-pointer/value/key retained. Delete true means nil SDKerror, not proven prior existence; importedcodec/storage/durability unresolved.')
 elif p=='internal/gateway/assortment/client.go'and head=='client.Do':boundary(c,'assortment','call','http','Actual OAuth net/http Client.Do; concrete query/header builders and status/decode branches separately source-traced.')
 elif p=='internal/gateway/cchconfiguration/client.go'and head=='c.client.Do':boundary(c,'cch','call','http','Actual net/http Client.Do for structureweekconfig brand/specmarket;404empty result distinct from200decode/error.')
 elif p=='internal/gateway/filterservice/client.go'and head=='c.client.Do':boundary(c,'filter','call','http','Actual net/http Client.Do; exact wheel/policy/tree/specmarket/ruleset source caller paths/query and status/decode cases retained.')
 elif p=='internal/gateway/carspecadapter/client.gen.go'and head=='c.Client.Do':
  assert c['target']==method('internal/gateway/client.go','Do')['implementation'],('Expected source-injected local HTTP wrapper',c)
  add('claim','local-adapter-transport/'+hash(c['operation']),owner=c['owner'],statement='Default app newCarSpecAdapterClient injects gateway.HTTPClient through WithHTTPClient. This source call invokes the available local wrapper, not a second remote request. Actual underlying net/http call remains a separate dynamic-destination boundary; caller request construction, BaseURL and OAuth wrapper intent remain source associations, without automatic per-invocation destination joining.',basis='source_declared',inputs=[c['operation'],c['target'],*c['arguments']],assumptions=['Examined application constructor; generic generated NewClient default and arbitrary option replacement are distinct.'],evidence=R[c['operation']]['evidence']+anchor('internal/app/carspecadapter.go'))
 elif p=='internal/gateway/tokensource.go'and head=='a.client.PostForm':boundary(c,'token','call','http','Actual configured OAuth PostForm grant_type/client_id/client_secret/resource; expiry parsing and response decode distinct. No invented status guard.')
 elif p=='internal/gateway/client.go'and head=='c.internalClient.Do':boundary(c,'dynamic-http','call','http','Actual reusable net/http Do; concrete caller destination/transport context unresolved, wrapper is not a separate service.',targetOverride={})
 elif p=='internal/backend/cached-graphql-client.go'and head=='c.client.Run':boundary(c,'optimization','call','graphql','Actual source cached wrapper fallback client.Run(ctx,req,resp), after shouldUseBackground false. Main source normal URL; event ordinary GraphqlClient configured background URL. Imported codec/transport and cache/out-pointer context distinct.')
 elif p=='internal/backend/cached-graphql-client.go'and head=='c.backgroundClient.Run':boundary(c,'optimization-background','call','graphql','Actual source background client.Run when shouldUseBackground true (RnD spec or Polish436/2020). Main Fx explicitly registers background client. Event background-interface/config activation is not established by default source; unused provider is not a runtime startup failure claim.',targetOverride={'api':components['optimization-background'],'event':None})
 elif p=='internal/gateway/roundtripper.go'and head in ['t.next.RoundTrip','transport.RoundTrip']:boundary(c,'dynamic-http','call','http','Actual supplied next RoundTripper / imported OAuth transport call. Source header/Base/tokenSource associations retained; concrete next transport/destination and caching/refresh policy unresolved.',targetOverride={})
 elif p=='internal/gateway/optimizationapi/client.go'and head=='c.client.Run':boundary(c,'optimization','call','graphql','Actual machinebox GraphQL Run with concrete request/variables/output pointer. Event host configured background URL; main normal URL. Imported HTTP/codec policy unresolved.')
 elif p=='internal/gateway/optimizationapi/generatedclient.go'and head=='c.Client.Post':boundary(c,'optimization','call','graphql','Actual generated GraphQL Post document/typed variables/output pointer. Generated client declaration not extra server exposure; configured destination choice remains source-host context.')
 elif p=='internal/backend/optimization-api.go'and head=='c.Client.Post':boundary(c,'optimization','call','graphql','Actual older generated GraphQL Post; source cached wrapper may select normal/background client based on context. Do not infer host URL solely from generic method.',targetOverride={})
 elif p=='internal/messaging/contracts/service_grpc.pb.go'and head=='c.cc.Invoke':boundary(c,'configurator','call','grpc','Actual generated gRPC Invoke with full service/method constant, concrete protobuf request/output and CallOptions. Active connection configured host:port/TLS, imported retry/auth/transport unresolved.')
 elif p.startswith('internal/messaging/')and head=='p.publisher.Publish':
  boundary(c,'kafka','publish','kafka','When cfg.SkipKafkaWriter == false: actual message.Publisher Publish(topic,messages), source header/protobuf/trace values retained. Imported delivery and broker acknowledgement policy unresolved.')
  boundary(c,'memory','publish','in-process-channel','When cfg.SkipKafkaWriter == true: source constructor selects distinct GoChannel; actual Publisher.Publish operands retained. No Kafka network/broker or foreign consumer join is inferred.')
 elif p=='internal/app/auth.go'and head=='keyfunc.Get':boundary(c,'jwks','call','source-sdk','Actual JWKS-capable SDK Get configured URL/refresh policy. Imported implementation and refresh scheduling not fabricated.')
 elif p=='internal/app/sentry.go'and head in ['sentry.CaptureException','sentry.Flush']:boundary(c,'sentry','call','source-sdk','Actual source Sentry SDK export/flush intent; may enqueue/flush SDK state. Immediate SDK result is distinct from actual transport/delivery/durability; no per-call network packet is asserted.')
 elif p.startswith('internal/featureflag/')and name in ['BoolVariation','StringVariation','JSONVariation']:
  g=gap(c['owner'],'flag-library/'+key,'Imported feature evaluation policy','Source SDK flag/context/default evaluation may use local SDK state. Per-call network transport is not established.','Keep library evaluation inside host; do not draw flag evaluation as service request.',R[c['operation']]['evidence']);add('claim','flag-library/'+key,owner=c['owner'],statement='Exact source library evaluation '+c['source']+'. Receiver/actuals/result retained in native calls. No remote target/effect/contract is asserted.',basis='source_declared',inputs=[c['operation'],*c['arguments'],g],assumptions=[],evidence=R[c['operation']]['evidence'])
 elif any(x in head for x in ['pgxpool.New','migrate.New','otel','ld.MakeClient','sentry.Init','redis.NewClient','grpc.NewClient','kafka.New','graphql.NewClient','river.NewClient']):INITIALISATION.append(c)
(D/'io-ledger.json').write_text(json.dumps(IO,indent=2)+'\n');(D/'write-ledger.json').write_text(json.dumps(WRITES,indent=2)+'\n');(D/'io-initialisation-boundaries.json').write_text(json.dumps(INITIALISATION,indent=2)+'\n')

(D/'library-boundary-ledger.json').write_text(json.dumps(LIBRARIES,indent=2)+'\n')
