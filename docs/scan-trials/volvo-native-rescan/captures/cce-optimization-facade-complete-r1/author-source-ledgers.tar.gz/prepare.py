"""Offline exact Git-content inventory and parser staging, never repository mutation."""
from pathlib import Path
import subprocess,json,hashlib,re,collections,os
GIT_ENV={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_TERMINAL_PROMPT":"0"}
D=Path(__file__).resolve().parent;C='/Users/RNEL/.cache/groundwork/clones/volvo-cars/cce-optimization-facade';PIN='8da8ebe3227a43817bbbca25fdec182edfaa6584';S=Path('/tmp/cce-optimization-facade-pinned')
assert subprocess.check_output(['git','-C',C,'rev-parse','HEAD'],text=True,env=GIT_ENV).strip()==PIN
paths=subprocess.check_output(['git','-C',C,'ls-tree','-rz','--name-only',PIN],env=GIT_ENV).split(b'\0');paths=[p.decode()for p in paths if p];proc=subprocess.Popen(['git','-C',C,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,env=GIT_ENV);rows=[]
for path in paths:
 proc.stdin.write((PIN+':'+path+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split();assert len(header)==3 and header[1]=='blob',(path,header);raw=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';text=raw.decode('utf8',errors='replace');go=path.endswith('.go');prod=go and not path.endswith('_test.go') and not path.startswith(('test/','tests/'));generated=go and bool(re.search(r'(?im)^//.*(?:code generated|automatically generated)',text[:3000]));rows.append({'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'productionGo':prod,'generated':generated})
 if prod:
  p=S/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
proc.stdin.close();assert proc.wait()==0
summary={'repo':'volvo-cars/cce-optimization-facade','pin':PIN,'workspace':'volvo-cars','files':rows,'preparation':'Exact pinned Git bytes; inventory/parser preparation is not source review or completed extraction.'};(D/'source-inventory.json').write_text(json.dumps(summary,indent=2)+'\n');(D/'source-review-ledger.json').write_text(json.dumps({'scope':'Preparation only; no completeness claim.','files':[{**r,'status':'not_examined'}for r in rows]},indent=2)+'\n');print({'files':len(rows),'allGo':sum(r['path'].endswith('.go')for r in rows),'productionGo':sum(r['productionGo']for r in rows),'generatedProductionGo':sum(r['productionGo']and r['generated']for r in rows),'productionGoLines':sum(r['lines']for r in rows if r['productionGo']),'generatedLines':sum(r['lines']for r in rows if r['productionGo']and r['generated'])})
