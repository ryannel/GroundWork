import json
from pathlib import Path
from collections import Counter
D=Path(__file__).resolve().parent
paths=['internal/app/'+x+'.go' for x in ['app','appevent','appmarketmapping','http','grpc','cache','riverqueue','server','assortment','carspecadapter','auth','localeditionresolver','config','policymapper','facade','kafka']]
paths+=['internal/api/httpserver/'+x+'.go' for x in ['routes','eventroutes','marketmappingroutes']]
paths+=['cmd/'+x+'/main.go' for x in ['cce-optimization-facade','cce-optimization-facade-event','cce-optimization-facade-market-mapping']]
facts=[
 'Three actual Fx/process hosts: main, event and market-mapping. Separate provider/invoke/interface associations: main cached Filter/CCH, event direct Filter and background GraphQL endpoint as normal client; market mapping has separate typed handlers. Generic dispatcher AddHandler is source-known void; exact Q,R key must be preserved.',
 'Main common JWT also covers /public, which adds read authorisation; Swagger is outside the common chain. Event route common source chain has no JWT. Market mappings use common JWT plus read/admin groups. Full source nested route concatenation is retained; route factory invocation constructs handler values rather than eagerly invoking them.',
 'Main HTTP timeout60s, event600s. Gateway retry transport replaces supplied inner transport then telemetry/graphqlattr/operationID wrappers; imported retry defaults not invented. CarSpecAdapter requires URL+resource and wraps OAuth; token-source reuse imported policy. Generic local client wrappers are not services.',
 'Cache skip creates NoCache. Redis missing host errors, every timeout1hour, TLS enabled unless hostname contains localhost. Cached config TTL: Filter/CCH/OptApi default600 only when0, local editions300 only when0; negative values preserved. Source config maps env/file locations; defaults metrics/traces true only.',
 'Lifecycle HTTP, River and Watermill start Go children; River/Watermill use WithoutCancel of source hook context; stop calls remain source callbacks. CarSpecAdapter local edition resolver is a stored global callback: flag may choose hardcoded mapping, otherwise validate Pno12/year, cached fetch, legacy-market conversion then exact row match and nil notfound. Captured instance/field reads remain invocation-time source values.',
 'Postgres migrator invoked by all three app profiles; River migration only event. API main owns REST+query registration, event REST+queue+Watermill registration, market mapping own typed commands/queries. Registered SDK config does not establish network per call.'
]
(D/'review-notes.json').write_text(json.dumps([{'paths':paths,'facts':facts}],indent=2)+'\n')
ledger=json.loads((D/'source-review-ledger.json').read_text())
for f in ledger['files']:
 if f['path'] in paths:f['status']='body-reviewed'
(D/'source-review-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
m=json.loads((D/'source-symbols.json').read_text());print('syntax types',len(m['types']),'method frames',len(m['methods']),'source calls',sum(len(x['calls'])for x in m['methods']),'reviewed files',len(paths))
a=Counter()
for f in ledger['files']:
 if f['productionGo']and not f['generated']:a['/'.join(f['path'].split('/')[:3])]+=f['lines']
print(a.most_common(18))
