"""Source/wire/persisted declarations and concrete local response construction contexts."""
import yaml
SCHEMAS=[];DDL=[];RESPONSE_CONTEXTS=[];REQUEST_CONTEXTS=[]
for path in ['api/swagger.json','api/marketmapping/marketmapping_swagger.json','internal/gateway/carspecadapter/spec.yaml']:
 doc=json.loads(pinned(path))if path.endswith('.json')else yaml.safe_load(pinned(path));definitions=doc.get('definitions',doc.get('components',{}).get('schemas',{}));e=anchor(path);ids={n:P+'shape/documented/'+hash(path+n)for n in definitions}
 for name,definition in definitions.items():
  sid=ids[name];g=gap(sid,'documented/'+hash(path+name),'Declared specification versus actual encoding','Exact committed schema retained, separate from actual route registration/caller construction and imported codec behavior.','Use actual local construction/serializer before claiming effective wire closure.',e);fs=[]
  for n,f in definition.get('properties',{}).items():
   ref=f.get('$ref','').rsplit('/',1)[-1];row={'name':n,'type':f.get('type')or f.get('$ref')or'declared specification expression','optional':n not in definition.get('required',[]),'status':'declared','evidence':e}
   if ref in ids:row['shape']=ids[ref]
   fs.append(row)
  add('shape','documented/'+hash(path+name),representation='wire',label='Committed specification '+path+'#'+name,encoding='json',fields=fs,completeness='partial',gaps=[g],evidence=e);cid=add('claim','documented/'+hash(path+name),owner=sid,statement='Exact committed specification, not runtime authority: '+json.dumps(definition,sort_keys=True),basis='source_declared',inputs=[sid],assumptions=[],evidence=e);SCHEMAS.append({'path':path,'name':name,'shape':sid,'claim':cid})
 add('claim','documented-paths/'+hash(path),owner=source,statement='Exact committed specification paths/basePath: '+json.dumps({'basePath':doc.get('basePath'),'paths':doc.get('paths',{})},sort_keys=True)+'. Documentation is separate authority from actual source registrations; missing documented endpoints are not excluded from source capture.',basis='source_declared',inputs=[source],assumptions=[],evidence=e)
for p in sorted(S.glob('internal/database/postgres/migrations/*.sql')):
 path=p.relative_to(S).as_posix();raw=p.read_text();e=anchor(path);cid=add('claim','ddl/'+hash(path),owner=source,statement='Exact declared DDL migration '+path+': '+raw+'. Migration source is not observed/applied schema.',basis='source_declared',inputs=[source],assumptions=[],evidence=e);DDL.append({'path':path,'claim':cid})
# PostgreSQL models and queued job representations really use source JSON tags/converters.
persisted={};persistedclones={}
def stored_json(wire):
 if wire in persistedclones:return persistedclones[wire]
 original=R[wire];key='stored-json/'+hash(wire);sid=P+'shape/'+key;persistedclones[wire]=sid;copy=json.loads(json.dumps(original));copy.pop('id');copy.pop('kind');copy['representation']='persisted';copy['label']='Declared stored JSON projection '+copy['label'];copy['fields']=[{**f,**({'shape':stored_json(f['shape'])}if f.get('shape')else{})}for f in copy.get('fields',[])]
 if copy.get('items'):copy['items']=stored_json(copy['items'])
 add('shape',key,**copy);return sid
for key,t in M['types'].items():
 if not t['path'].startswith(('internal/database/postgres/','internal/database/queuedb/'))or key not in json_shapes or not any('json:'in(f.get('tag')or'')for f in t['fields']):continue
 original=R[json_shapes[key]];sid=stored_json(json_shapes[key]);persisted[key]=sid
 add('claim','persisted/'+hash(key),owner=sid,statement='Actual local JSON-tag declaration and available storage/job conversion context. Persisted root and nested tag projections are distinct from Go field names, protobuf and HTTP wire declarations. Actual SQL/queue binding and imported codec/omission/alias policy remain separate; this is a declaration, not an observed stored row.',basis='source_declared',inputs=[sid,shapeids[key],json_shapes[key]],assumptions=[],evidence=original['evidence'])
# Actual source handler graph helpers, retaining callbacks as associations rather than proof of policy execution.
byowner=collections.defaultdict(list)
for c in CALLS:byowner[c['owner']].append(c)
def local_http_context(iid):
 seen=set();todo=[iid]
 while todo:
  v=todo.pop()
  if v in seen:continue
  seen.add(v)
  for c in byowner[v]:
   target=lookupmethod.get(c['target'])
   if target and target['path'].startswith(('internal/api/httpserver/','internal/api/pagination/','internal/facade/')):todo.append(target['implementation'])
 return seen
FACTORY_CONTEXTS=[]
for row in rest_rows:
 if row['status']!='source-bound':continue
 contract=R[row['contract']];frames=local_http_context(row['implementation']);e=contract['evidence'];requests=[];bodyshapes=[];cases=[];queryfields={};pathfields=re.findall(r'\{([^{}]+)\}',row['path'])
 factories=[lookupmethod[row['factoryImplementation']]]if row.get('factoryImplementation')else[]
 factories += [lookupmethod[c['target']]for iid in list(frames)for c in byowner[iid]if c['target']in lookupmethod and lookupmethod[c['target']]['path']=='internal/facade/api.go'and lookupmethod[c['target']]['name'].startswith('Get')]
 for factory in {f['implementation']:f for f in factories}.values():
  for c in byowner[factory['implementation']]:
   target=lookupmethod.get(c['target'])
   if not target or target['name']!='httpHandlerAdapterForPolytopeBasedBackend' or not c['arguments']:continue
   actual=c['arguments'][0];typ=(VT.get(actual)or'').lstrip('*');targets=REC.get((typ,'Get'),[])
   if len(targets)!=1:continue
   get=targets[0];frames.update(local_http_context(get['implementation']));callbacks=[x for x in CLOSURES if x['owner']==target['implementation']];captures=[cap for x in callbacks for cap in x['captures']if cap['name']=='polytopeFacade'];sharedcalls=[x for cb in callbacks for x in byowner[cb['callback']]if x['source'].startswith('polytopeFacade.Get(')]
   detail={'entry':row['entry'],'factory':factory['implementation'],'adapterCall':c['operation'],'actualFieldValue':actual,'actualFieldSourceType':typ,'adapterFormal':target['parameters'][0],'closureCaptures':captures,'conditionalInvocationCalls':[x['operation']for x in sharedcalls],'sourceKnownGet':get['implementation'],'requestFormals':get['parameters']};cid=add('claim','factory-context/'+hash(row['entry']+factory['implementation']),owner=row['implementation'],statement='Exact source handler factory → concrete ApiFacade field → adapter formal → lexical captured variable → conditional Get(request) source association: '+json.dumps(detail)+'. Same shared lambda serves multiple factories; this does not globally bind its interface dispatch, specialise method identity, create an eager call or fabricate captures/formals. Actual default constructor stores the concrete pointer field. Automatic closure/generic/heap context dispatch remains a query limitation.',basis='source_declared',inputs=[row['entry'],factory['implementation'],c['operation'],actual,target['parameters'][0],get['implementation'],*get['parameters'],*[x['operation']for x in sharedcalls],*[x for cap in captures for x in [cap['capture'],cap['value']]]],assumptions=[],evidence=R[c['operation']]['evidence']+anchor('internal/facade/api.go')+[ev(get['path'],get['lines'])]);FACTORY_CONTEXTS.append({**detail,'claim':cid})
 for iid in frames:
  for c in byowner[iid]:
   node=callnode(c);fun=(node or{}).get('Fun',{});head=c['source'].split('(')[0]
   if fun.get('kind')=='SelectorExpr'and tx(fun['Sel'])=='Decode'and ('.Body)'in tx(fun['X'])or any('ReadAll('in x['source']and'.Body'in x['source']for x in byowner[iid])):
    actual=c['arguments'][0]if c['arguments']else None;typ=VT.get(actual)
    if typ in ['any','interface{}','interface {}']and actual in lookupmethod[iid]['parameters']:
     index=lookupmethod[iid]['parameters'].index(actual);callerTypes={VT.get(x['arguments'][index])for owner in frames for x in byowner[owner]if x['target']==iid and index<len(x['arguments'])and VT.get(x['arguments'][index])}
     if len(callerTypes)==1:typ=next(iter(callerTypes))
    typ=typ[1:]if typ and typ.startswith('*')else typ;ss=source_shape(typ,R[c['operation']]['evidence'])if typ else None;ws=jsonshape(typ,R[c['operation']]['evidence'])if typ else None;bodyshapes.append((ss,ws,c))
   if fun.get('kind')=='SelectorExpr'and tx(fun['Sel'])=='Get'and 'Query'in tx(fun['X']):
    args=node.get('Args',[])
    if args and args[0]['kind']=='BasicLit':queryfields[json.loads(args[0]['Value'])]=R[c['operation']]['evidence']
   if head in ['respond.Do','respond.Paginated']and len(c['arguments'])==4:
    payload=c['arguments'][2];status=c['arguments'][3];args=node['Args'];symbol=tx(args[3]);typ=VT.get(payload);ce=R[c['operation']]['evidence']+anchor('internal/api/httpserver/respond/model.go')+anchor('internal/api/httpserver/respond/respond.go');ss=source_shape(typ,ce)if typ else None;ws=jsonshape(typ,ce)if typ else None;key=hash(c['operation']+row['entry']);g=gap(row['implementation'],'response-context/'+key,'Concrete payload versus effective HTTP writer outcome','Source respond.Do/Paginated constructs Response or ErrorResponse after dynamic error assertion; exact caller payload/status values retained. Generic field/heap assertion/codec/writer policy is not mechanically joined.204 nil still attempts JSON in source; HTTP writer may suppress it.','Use concrete source context and error branch; do not call inner DTO the entire wire response.',ce)
    fs=[{'name':'status','type':'int','status':'declared','evidence':ce},{'name':'operationId','type':'string','status':'declared','evidence':ce},{'name':'data','type':typ or'actual caller payload type unresolved','optional':True,'status':'declared','evidence':ce,**({'shape':ws}if ws else{})}]
    if head=='respond.Paginated':fs.append({'name':'pagination','type':'respond.Pagination','shape':json_shapes[BASE+'api/httpserver/respond::Pagination'],'status':'declared','evidence':ce})
    wrapper=add('shape','response-context/'+key,representation='wire',label='Conditional declared non-error response construction '+head+' '+symbol,encoding='json',fields=fs,completeness='partial',gaps=[g],evidence=ce)
    if typ=='error':wrapper=json_shapes[BASE+'api/httpserver/respond::ErrorResponse']
    cid=add('claim','response-context/'+key,owner=row['implementation'],statement='Exact caller→respond payload/status source construction association. '+json.dumps({'operation':c['operation'],'payload':payload,'sourceType':typ,'innerSourceShape':ss,'innerJSONShape':ws,'statusValue':status,'statusSource':symbol,'wrapper':wrapper})+'. Payload implementing error selects createErrorResponse; otherwise NewResponse/NewListResponse. Header/body encoding and already-written failure semantics remain separate. This is conditional source construction, not a durability acknowledgement.',basis='source_declared',inputs=[row['entry'],c['operation'],payload,status,wrapper,*([ss]if ss else[]),*([ws]if ws else[])],assumptions=[],evidence=ce);RESPONSE_CONTEXTS.append({'entry':row['entry'],'implementation':row['implementation'],'caller':iid,'operation':c['operation'],'payload':payload,'status':status,'statusSource':symbol,'shape':wrapper,'innerSourceShape':ss,'innerWireShape':ws,'claim':cid});cases.append({'status':symbol,'body':part('body',wrapper,None,presence='unresolved',gaps=[g],e=ce),'meaning':'Source error-typed payload conditionally selects actual ErrorResponse when non-nil; nil interface follows actual non-error wrapper path. Imported writer/codec remain separate.'if typ=='error'else'Conditional non-error Response/ListResponse construction; dynamic error payload selects actual ErrorResponse source path. Imported writer/codec and exact status constant numeric resolution separate.','evidence':ce})
 if pathfields:
  sh=add('shape','route-path/'+hash(row['entry']),representation='wire',label='Actual registered path fields '+row['path'],fields=[{'name':n,'type':'string','status':'declared','evidence':e}for n in pathfields],completeness='closed',gaps=[],evidence=e);requests.append(part('path',sh,None,content=None,e=e))
 if queryfields:
  sh=add('shape','route-query/'+hash(row['entry']),representation='wire',label='Source queried fields '+row['path'],fields=[{'name':n,'type':'string','status':'declared','evidence':qe}for n,qe in queryfields.items()],completeness='partial',gaps=[runtimegap],evidence=e);requests.append(part('query',sh,None,content=None,gaps=[runtimegap],e=e))
 if len({ss for ss,ws,c in bodyshapes})==1:
  ss,ws,c=bodyshapes[0];requests.append(part('body',ws,ss,presence='unresolved',gaps=[runtimegap],e=R[c['operation']]['evidence']));REQUEST_CONTEXTS.append({'entry':row['entry'],'decodeOperation':c['operation'],'sourceShape':ss,'wireShape':ws,'actual':c['arguments']})
 elif bodyshapes:requests.append(part('body',None,None,presence='unresolved',gaps=[runtimegap],e=e))
 contract['request']=requests;contract['responses']=cases
(D/'documented-schema-ledger.json').write_text(json.dumps(SCHEMAS,indent=2)+'\n');(D/'storage-schema-ledger.json').write_text(json.dumps({'ddl':DDL,'jsonShapes':[{'sourceType':k,'sourceShape':shapeids[k],'persistedShape':v}for k,v in persisted.items()]},indent=2)+'\n');(D/'response-construction-ledger.json').write_text(json.dumps(RESPONSE_CONTEXTS,indent=2)+'\n');(D/'request-construction-ledger.json').write_text(json.dumps(REQUEST_CONTEXTS,indent=2)+'\n')
# Actual generated RPC contract addresses and protobuf input/output shapes, separate from indexed SDK signature.
OUTBOUND=[]
for io in IO:
 m=lookupmethod[io['owner']]
 if io['path']=='internal/messaging/contracts/service_grpc.pb.go':
  node=callnode(io);constant=tx(node['Args'][1]);address=None
  for d in F[io['path']]['ast'].get('Decls',[]):
   if d['kind']!='GenDecl':continue
   for spec in d.get('Specs',[]):
    if spec.get('kind')!='ValueSpec':continue
    for i,name in enumerate(spec.get('Names',[])):
     if name['Name']==constant:address=literal(spec['Values'][i],m,node['start'])
  assert address,(constant,m['name']);inputtype=next(x for x in M['methods']if x['key']==m['key'])['parameters'][1]['type'].lstrip('*');outputtype=m['results'][0]['type'].lstrip('*');contract=R[io['contract']];contract.update(method='RPC',path=address,request=[part('body',proto_shapes.get(inputtype),shapeids.get(inputtype),presence='present',content='application/protobuf',gaps=[io['gap']],e=contract['evidence'])],responses=[{'status':'returned source error == nil','body':part('body',proto_shapes.get(outputtype),shapeids.get(outputtype),presence='unresolved',content='application/protobuf',gaps=[io['gap']],e=contract['evidence']),'meaning':'Generated Invoke error guard and output pointer; gRPC status values stay distinct from HTTP outcomes.','evidence':contract['evidence']}]);OUTBOUND.append({'owner':io['owner'],'contract':io['contract'],'interaction':io['interaction'],'family':io['family'],'address':address,'inputSourceType':inputtype,'outputSourceType':outputtype})
# Reviewed source request construction frames, with exact values and all source operands retained.
for path,names,family in [
 ('internal/gateway/assortment/client.go',['getCarConfig','queryCarConfig','querySpecMarket','newQueryRequest'],'assortment'),
 ('internal/gateway/cchconfiguration/client.go',['getStructureWeekConfig'],'cch'),
 ('internal/gateway/filterservice/client.go',['GetWheelComponents','GetPolicyUidMappings','GetPolicyTreeReversed','GetSpecMarketPolicies','GetRuleset'],'filter'),
 ('internal/gateway/tokensource.go',['Token'],'token'),
 ('internal/gateway/carspecadapter/fetcher.go',['GetCarSpecification','GetLocalEditions'],'adapter'),
]:
 for name in names:
  matches=[m for m in methods if m['path']==path and m['name']==name]
  if not matches:continue
  m=matches[0];calls=byowner[m['implementation']];e=[ev(path,m['lines'])];key=hash(m['key']);cid=add('claim','outbound-construction/'+key,owner=m['implementation'],statement='Exact source '+family+' request construction frame: '+nodes[m['key']]['Body']['text']+'. Genuine formals, native field/map/header assignments, body JSON/form/protobuf construction, actual call operands and errors retained. This source context is not an extra remote invocation or an inferred whole SDK signature wire body. Imported codec and heap/transport context joining remain explicit.',basis='source_declared',inputs=[m['implementation'],*m['parameters'],*[c['operation']for c in calls],*[v for c in calls for v in c['arguments']]],assumptions=[],evidence=e);OUTBOUND.append({'owner':m['implementation'],'name':name,'path':path,'family':family,'claim':cid,'callOperations':[c['operation']for c in calls]})
for row in DI_ROWS:
 if row['interface']in DI and row['concrete']!=DI[row['interface']]:raise AssertionError(('Varying DI was globally bound',row))
for interface,concrete in CONSTRUCTOR_DI.items():
 if interface.endswith('::CarConfigurationServiceClient'):meaning='NewGrpcClient delegates to generated NewCarConfigurationServiceClient, whose result is &carConfigurationServiceClient{cc}.';e=anchor('internal/gateway/carconfigurator/client.go')+anchor('internal/messaging/contracts/service_grpc.pb.go')
 elif interface.endswith('::ClientInterface'):meaning='NewClientWithResponses calls NewClient and embeds that *Client in &ClientWithResponses{client}.';e=anchor('internal/gateway/carspecadapter/client.gen.go')
 else:meaning='RulesetReplacer.Begin returns the concrete &RulesetReplacement with actual pool/repository/car fields; fluent methods return r.';e=anchor('internal/database/postgres/rulesetreplacer.go')
 add('claim','constructor-di/'+hash(interface),owner=source,statement='Exact inspected local constructor chain source association: '+interface+' -> '+concrete+'. '+meaning+' This default-source correspondence does not infer arbitrary field writes, runtime replacement or general heap dispatch.',basis='source_declared',inputs=[source],assumptions=[],evidence=e)
(D/'outbound-construction-ledger.json').write_text(json.dumps(OUTBOUND,indent=2)+'\n')

(D/'factory-context-ledger.json').write_text(json.dumps(FACTORY_CONTEXTS,indent=2)+'\n')
# Declared current PostgreSQL row columns from the complete ordered up-migration sequence.
# Source migration intent stays distinct from observed/applied schema and imported driver codecs.
TABLES={};TABLE_EVIDENCE=collections.defaultdict(list)
for p in sorted(S.glob('internal/database/postgres/migrations/*.up.sql')):
 path=p.relative_to(S).as_posix();raw=p.read_text();e=anchor(path)
 for match in re.finditer(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.*?)\);',raw,re.I|re.S):
  table,body=match.groups();fields={}
  for line in body.splitlines():
   field=re.match(r'\s*([a-z][a-z0-9_]*)\s+([A-Za-z_][A-Za-z0-9_]*)(.*)',line)
   if not field:continue
   name,typ,rest=field.groups();fields[name]={'name':name,'type':typ,'nullable':not bool(re.search(r'NOT\s+NULL|PRIMARY\s+KEY',rest,re.I)),'status':'declared','evidence':e}
  for key in re.findall(r'PRIMARY\s+KEY\s*\((.*?)\)',body,re.I|re.S):
   for name in key.split(','):
    if name.strip()in fields:fields[name.strip()]['nullable']=False
  TABLES[table]=fields;TABLE_EVIDENCE[table].extend(e)
 for table,name,typ,rest in re.findall(r'ALTER\s+TABLE\s+(\w+)\s+ADD\s+COLUMN\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s+(\w+)([^;]*);',raw,re.I):
  TABLES[table][name]={'name':name,'type':typ,'nullable':not bool(re.search(r'NOT\s+NULL',rest,re.I)),'status':'declared','evidence':e};TABLE_EVIDENCE[table].extend(e)
 for table,name in re.findall(r'ALTER\s+TABLE\s+(\w+)\s+DROP\s+COLUMN\s+(?:IF\s+EXISTS\s+)?(\w+)',raw,re.I):TABLES[table].pop(name,None);TABLE_EVIDENCE[table].extend(e)
 for table,key in re.findall(r'ALTER\s+TABLE\s+(\w+)\s+ADD\s+PRIMARY\s+KEY\s*\((.*?)\)',raw,re.I|re.S):
  for name in key.split(','):TABLES[table][name.strip()]['nullable']=False
  TABLE_EVIDENCE[table].extend(e)
 for table in re.findall(r'DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?(\w+)',raw,re.I):TABLES.pop(table,None)
marshal_results={c['result']:c for c in CALLS if c['source'].startswith('json.Marshal(')and c['result']}
def marshal_origin(value,seen=None):
 seen=set()if seen is None else seen
 if value in seen:return None
 seen.add(value)
 if value in marshal_results:return marshal_results[value]
 for previous in incoming[value]:
  result=marshal_origin(previous,seen)
  if result:return result
 return None
TABLE_SCHEMA=[]
for table,fs in TABLES.items():
 rid=resources.get('postgres/table/'+table);e=list(dict.fromkeys(TABLE_EVIDENCE[table]));sid=P+'shape/ddl-table/'+table;g=gap(sid,'ddl-table/'+table,'Declared migration row versus applied storage/codec','Columns reflect the examined ordered up-migration declarations, not observed applied schema. PK/unique/default/FK/cascade/index/compression semantics remain exact DDL claims. Driver JSON encoding/decoding and per-row runtime values are not inferred.','Use declared row and actual SQL bindings; inspect runtime migration state/imported codec before persisted-state claims.',e);bindings=[]
 for col,f in fs.items():
  if f['type'].upper()not in ['JSON','JSONB']:continue
  candidates={};contexts=[]
  for w in WRITES:
   if w['resource']!=rid:continue
   for name,value in w['fields']:
    if name!=col:continue
    typ=VT.get(value);codec=marshal_origin(value)
    if codec and codec['arguments']:typ=VT.get(codec['arguments'][0])
    if typ:candidates[typ]=value
    contexts.append({'write':w['write'],'branch':w['branch'],'value':value,'sourceType':typ,'explicitMarshalOperation':codec['operation']if codec else None,'binding':'Actual SQL payload Go value; imported driver codec remains separate when not explicitly Marshal.'})
  if len(candidates)==1:
   typ=next(iter(candidates));f['shape']=stored_json(jsonshape(typ,e))
  if contexts:
   cid=add('claim','stored-column/'+table+'/'+col,owner=sid,statement='Exact SQL JSON column/source construction contexts: '+json.dumps(contexts)+'. Source structs/tags or explicit json.Marshal input are retained separately from imported pgx codec behavior. This is not an inferred byte-for-byte stored row or generic argument-to-result flow.',basis='source_declared',inputs=[rid,*[x for c in contexts for x in [c['write'],c['value'],c['explicitMarshalOperation']]if x]],assumptions=[],evidence=e);bindings.append({'column':col,'contexts':contexts,'claim':cid})
 add('shape','ddl-table/'+table,representation='persisted',label='Declared PostgreSQL row '+table+' after source up migrations (not observed schema)',encoding='relational',container='object',fields=list(fs.values()),completeness='closed',gaps=[g],evidence=e)
 if rid:R[rid]['shapes'].append(sid)
 add('claim','ddl-table/'+table,owner=sid,statement='All22 up-migration files inspected in sequence. Exact default, PK/unique, FK ON DELETE CASCADE, index and LZ4 declarations are retained in the linked source DDL claims; rows are declarations only. Historical carkeys/start_car_keys are dropped by later source migrations. Brand type declares VCC/POL then addsLCO. SQL read/write operations reference actual table resources; WHERE/conflict keys remain selectors, conditional SET/INSERT values remain write payloads.',basis='source_declared',inputs=[sid,*([rid]if rid else[]),*[x['claim']for x in DDL]],assumptions=[],evidence=e)
 TABLE_SCHEMA.append({'table':table,'shape':sid,'resource':rid,'fields':list(fs),'jsonBindings':bindings})
assert set(TABLES)=={'cars','spec_market_rulesets','policy_rulesets','spec_market_components','start_car_configurations','base_car_configurations','car_components','markets','clients','policies','offer_mappings'}
assert 'id'not in TABLES['spec_market_components']
assert TABLES['cars']['ruleset_id']['nullable']
(D/'table-schema-ledger.json').write_text(json.dumps(TABLE_SCHEMA,indent=2)+'\n')
# One source-local custom JSON encoder, not an unexamined imported policy.
keep=method('internal/backend/runner-path.go','MarshalJSON');kt=BASE+'backend::KeepZero';add('claim','keep-zero-json',owner=shapeids[kt],statement='Actual KeepZero.MarshalJSON source: integral values FormatFloat(f,\'f\',1,32), others FormatFloat(f,\'f\',-1,32), converted to []byte and returned withnilerror. Source helper body and numeric result declaration inspected; automatic encoding/json custom-marshaler dispatch is not mechanically joined, and no object envelope is invented.',basis='source_declared',inputs=[shapeids[kt],keep['implementation']],assumptions=[],evidence=[ev(keep['path'],keep['lines'])])
joins={r['result']:r['owner']for r in R.values()if r['kind']=='operation'and r['label'].startswith('Source reaching definitions join ')and r['result']}
if joins:
 joinowners=set(joins.values())
 sg=gap(source,'source-ssa-precision','Automatic branch/iteration value precision','Separate branch environments and actual source guard transitions are retained. Native reaching-definition joins express alternatives, not simultaneous runtime inputs/allocated objects. Formal guard feasibility, repeated loop state and variable-cell/heap alias effects are not solved.','Read source guards, field/capture/assignment associations and explicit invocation context; do not interpret lineage alternatives as observed execution.',anchor('internal/api/httpserver/policy/controller.go')+anchor('internal/service/carspecificationpipeline.go')if (S/'internal/service/carspecificationpipeline.go').exists()else anchor('internal/api/httpserver/policy/controller.go'))
 for r in R.values():
  if r['kind']=='flow'and r['to']in joins:r['gaps'].append(sg);r['assumptions'].append('Alternative reaching definition under the retained source branch/iteration guards; no simultaneous value computation or formal feasibility proof asserted.')
  if r['kind']=='coverage'and r['owner']in joinowners:r['gaps'].append(sg)
for(owner,field),concrete in DI_FIELDS.items():
 typ=M['types'][owner];e=anchor(typ['path'])+(anchor('internal/app/carspecadapter.go')if owner.endswith('carspecadapter::Client')else[]);add('claim','constructor-field/'+hash(owner+field),owner=shapeids[owner],statement='Exact default source constructor field association '+owner+'.'+field+' -> '+concrete+'. The generated adapter Client.Client receives gateway.HTTPClient via app newCarSpecAdapterClient and WithHTTPClient (generated constructor defaults are distinct). Cached clients receive the concrete direct client/ WrappedClient/LocalEditionFetcher; cache fields receive NewPrefixedCache, whose wraps formal remains conditional Redis/NoCache source association. This precedence prevents replacing an inner direct client with the outer host-level cached interface. Original method identities, actual receiver values and field assignments retained; mutable heap/runtime replacement and imported cache/codec policy are not proved.',basis='source_declared',inputs=[shapeids[owner],shapeids[concrete]],assumptions=['Examined default source constructor path only.'],evidence=e)
add('claim','ruleset-replacement-constructor',owner=shapeids[BASE+'database/postgres::RulesetReplacement'],statement='Exact source RulesetReplacer.Begin returns &RulesetReplacement{pool:r.pool,carRepository:r.carRepository,car:carWithVersions}. It omits logger. This is the available default domain.RulesetReplacement construction path; fluent RulesetID/StartConfigurations/BaseConfigurations/Components set flags/payloads and return the same receiver; Commit has a genuine ctx formal and reads those fields before separate transaction/helper/Commit calls. No new logical method or fake formals are created; automatic heap/field-state joins remain limited.',basis='source_declared',inputs=[shapeids[BASE+'database/postgres::RulesetReplacement'],shapeids[BASE+'domain::RulesetReplacement']],assumptions=[],evidence=anchor('internal/database/postgres/rulesetreplacer.go'))
