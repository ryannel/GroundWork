"""Reconcile completed source inspection separately from finite query projection limits."""
import json,collections,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;b=json.load(open(D/'working.bundle.json'));rs=b['records'];by={r['id']:r for r in rs};M=json.load(open(D/'source-symbols.json'));pending={r['id']for r in rs if r['kind']=='gap'and'/pending-body/'in r['id']};rs[:]=[r for r in rs if r['id']not in pending]
implementations={x['id']for x in rs if x['kind']=='implementation'}
for r in rs:
 if r['kind']=='coverage'and r['owner']in implementations and '/swagger/'not in r['owner']:
  r['gaps']=[x for x in r['gaps']if x not in pending];r.update(obligation='Pinned source body inspection and native source transcription',status='examined',scope='Actual source signature/body/direct calls, branches, source data constructions and local registration associations examined. Generated template bodies checked separately. Source inspection is distinct from automatic whole-entry projection: generic/delegate/heap/Scan/channel/defer/panic/codec/imported policy and query bounds remain explicit limitations, not missing local source.')
 if r['kind']=='gap'and'/type/'in r['id']and r['obligation']=='Source declaration representation':
  r.update(reason=r['reason'].replace('projection pending:','declaration retained (native callable/interface/map slots and generic context are partial):'),action='Use exact source declaration/signatures and source-owned claims. Do not invent data fields for callable/interface method sets or claim automatic generic/container dispatch.')
assert not any('pending-body/'in r['id']for r in rs)
(D/'working.bundle.json').write_text(json.dumps(b,indent=2)+'\n')
ledger=json.load(open(D/'source-review-ledger.json'));I=json.load(open(D/'source-inventory.json'));rows=[]
for f in ledger['files']:
 f=dict(f);p=f['path']
 if f['productionGo']:assert f['status']=='body-reviewed',(p,f['status']);f['sourceRole']='auxiliary-unhosted-source'if p.startswith(('internal/servicetest/','internal/fake/'))else'generated-source'if f['generated']else'production-source'
 elif p.endswith('_test.go')or p.startswith('test/'):f.update(status='excluded-production-execution',sourceRole='test-or-fixture; inventoried, not executed or used as runtime authority')
 elif f['status']=='body-reviewed':f['sourceRole']='declared-ddl'if p.endswith('.sql')else'source-configuration-or-schema-documentation'
 elif p.endswith('.png'):f.update(status='inventory-reconciled-no-production-execution',sourceRole='documentation-illustration; no independent runtime authority')
 elif p.startswith('.github/')or p in ['.gitignore','.golangci.yaml','.grype.yaml','bin/.gitkeep']:f.update(status='inventory-reconciled-no-production-execution',sourceRole='repository-tooling-or-editor-advice; no production registration')
 else:raise AssertionError(('Unreconciled source',p,f['status']))
 rows.append(f)
(D/'source-review-ledger.json').write_text(json.dumps({'scope':'Whole pinned production source/config/schema/registration inspection completed. Test/fixture/tooling/image exclusions explicitly reconciled. Source facts do not establish live activation, delivery/durability or automatic heap/runtime proof.','pin':I['pin'],'files':rows},indent=2)+'\n')
counts=collections.Counter(r['kind']for r in rs);reg=json.load(open(D/'rest-registration-ledger.json'));limits=json.load(open(D/'native-expansion-limits.json'));methods=json.load(open(D/'native-method-ledger.json'));calls=json.load(open(D/'native-call-ledger.json'))
assert len({r['id']for r in rs})==len(rs)
sourcehash={f['path']:f['sha256']for f in I['files']};staged=Path('/tmp/cce-optimization-facade-pinned');bad=[]
for f in I['files']:
 p=staged/f['path']
 if p.exists()and p.is_file()and hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:bad.append(f['path'])
assert not bad,bad
(D/'completeness-ledger.json').write_text(json.dumps({'repo':I['repo'],'pin':I['pin'],'trackedFiles':len(rows),'productionNamedGo':sum(f['productionGo']for f in rows),'generatedProductionGo':sum(f['productionGo']and f['generated']for f in rows),'productionGoInspection':'examined actual bodies/templates','sourceImplementations':len(methods),'nativeSourceCalls':len(calls),'actualRestRegistrations':len(reg),'restByHost':dict(collections.Counter(r['host']for r in reg)),'restUnreconciled':sum('entry'not in r for r in reg),'missingLocalSourceBodies':0,'realProjectionLimits':len(limits),'unsupportedSourceKinds':dict(collections.Counter(x['reason'].split(':')[0]for x in limits if x['reason'].startswith('Unexpanded'))),'counts':dict(counts),'sourceInspectionVsQuery':'Source frames/constructors/registrations/values are inspected and queryable. Callback/registry/generic/heap/Scan/channel/defer/recover/imported transport joins and bounded whole-entry projections are not complete runtime proofs.','idPolicy':'New physical revision namespace, stable logical identities, unequal/cross-kind ID reuse rejected; no historical capture imported or mutated.','stagedSourceSHA256MatchesPinnedInventory':True},indent=2)+'\n')
(D/'source-symbol-audit.json').write_text(json.dumps({'sourceASTMethods':len(M['methods']),'nativeMethods':len(methods),'methodKeysUnique':len({m['key']for m in methods})==len(methods),'sourceInitDeclarations':[{'path':m['path'],'lines':m['lines'],'key':m['key'],'implementation':m['implementation']}for m in methods if m['name']=='init'],'generatedServerDeclarations':'Seven generated CaaS server stubs/decoder handlers are source declarations only, no hosted RPC entries.','entrySummary':reg,'rawStatementLimitCount':sum(x['reason'].startswith('Unexpanded')for x in limits)},indent=2)+'\n')
print(json.dumps({'records':len(rs),'coverage':counts['coverage'],'REST':len(reg),'sourceMethods':len(methods),'unsupportedKinds':sum(x['reason'].startswith('Unexpanded')for x in limits)}))
