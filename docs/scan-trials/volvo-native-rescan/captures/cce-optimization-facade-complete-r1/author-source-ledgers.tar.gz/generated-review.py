"""Review pinned generated protobuf families, retaining every declaration/body range."""
import json,re,collections
from pathlib import Path
D=Path(__file__).resolve().parent;A=json.load(open(D/'source-ast.json'));rows=[];counts=collections.Counter();paths=[]
for f in A['files']:
 if not f['path'].endswith('.pb.go') or f['path'].endswith('_grpc.pb.go'):continue
 paths.append(f['path'])
 for n in f['ast'].get('Decls',[]):
  if n['kind']!='FuncDecl':continue
  name=n['Name']['Name'];s=re.sub(r'\s+',' ',n['Body']['text']).strip();cat=None
  if name.startswith('Get'):
   match=re.fullmatch(r'\{ if x != nil(?: && x\.([\w]+) != nil)? \{ return (\*?)x\.(\w+) \} return (nil|""|0|false|[\w.]+) \}',s);assert match,(f['path'],name,s);assert name=='Get'+match[3];cat='nil/default field getter'
  elif name=='Reset':assert s.startswith('{ *x = ') and 'ms.StoreMessageInfo(mi)'in s;cat='reset'
  elif name=='String':assert 'protoimpl.X.'in s and ('MessageStringOf(x)'in s or 'EnumStringOf('in s);cat='message/enum string'
  elif name=='ProtoMessage':assert s=='{}';cat='marker'
  elif name=='ProtoReflect':assert all(x in s for x in ['if x != nil','ms.LoadMessageInfo() == nil','ms.StoreMessageInfo(mi)','return ms','return mi.MessageOf(x)']);cat='reflection'
  elif name in ['Descriptor','EnumDescriptor']:assert 'rawDescGZIP(), []int{'in s or re.fullmatch(r'\{ return file_\w+_enumTypes\[\d+\]\.Descriptor\(\) \}',s);cat='descriptor'
  elif name=='Enum':assert re.fullmatch(r'\{ p := new\(\w+\) \*p = x return p \}',s);cat='enum pointer allocation'
  elif name=='Type':assert re.fullmatch(r'\{ return &file_\w+_enumTypes\[\d+\] \}',s);cat='enum reflection type'
  elif name=='Number':assert s=='{ return protoreflect.EnumNumber(x) }';cat='enum number'
  elif name=='init':assert '_proto_init()'in s;cat='initializer'
  elif name.endswith('rawDescGZIP'):assert 'rawDescOnce.Do(func()'in s and 'CompressGZIP('in s;cat='deferred compression'
  elif name.endswith('_proto_init'):assert 'if File_'in s and '.Build()'in s;cat='descriptor builder'
  else:raise AssertionError((f['path'],name,s))
  counts[cat]+=1;rows.append({'path':f['path'],'name':name,'lines':n['lines'],'category':cat,'body':n['Body']['text']})
# The seven generated client methods, seven server stubs, seven decoder/interceptor handlers,
# constructor, registration and embed checks were read separately in full. No local server host.
p='internal/messaging/contracts/service_grpc.pb.go';paths.append(p)
for f in A['files']:
 if f['path']==p:
  for n in f['ast'].get('Decls',[]):
   if n['kind']=='FuncDecl':rows.append({'path':p,'name':n['Name']['Name'],'lines':n['lines'],'category':'fully reviewed grpc client/server declaration body','body':n['Body']['text']})
(D/'generated-source-review.json').write_text(json.dumps({'counts':dict(counts),'scope':'Every protobuf family body checked; gRPC full methods/client Invoke arguments/decoder/interceptor forwarding/server stubs separately read. Generated server declarations are not hosted APIs. Raw descriptors and source tags establish source/wire declarations, not deployments. Imported protobuf internals remain library policy.','methods':rows},indent=2)+'\n')
print(json.dumps({'paths':paths,'facts':['All generated protobuf getters checked against actual field/default/pointer source templates; Reset, reflection, enum allocation, descriptors and every initializer/compression builder checked. Imported protobuf runtime behavior remains unresolved library policy.','Seven CarConfigurationService generated RPC client methods use exact full v2 service/method addresses and concrete request/response pointers; seven server decoder/interceptor handlers and Unimplemented stubs are declarations only. No Facade gRPC server registration found; actual gateway caller usage establishes outbound RPCs.']}))
