import pathlib,json,hashlib
OUT=pathlib.Path(__file__).resolve().parent;ROOT=OUT.parent.parent.parent;SRC=pathlib.Path('/tmp/cdls-mono-volvocars-pinned')
if (OUT/'capture-seal.json').exists():raise SystemExit('Immutable capture')
bundle=json.loads((OUT/'bundle.json').read_text());rs=bundle['records'];by={r['id']:r for r in rs};census={r['path']:r for r in json.loads((ROOT/'sourcefile-census.json').read_text())['files']};body=json.loads((OUT/'body-completeness-ledger.json').read_text());scopes=[]
for pkg in ['site-nav-embed','site-footer-embed']:
 suffix='SiteNavigation'if pkg=='site-nav-embed'else'SiteFooter'
 for name in ['fetch'+suffix+'Props.ts','get'+suffix+'Url.ts','types.ts']:
  path='packages/'+pkg+'/src/'+name;data=(SRC/path).read_bytes();scopes.append(dict(path=path,oid=census[path]['oid'],lines=[1,len(data.splitlines())],bytes=len(data),scope='entire_source_file_read',nativeScope='all function bodies or explicit compressed error constructor; props/options declarations and known constraints',status='source_reviewed_bounded_unit',qualification='Does not include remaining request/ESI/UI helpers in package'))
(OUT/'sourcefile-completeness-ledger.json').write_text(json.dumps(dict(files=scopes,fullFiles=6,unexaminedInDeclaredScope=0,additionalEvidenceOnly=['apps/ev-subsidy/app/[siteSlug]/layout.tsx'],qualification='Only these six files are fully covered in this unit; EV layout/request/ESI/cookie/import closure and monorepo remain separate source obligations.'),indent=2)+'\n')
exact=[]
for pkg in ['site-nav-embed','site-footer-embed']:
 inventory=ROOT/'syntax-inventory'/('packages__'+pkg+'.jsonl')
 for line in inventory.open():
  row=json.loads(line)
  if row['path'] not in {s['path']for s in scopes}:continue
  for fn in row['functions']:
   if not fn['hasBody']:continue
   matches=[b for b in body if b['path']==row['path'] and b['lines']==fn['lines']];assert len(matches)==1,(row['path'],fn['name'],fn['lines']);b=matches[0];exact.append(dict(sourceIdentity=fn['id'],path=row['path'],name=fn['name'],lines=fn['lines'],parameters=fn['parameters'],declaredReturnType=fn['returnType'],nativeOwner=b.get('owner'),status=b['status'],qualification=b['qualification']))
assert len(exact)==10
(OUT/'body-completeness-ledger.json').write_text(json.dumps(dict(sourceBodies=10,namedFrames=8,compressedConstructors=2,bodies=exact,unexaminedBodiesInScope=0),indent=2)+'\n')
checks=[]
for r in rs:
 if r['kind']!='evidence':continue
 data=(SRC/r['path']).read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert oid==census[r['path']]['oid'];assert 1<=r['lines'][0]<=r['lines'][1]<=len(data.splitlines());checks.append(dict(id=r['id'],path=r['path'],lines=r['lines'],oid=oid,status='exact_pinned_cached_blob_and_range_verified'))
(OUT/'source-range-audit.json').write_text(json.dumps(dict(evidence=len(checks),files=len({r['path']for r in checks}),checks=checks),indent=2)+'\n')
(OUT/'schema-ledger.json').write_text(json.dumps(dict(sourceShapes=[r for r in rs if r['kind']=='shape'],contracts=[r for r in rs if r['kind']=='interface_contract'],qualification='Source props declarations, URL/options/caller/allocated-result projections; enum/const fields native. Dynamic auth header key remains native actual source values/claims, not guessed static header. Navigation declaration intersection siteSlug-or-html is source claim, not fabricated object member or runtime wire guard. SDK/wire/enforcement unknown.'),indent=2)+'\n')
(OUT/'symbol-resolution-audit.json').write_text(json.dumps(dict(methods=[r for r in rs if r['kind']=='implementation'],localCalls=[dict(operation=r['id'],target=by[r['resolution']]['target'],bindings=r['bindings'],receiver=r.get('receiver'))for r in rs if r['kind']=='operation'and r['resolution'] and by[r['resolution']]['target']],unresolvedCalls=[dict(operation=r['id'],label=r['label'],receiver=r.get('receiver'))for r in rs if r['kind']=='operation'and r['resolution'] and not by[r['resolution']]['target']],qualification='Exact file-local lexical names/arity, no overload ambiguity, parser attribution or arbitrary dispatch. Fetch/text/console imported calls are explicit. Error constructors compressed with exact source status/url/prototype and throw association. Shared code executes in caller host, not service per package.'),indent=2)+'\n')
(OUT/'registration-ledger.json').write_text(json.dumps(dict(physicalRegistrations=0,entries=0,subscriptions=0,context='EV Next server imports getSiteNavigationPropsForRequest/getSiteFooterPropsForRequest; their local closure calls these fetch functions only on direct-fetch alternatives. This unit exposes source helper bodies for drilldown, not new runtime registrations or unconditional layout calls.',sourceHost='API001 exact EV Next server',remainingSourceScope=['EV SSR layout','getPropsForRequest disable/forceFetch/Akamai branches','ESI render wrappers/client callbacks','cookie helper closure']),indent=2)+'\n')
(OUT/'async-return-acknowledgement-ledger.json').write_text(json.dumps(dict(sourceAsyncFunctions=2,immediateHandles='async helpers and imported fetch/text results remain values',awaitedSource=['fetch(src||alt,fetchOptions)','resp.text()'],cacheIntent='next.revalidate1200China/300elsewhere; no observed cache or scheduling proof',acknowledgement='No DB/broker writes, no retry/alternate fetch. Fetch response.ok guard throws on non-ok; text feeds source html. Imported HTTP transport/status/caches and effective deployed renderer remain unknown.',errorConstructorCompression='Exact source super(message/status/url), this.status/url and prototype mutation retained through source claims; no invented network error policy.'),indent=2)+'\n')
print('audit:6fullfiles,10sourcebodies(8frames/2compressedconstructors),',len(checks),'ranges')
