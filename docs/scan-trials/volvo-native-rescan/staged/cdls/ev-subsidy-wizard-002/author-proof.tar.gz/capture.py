"""Finite source wizard callback capture; no source execution."""
import pathlib,json,hashlib
OUT=pathlib.Path(__file__).resolve().parent;SRC=pathlib.Path('/tmp/cdls-mono-volvocars-pinned');PIN='8e1fd20c525fd3ef46f89fa7734dba06b06c79fc';REPO='volvo-cars/cdls-mono-volvocars';P='volvo/cdls-mono-volvocars/8e1fd20c525f/ev-subsidy-wizard-r2/'
if (OUT/'snapshot.json').exists():raise SystemExit('Immutable checkpoint')
records=[];by={}
def h(x):return hashlib.sha256(x.encode()).hexdigest()[:20]
def add(kind,key,**kw):
 rid=P+key;assert rid not in by,rid;r=dict(id=rid,kind=kind,**kw);records.append(r);by[rid]=r;return rid
def ev(path,a=1,b=None):
 b=b or len((SRC/path).read_bytes().splitlines());key='e/'+h(path+str([a,b]));rid=P+key
 return [rid] if rid in by else [add('evidence',key,repo=REPO,commit=PIN,path=path,lines=[a,b],basis='source',host='github.com')]
def shape(key,label,fields,path,lines):return add('shape','shape/'+key,representation='source',label=label,fields=[dict(name=n,type=t,status='declared',optional=o,evidence=ev(path,*lines)) for n,t,o in fields],completeness='partial',gaps=[gap],evidence=ev(path,*lines))
ledger=[]
class Frame:
 def __init__(self,key,path,method,address,lines):
  self.key=key;self.path=path;self.lines=lines;self.n=0;self.evidence=ev(path,*lines);self.owner=add('implementation','method/'+key,logicalId=path+'#'+key+'@'+str(lines[0]),scope=source,entry=P+'op/'+key+'/entry',parameters=[],returnKind='value',evidence=self.evidence);self.entry=self.op('entry','Source '+method,lines,key='entry');self.execution=add('execution_binding','execution/'+key,implementation=self.owner,component=server,basis='source_declared',artifactBinding=None,gaps=[gap],evidence=self.evidence);self.entryId=add('entry','entry/'+key,logicalId='cdls:ev-subsidy:'+method+' '+address,trigger='callback',method=method,path=address,implementation=self.owner,evidence=self.evidence);self.contract=add('interface_contract','contract/'+key,component=server,protocol='callback',name=method+' '+address,method=method,path=address,authority='source_declared',request=[],responses=[],gaps=[gap],evidence=self.evidence);add('entry_binding','entry-binding/'+key,entry=self.entryId,execution=self.execution,contract=self.contract,gaps=[gap],evidence=self.evidence);self.catch=None;self.last=self.entry
 def op(self,action,label,lines,key=None,result=None,status=None,exit=None):
  self.n+=1;key=key or str(self.n);rid=add('operation','op/'+self.key+'/'+key,owner=self.owner,action=action,label=label,resolution=None,bindings=[],result=result,exit=exit,httpStatus=status,evidence=ev(self.path,*lines))
  if action=='call':by[rid]['resolution']=add('resolution','resolution/'+self.key+'/'+key,owner=self.owner,requestedArtifact=None,basis='unresolved',target=None,binding=None,candidates=[],evidence=ev(self.path,*lines))
  return rid
 def value(self,op,label,lines,shape=None,role='definition'):
  return add('value','v/'+self.key+'/'+str(len(records)),owner=self.owner,definition=op,label=label,role=role,representation='source',shape=shape,accessPath=[],evidence=ev(self.path,*lines))
 def edge(self,a,b,lines,on='normal',condition=None,values=[]):return add('transition','t/'+str(len(records)),owner=self.owner,**{'from':a,'to':b},on=on,condition=condition,values=values,evidence=ev(self.path,*lines))
 def flow(self,a,b,op,label,lines):return add('flow','flow/'+str(len(records)),owner=self.owner,**{'from':a,'to':b},at=op,transform=label,gaps=[],assumptions=[],evidence=ev(self.path,*lines))
 def claim(self,label,inputs,lines):return add('claim','claim/'+str(len(records)),owner=self.owner,statement=label,basis='source_declared',inputs=inputs,assumptions=[],evidence=ev(self.path,*lines))
 def step(self,label,lines,inputs=[],shape=None,action='compute',link=True):
  op=self.op(action,label,lines)
  if link:self.edge(self.last,op,lines,on='true' if by[self.last]['action']=='branch' else 'normal',condition=by[self.last]['label'] if by[self.last]['action']=='branch' else None)
  v=self.value(op,label,lines,shape)
  by[op]['result']=v
  for x in inputs:self.flow(x,v,op,label,lines)
  self.last=op
  return v
 def branch(self,label,lines,inputs=[]):
  op=self.op('branch',label,lines);self.edge(self.last,op,lines,values=inputs);self.last=op;return op
 def returned(self,label,lines,status,inputs=[],condition=None,fromop=None,link=True,fields=[]):
  parent=fromop or self.last;op=self.op('compute','Construct source JSON payload '+label,lines);sh=shape(self.key+'-response-'+str(len(records)),label,fields,self.path,lines);payload=self.value(op,label,lines,sh)
  for x in inputs:self.flow(x,payload,op,'Source field projection/construction: '+label,lines)
  if link:self.edge(parent,op,lines,on='true' if condition else 'normal',condition=condition)
  wrapper=self.op('call','NextResponse.json(payload, source status options)',lines);self.edge(op,wrapper,lines);result=self.value(wrapper,'NextResponse source outer response; JSON body remains separate',lines);by[wrapper]['result']=result;self.claim('Actual NextResponse.json source argument payload and status options; imported response construction/serialization is not an argument→returned-object identity proof.',[wrapper,payload,result],lines)
  ret=self.op('return','Return '+label,lines,result=result,status=status,exit='normal');self.edge(wrapper,ret,lines);by[self.contract]['responses'].append(dict(status=str(status) if status else 'source_dynamic_status',body=dict(part='body',presence='present',shape=None,sourceShape=sh,contentType='application/json',gaps=[gap],evidence=ev(self.path,*lines)),meaning=label,evidence=ev(self.path,*lines)));return op,ret
 def fetch(self,label,lines,url,method,actuals,body=None):
  op=self.op('call','fetch '+method+' '+url,lines);self.edge(self.last,op,lines);by[op]['waitsFor']='await';promise=self.value(op,'Immediate Promise<Response> handle for '+label,lines);by[op]['result']=promise
  sig=shape(self.key+'-signature-'+str(len(records)),'Source call-signature projection for fetch; not a runtime object or wire body',[(n,'string' if n=='argument0' else 'RequestInit source object',False) for n,v in actuals],self.path,lines)
  contract=add('interface_contract','io-contract/'+str(len(records)),component=remote,protocol='http',name=method+' '+url,method=method,path=url,authority='caller_construction',request=[dict(part='record',presence='present',shape=None,sourceShape=sig,contentType=None,gaps=[gap],evidence=ev(self.path,*lines))],responses=[],gaps=[gap],evidence=ev(self.path,*lines))
  ix=add('interaction','io/'+str(len(records)),owner=self.owner,execution=self.execution,operation=op,target=remote,targetEntry=None,contract=contract,effect=None,handoff=None,mode='request_response',boundary='network',waitsFor='response',condition='Source awaited browser fetch to relative EV API route; effective routing and imported HTTP behavior unresolved',requestBindings=[dict(part='record',path=[n],value=v,transform='Exact indexed source argument/field projection; not invented external formal') for n,v in actuals],responseBindings=[dict(part='result',path=[],value=promise,transform='Immediate Promise handle, distinct from eventual Response below')],gaps=[gap],evidence=ev(self.path,*lines))
  self.claim('Source actual request URL/options are caller-owned; signature projection retains source field values and no invented external formals.',[op,ix]+[v for n,v in actuals],lines)
  awaitop=self.op('compute','Await fetch completion: Response for '+label,lines);self.edge(op,awaitop,lines);response=self.value(awaitop,'Awaited Response for '+label,lines);self.claim('Await links this Promise handle to its eventual source Response, not to arbitrary remote body data.',[promise,response,op,awaitop],lines);self.last=awaitop;ledger.append(dict(entry=self.entryId,operation=op,interaction=ix,contract=contract,source=self.path,lines=lines,actualValues=actuals,url=url,method=method));return response
 def finish(self):
  add('coverage','coverage/'+self.key,owner=self.owner,obligation='finite_source_callback_body',status='partial',scope='Finite callback body branches, actual state/callback values, catches/finally and request/response projections reviewed. Imported dispatch, captured-origin projection and remaining UI/shared bodies are separate obligations.',gaps=[gap],evidence=self.evidence)


source=add('source_revision','source',repo=REPO,commit=PIN)
gap=add('gap','gap/callback-runtime',owner=source,obligation='react_dispatch_closure_and_effective_routing',reason='Source callbacks and explicit body logic are known; React/Google component dispatch, actual rendered closure environments, concurrent task interleavings and effective browser-to-server routing remain unobserved. Other UI/shared body obligations remain separate.',action='Use actual callback roots and source call associations; do not turn construction/registration into invocation or infer source-local absence from unknown runtime closure origins.',evidence=ev('apps/ev-subsidy/src/components/wizard/StepAddress/index.tsx'))
server=add('runtime_component','component/browser',logicalId='cdls:ev-subsidy-browser',label='EV Subsidy browser app',category='app',technology='React / browser',sources=[source],basis='source_declared',gaps=[gap],evidence=ev('apps/ev-subsidy/src/RootLayoutProvider.tsx')+ev('apps/ev-subsidy/src/components/wizard/Wizard.tsx'))
API='volvo/cdls-mono-volvocars/8e1fd20c525f/ev-subsidy-api-r1/'
remote=API+'component/ev-subsidy-server'
base=json.loads((OUT.parent.parent/'ev-subsidy-api/checkpoint-001/bundle.json').read_text())
# The frozen API bundle is selected with this unit, preserving exact same technical server ID.
API_ENTRIES={r['path']:r['id'] for r in base['records'] if r['kind']=='entry'}
def captures(f,items):
 out={}
 for name,typ,lines in items:out[name]=f.value(f.entry,name+' : '+typ,lines,role='capture')
 by[f.owner]['captures']=list(out.values());return out

def callback_end(f,lines):
 op=f.op('return','Callback eventual completion (no explicit returned value)',lines,exit='normal');f.edge(f.last,op,lines);f.last=op;f.finish()
def void_call(f,label,lines,actuals):
 op=f.op('call',label,lines);f.edge(f.last,op,lines)
 if label in ('setLoading(true)','setIsEligible(null)','setIsEligible(false)'):
  literal=label.split('(',1)[1].split(')',1)[0];actuals=actuals+[f.value(op,'Source argument0 constant '+literal,lines,role='constant')]
 if label.startswith('tracker.customEvent'):
  by[op]['receiver']=actuals[0]
  sh=shape('tracking-'+str(len(records)),'Actual customEvent source argument object',[(n,'string',False) for n in ('eventAction','eventLabel','eventCategory')],f.path,lines)
  argument=f.value(op,'{eventAction:button|click,eventLabel:Bekräfta uppgifter,eventCategory:Premietestet}',lines,shape=sh)
  actuals=actuals+[argument]
 f.claim('Source call callee/receiver followed by actual source arguments in order. No invented external formals, fluent return or setter result.',[op]+actuals,lines);f.last=op;return op
def outgoing(f,label,lines,url,bodyshape,body,options):
 optionShape=shape('options-'+str(len(records)),'Actual allocated source RequestInit object',[('method','POST',False),('headers','{Content-Type:application/json}',False),('body','JSON.stringify source payload string',False)],f.path,lines)
 by[options]['shape']=optionShape
 urlvalue=f.step('Source relative URL '+url,lines)
 response=f.fetch(label,lines,url,'POST',[('argument0',urlvalue),('argument1',options)])
 io=by[ledger[-1]['interaction']];providerEntry=API_ENTRIES[url];io['targetEntry']=providerEntry;contract=by[io['contract']];contract['request'].append(dict(part='body',presence='present',shape=None,sourceShape=bodyshape,contentType='application/json',gaps=[gap],evidence=ev(f.path,*lines)));io['requestBindings'].append(dict(part='body',path=[],value=body,transform='Actual JSON.stringify body operand inside source RequestInit; no invented external formal'))
 signature=by[contract['request'][0]['sourceShape']]
 signature['fields'][1]['shape']=optionShape
 candidateShape=shape('parsed-result-'+str(len(records)),'Caller parsed JSON projection; actual response validation is absent', [('eligible','unknown source value',True)] if url.endswith('eligibility') else [('incomeSection','unknown source object',True)],f.path,lines)
 for field in by[candidateShape]['fields']:field['status']='candidate'
 contract['responses'].append(dict(status='source Response.ok branch',body=dict(part='body',presence='present',shape=None,sourceShape=candidateShape,contentType=None,gaps=[gap],evidence=ev(f.path,*lines)),meaning='Caller parses JSON and projects fields without runtime validation; source provider correspondence does not prove wire payload compatibility.',evidence=ev(f.path,*lines)))
 f.claim('Source caller/provider method/path correspondence within EV Subsidy, not observed live routing or server response execution completion.',[io['id'],providerEntry],lines);return response
path='apps/ev-subsidy/src/components/wizard/StepAddress/index.tsx'
f=Frame('handleSelect',path,'CALLBACK','browser:ev-subsidy:StepAddress:onSelectAction',[22,48]);cs=captures(f,[('setLoading','React state setter',[22,48]),('setIsEligible','React state setter',[22,48])]);locshape=shape('selected-address','SelectedAddress source declaration',[('address','string',False),('lat','number',False),('lng','number',False)],path,[7,11]);loc=f.value(f.entry,'location : SelectedAddress',[22,22],shape=locshape,role='parameter');by[f.owner]['parameters']=[loc]
void_call(f,'setLoading(true)',[23,23],[cs['setLoading']]);void_call(f,'setIsEligible(null)',[24,24],[cs['setIsEligible']]);start=len(records)
lat=f.step('location.lat',[33,33],[loc]);lng=f.step('location.lng',[34,34],[loc]);ps=shape('eligibility-body','Source eligibility JSON payload',[('lat','number',False),('lng','number',False)],path,[32,35]);payload=f.step('{lat:location.lat,lng:location.lng}',[32,35],[lat,lng],shape=ps);encoded=f.step('JSON.stringify actual eligibility body',[32,35],[payload]);opts=f.step('POST options with Content-Type application/json and encoded body',[27,36],[encoded]);response=outgoing(f,'Address eligibility',[27,36],'/api/ev-subsidy/eligibility',ps,encoded,opts)
b=f.branch('!res.ok',[38,38],[response]);errorop=f.op('throw',"throw new Error('Eligibility check failed') within try",[38,38]);f.edge(b,errorop,[38,38],on='true',condition='!res.ok');err=f.value(errorop,'Allocated Error(Eligibility check failed)',[38,38]);by[errorop]['result']=err
cont=f.op('compute','res.ok truthy',[40,40]);f.edge(b,cont,[38,40],on='false',condition='res.ok');f.last=cont;data=f.step('await res.json()',[40,40],[response]);eligible=f.step('data.eligible',[41,41],[data]);void_call(f,'setIsEligible(data.eligible)',[41,41],[cs['setIsEligible'],eligible]);normal=f.last
catch=f.op('compute','catch(error): console.error(error)',[42,43]);caught=f.value(catch,'Caught source exception',[42,43]);f.edge(errorop,catch,[38,43],on='exception',values=[err]);f.last=catch;void_call(f,'setIsEligible(false)',[44,44],[cs['setIsEligible']]);caughtend=f.last
for o in list(records)[start:]:
 if o['kind']=='operation' and o['owner']==f.owner and o['action'] in ('call','compute') and o['id'] not in (catch,caughtend) and by[o['evidence'][0]]['lines'][0]<42:f.edge(o['id'],catch,[42,44],on='exception',condition='Expression rejects/throws inside try')
final=f.op('call','finally: setLoading(false)',[45,46]);by[final]['result']=None;f.edge(normal,final,[45,46]);f.edge(caughtend,final,[45,46]);falsevalue=f.value(final,'Source argument0 constant false',[46,46],role='constant');f.claim('Actual finally setter is attempted after normal or caught try completion; failures in prior setters/catch/finally remain imported runtime frontiers, not proven swallowed failures.',[final,cs['setLoading'],falsevalue],[42,46]);f.last=final;callback_end(f,[47,48]);f.claim('Actual local JSX registration passes handleSelect as AddressInput.onSelectAction. Imported Autocomplete dispatch→local handlePlaceChanged guards→onSelectAction association is source declared, not eager invocation while JSX is created.',[f.entryId,f.owner], [55,55]);f.claim('Loading=false/null/boolean state source mutations retain exact setter actuals. Concurrent selections can race; no latest-request cancellation or ordering is proved.',list(cs.values())+[loc,eligible],[22,48]);addressFrame=f

path='apps/ev-subsidy/src/components/wizard/StepPersons/index.tsx';f=Frame('submitData',path,'CALLBACK','browser:ev-subsidy:StepPersons:submitData-source-body',[39,71]);
for remove in [f.entryId,f.contract,P+'entry-binding/submitData']:
 records.remove(by.pop(remove))
f.entryId=f.owner
cs=captures(f,[('rows','PersonRow[]',[24,26]),('childrenAmount','number',[29,29]),('setLoading','React state setter',[28,28]),('onNext','source callback (data?)=>void',[13,20])]);start=len(records);void_call(f,'setLoading(true)',[41,41],[cs['setLoading']])
ps=shape('income-body','Source income request JSON object',[('rows','PersonRow[]',False),('childrenAmount','number',False)],path,[46,46]);payload=f.step('{rows, childrenAmount}',[46,46],[cs['rows'],cs['childrenAmount']],shape=ps);encoded=f.step('JSON.stringify({rows,childrenAmount})',[46,46],[payload]);opts=f.step('POST options Content-Type application/json; encoded body',[43,47],[encoded]);response=outgoing(f,'Income eligibility',[43,47],'/api/ev-subsidy/income',ps,encoded,opts)
b=f.branch('!res.ok',[49,49],[response]);errorop=f.op('throw',"throw new Error('Income eligibility request failed') within try",[49,49]);f.edge(b,errorop,[49,49],on='true',condition='!res.ok');err=f.value(errorop,'Allocated Error(Income eligibility request failed)',[49,49]);by[errorop]['result']=err;cont=f.op('compute','res.ok truthy',[51,51]);f.edge(b,cont,[49,51],on='false',condition='res.ok');f.last=cont;data=f.step('await res.json(): destructure incomeSection',[51,51],[response]);section=f.step('incomeSection from source parsed response',[51,51],[data]);b=f.branch("incomeSection.status === 'eligible'",[53,53],[section]);f.last=b
fields=['qualifiesForStartBonus','adjustedIncome','maxAdjustedIncome','maxHouseholdIncome','startBonusHouseholdIncome','startBonusThreshold'];values=[]
for name,fieldlines in zip(fields,[[55,55],[56,56],[57,57],[58,58],[59,60],[61,61]]):values.append(f.step('incomeSection.details.'+name,fieldlines,[section]))
nextshape=shape('on-next-data','Actual successful onNext data source fields',[(n,'boolean' if n=='qualifiesForStartBonus' else 'number',False) for n in fields],path,[54,62]);arg=f.step('onNext actual successful details object',[54,62],values,shape=nextshape);void_call(f,'onNext(actual details object)',[54,62],[cs['onNext'],arg]);success=f.last;bad=f.op('call','onNext() with no argument',[63,64]);f.edge(b,bad,[53,64],on='false',condition="incomeSection.status !== 'eligible'");f.claim('Actual source ineligible callback has zero arguments. No invented payload/default object and no result value.',[bad,cs['onNext']],[63,64]);normal=f.op('compute','Join successful/ineligible onNext completion',[65,65]);f.edge(success,normal,[65,65]);f.edge(bad,normal,[65,65]);catch=f.op('compute','catch(err): console.error Income API error',[66,67]);f.edge(errorop,catch,[49,67],on='exception',values=[err]);
for o in list(records)[start:]:
 if o['kind']=='operation' and o['owner']==f.owner and o['action'] in ('call','compute') and o['id']!=catch and by[o['evidence'][0]]['lines'][0]<66:f.edge(o['id'],catch,[66,67],on='exception',condition='Expression rejects/throws inside try')
final=f.op('call','finally: setLoading(false)',[68,69]);f.edge(normal,final,[68,69]);f.edge(catch,final,[68,69]);falsevalue=f.value(final,'Source argument0 constant false',[69,69],role='constant');f.claim('Catch logs and does not call onNext; finally attempts setLoading(false). Actual setter receiver and false operand association; no returned setter value.',[final,cs['setLoading'],falsevalue],[66,69]);f.last=final;callback_end(f,[70,71]);submitFrame=f

f=Frame('confirm-click',path,'CALLBACK','browser:ev-subsidy:StepPersons:confirm-button:onClick',[187,194]);by[f.owner]['returnKind']='void';cs=captures(f,[('submitData','source async closure',[39,71]),('tracker','local tracking delegate',[27,27])]);op=f.op('call','submitData() without await',[188,188]);f.edge(f.last,op,[188,188]);resolution=by[op]['resolution'];by[resolution].update(basis='source_local',target=submitFrame.owner,candidates=[]);by[op]['waitsFor']='none';task=f.value(op,'Immediate Promise<void> from submitData; not eventual callback completion',[188,188]);by[op]['result']=task
bindings=[]
for capture in by[submitFrame.owner]['captures']:
 projection=f.value(op,'Analysis projection of source closure binding: '+by[capture]['label'],[188,188],role='field');bindings.append(dict(capture=capture,value=projection,mode='unresolved'));f.claim('This source-anchored analysis projection associates the lexical variable declared in the enclosing StepPersons render with the called source closure. Exact runtime captured cell origin is unresolved; no compiler closure layout/property or extra source formal is asserted.',[cs['submitData'],projection,capture,op],[24,71])
by[op]['captureBindings']=bindings;f.last=op;void_call(f,'tracker.customEvent actual button|click / Bekräfta uppgifter / Premietestet',[189,193],[cs['tracker']]);callback_end(f,[194,194]);f.claim('Actual onClick invokes source constant submitData then tracking without awaiting the task; captured variable origins remain explicit unresolved projections. Async completion/faults do not unwind into this immediate callback. Button disabled is hasEmptyFields||loading; runtime React dispatch/closure instance and concurrent re-entry remain separate.',[f.entryId,submitFrame.owner,task],[187,195])
add('gap','gap/available-local-tracking',owner=source,obligation='remaining_available_local_tracking_and_render_helpers',reason='Tracking and shared provider implementations are available in this pinned monorepo but are not expanded by this bounded wizard network-callback unit. Exact delegate dispatch from returned tracker requires source review; it is not an unavailable foreign library or a remote service.',action='Complete separate local helper/profile review before whole-app source closure is claimed.',evidence=ev('apps/ev-subsidy/src/components/wizard/StepPersons/index.tsx',1,28))
add('coverage','coverage/full-app',owner=source,obligation='full_ev_subsidy_and_monorepo',status='not_examined',scope='Finite address/income network callbacks plus confirm-button async task invocation only. Other wizard mutations, Google loading, SSR/shared helpers, tracking, UI content and all other monorepo units remain separately in progress.',gaps=[gap],evidence=ev('apps/ev-subsidy/src/components/wizard/Wizard.tsx'))
claim=next(r for r in records if r['kind']=='claim' and r['statement'].startswith('Actual local JSX registration passes handleSelect'))
claim['evidence']+=ev('apps/ev-subsidy/src/components/wizard/AddressInput/index.tsx',29,46)
(OUT/'bundle.draft.json').write_text(json.dumps(dict(format='groundwork-knowledge/v3',workspace='volvo-cars',records=records),indent=2)+'\n');(OUT/'io-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print('records',len(records),'interactions',len(ledger))
